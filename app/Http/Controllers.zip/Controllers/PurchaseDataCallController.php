<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use Illuminate\Http\Request;
use App\Helpers\PurchaseHelper;
use App\Helpers\CommonHelper;
use Auth;
use DB;
use Config;
use Session;
use App\Models\Supplier;
use App\Models\Countries;
use App\Models\Category;
use App\Models\Subitem;
use App\Models\UOM;
use App\Models\Demand;
use App\Models\DemandData;
use App\Models\GoodsReceiptNote;
use App\Models\GRNData;
use App\Models\PurchaseVoucher;
use App\Models\PurchaseVoucherData;
use App\Models\PurchaseType;
use App\Models\Currency;
use App\Models\FinanceDepartment;
use App\Models\CostCenter;
use App\Models\CostCenterDepartmentAllocation;
use App\Models\DepartmentAllocation1;
use App\Models\SalesTaxDepartmentAllocation;
use App\Models\Transactions;
use App\Models\Warehouse;
use Input;
class PurchaseDataCallController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
   	public function viewSupplierList(){
   	    $m = $_GET['m'];
        CommonHelper::companyDatabaseConnection($m);
		$suppliers = new Supplier;
		$suppliers = $suppliers->SetConnection('mysql2');
        $suppliers=$suppliers->where('status',1)->select('name','id','email','resgister_income_tax')->get();
        CommonHelper::reconnectMasterDatabase();
		$counter = 1;
		foreach($suppliers as $row){
	?>
		<tr>
			<td class="text-center"><?php echo $counter++;?></td>
			<td class="text-center"><?php echo $row['name'];?></td>

			<td class="text-center"><?php echo $row['email'];?></td>
            <td class="text-center">	<img  src="{{URL::asset('img/103.gif')}}"  /></td>
            <td class="text-center"><button type="button" class="btn btn-primary btn-xs">Check</button></td>
			<td class="text-center"><?php echo CommonHelper::masterTableButtons($m,$row['status'],$row['id'],$row['name'],$row['acc_id'],'supplier','purchase/editSupplierForm','Edit Supplier Detail Form','purchase/viewSupplierDetail','View Supplier Detail','purchase/deleteSupplierRecord','purchase/repostSupplierRecord')?></td>
		</tr>
	<?php
		}
	}
	
	public function viewCategoryList(){
        $m = $_GET['m'];
        CommonHelper::companyDatabaseConnection($m);
		$categories = new Category;
		$categories = $categories::get();
        CommonHelper::reconnectMasterDatabase();
		$counter = 1;
		foreach($categories as $row){
	?>
		<tr>
			<td class="text-center"><?php echo $counter++;?></td>
			<td><?php echo $row['main_ic'];?></td>
			<td class="text-center"><?php echo CommonHelper::masterTableButtons($m,$row['status'],$row['id'],$row['main_ic'],$row['acc_id'],'category','purchase/editCategoryForm','Edit Category Detail Form','purchase/viewCategoryDetail','View Category Detail','purchase/deleteCategoryRecord','purchase/repostCategoryRecord')?></td>
        </tr>
	<?php
		}
	}
	
	public function viewSubItemList(){
        $m = $_GET['m'];
        CommonHelper::companyDatabaseConnection($m);
		$subitems = new Subitem;
		$subitems = $subitems::get();
        CommonHelper::reconnectMasterDatabase();
		$counter = 1;
		foreach($subitems as $row){
	?>
		<tr>
			<td class="text-center"><?php echo $counter++;?></td>
			<td><?php echo CommonHelper::getCompanyDatabaseTableValueById($m,'category','main_ic',$row['main_ic_id']);?></td>
			<td><?php echo $row['sub_ic'];?></td>
            <td class="text-center"><?php echo CommonHelper::masterTableButtons($m,$row['status'],$row['id'],$row['sub_ic'],$row['acc_id'],'subitem','purchase/editSubItemForm','Edit Sub-Item Detail Form','purchase/viewSubItemDetail','View Sub-Item Detail','purchase/deleteSubItemRecord','purchase/repostSubItemRecord')?></td>
		</tr>
	<?php
		}

	}

    public function viewUOMList(){
        $uoms = new UOM;
        $uoms = $uoms::where('status', '=', '1')->where('company_id', '=', $_GET['m'])->get();

        $counter = 1;
        foreach($uoms as $row){
            ?>
            <tr>
                <td class="text-center"><?php echo $counter++;?></td>
                <td><?php echo $row['uom_name'];?></td>
                <td></td>
            </tr>
            <?php
        }
    }

    public function filterDemandVoucherList(){
        $fromDate = $_GET['fromDate'];
        $toDate = $_GET['toDate'];
        $m = $_GET['m'];

        $selectVoucherStatus = $_GET['selectVoucherStatus'];
        $selectSubDepartment = $_GET['selectSubDepartment'];
        $selectSubDepartmentId = $_GET['selectSubDepartmentId'];

        CommonHelper::companyDatabaseConnection($m);
        if($selectVoucherStatus == '0' && empty($selectSubDepartmentId)){
            $demandDetail = Demand::whereBetween('demand_date',[$fromDate,$toDate])->get();
        }else if($selectVoucherStatus == '0' && !empty($selectSubDepartmentId)){
            $demandDetail = Demand::whereBetween('demand_date',[$fromDate,$toDate])->whereIn('status', array(1, 2))->where('sub_department_id','=',$selectSubDepartmentId)->get();
        }else if($selectVoucherStatus == '1' && !empty($selectSubDepartmentId)){
            $demandDetail = Demand::whereBetween('demand_date',[$fromDate,$toDate])->where('status','=','1')->where('demand_status','=','1')->where('sub_department_id','=',$selectSubDepartmentId)->get();
        }else if($selectVoucherStatus == '2' && !empty($selectSubDepartmentId)){
            $demandDetail = Demand::whereBetween('demand_date',[$fromDate,$toDate])->where('status','=','1')->where('demand_status','=','2')->where('sub_department_id','=',$selectSubDepartmentId)->get();
        }else if($selectVoucherStatus == '3' && !empty($selectSubDepartmentId)){
            $demandDetail = Demand::whereBetween('demand_date',[$fromDate,$toDate])->where('status','=','2')->where('sub_department_id','=',$selectSubDepartmentId)->get();
        }else if($selectVoucherStatus == '1' && empty($selectSubDepartmentId)){
            $demandDetail = Demand::whereBetween('demand_date',[$fromDate,$toDate])->where('status','=','1')->where('demand_status','=','1')->get();
        }else if($selectVoucherStatus == '2' && empty($selectSubDepartmentId)){
            $demandDetail = Demand::whereBetween('demand_date',[$fromDate,$toDate])->where('status','=','1')->where('demand_status','=','2')->get();
        }else if($selectVoucherStatus == '3' && empty($selectSubDepartmentId)){
            $demandDetail = Demand::whereBetween('demand_date',[$fromDate,$toDate])->where('status','=','2')->get();
        }
        CommonHelper::reconnectMasterDatabase();
        return view('Purchase.AjaxPages.filterDemandVoucherList',compact('demandDetail'));
    }

    public function viewDemandVoucherDetail(){
        return view('Purchase.AjaxPages.viewDemandVoucherDetail');
    }
    public function viewPurchaseVoucherDetail($id)
    {

        $purchase_voucher=new PurchaseVoucher();
        $purchase_voucher=$purchase_voucher->SetConnection('mysql2');
        $purchase_voucher=$purchase_voucher->where('status',1)->where('id',$id)->select('id','pv_no','current_amount','currency','supplier','description','pv_date','purchase_type','due_date','slip_no','total_net_amount','amount_in_words')->first();
        $PurchaseVoucherData=new PurchaseVoucherData();
        $PurchaseVoucherData=$PurchaseVoucherData->SetConnection('mysql2');
        $PurchaseVoucherData=$PurchaseVoucherData->where('master_id',$id)->select('id','pv_no','category_id','sub_item','uom','qty','rate','amount','sales_tax_per','sales_tax_amount','net_amount','dept_id')->get();
        return view('Purchase.AjaxPages.viewPurchaseVoucherDetail',compact('purchase_voucher','PurchaseVoucherData'));
    }
    public function filterGoodsReceiptNoteList(){
        $fromDate = $_GET['fromDate'];
        $toDate = $_GET['toDate'];
        $m = $_GET['m'];
        $selectVoucherStatus = $_GET['selectVoucherStatus'];
        $selectSubDepartment = $_GET['selectSubDepartment'];
        $selectSubDepartmentId = $_GET['selectSubDepartmentId'];
        $selectSupplier = $_GET['selectSupplier'];
        $selectSupplierId = $_GET['selectSupplierId'];

        CommonHelper::companyDatabaseConnection($m);
        if($selectVoucherStatus == '0' && empty($selectSubDepartmentId) && empty($selectSupplierId)){
            //return 'One';
            $goodsReceiptNoteDetail = GoodsReceiptNote::whereBetween('grn_date',[$fromDate,$toDate])->get();
        }else if($selectVoucherStatus == '0' && !empty($selectSubDepartmentId) && empty($selectSupplierId)){
            //return 'Two';
            $goodsReceiptNoteDetail = GoodsReceiptNote::whereBetween('grn_date',[$fromDate,$toDate])->whereIn('status', array(1, 2))->where('sub_department_id','=',$selectSubDepartmentId)->get();
        }else if($selectVoucherStatus == '0' && empty($selectSubDepartmentId) && !empty($selectSupplierId)){
            //return 'Three';
            $goodsReceiptNoteDetail = GoodsReceiptNote::whereBetween('grn_date',[$fromDate,$toDate])->whereIn('status', array(1, 2))->where('supplier_id','=',$selectSupplierId)->get();
        }else if($selectVoucherStatus == '1' && !empty($selectSubDepartmentId) && empty($selectSupplierId)){
            //return 'Four';
            $goodsReceiptNoteDetail = GoodsReceiptNote::whereBetween('grn_date',[$fromDate,$toDate])->where('status','=','1')->where('grn_status','=','1')->where('sub_department_id','=',$selectSubDepartmentId)->get();
        }else if($selectVoucherStatus == '2' && !empty($selectSubDepartmentId) && empty($selectSupplierId)){
            //return 'Five';
            $goodsReceiptNoteDetail = GoodsReceiptNote::whereBetween('grn_date',[$fromDate,$toDate])->where('status','=','1')->where('grn_status','=','2')->where('sub_department_id','=',$selectSubDepartmentId)->get();
        }else if($selectVoucherStatus == '3' && !empty($selectSubDepartmentId) && empty($selectSupplierId)){
            //return 'Six';
            $goodsReceiptNoteDetail = GoodsReceiptNote::whereBetween('grn_date',[$fromDate,$toDate])->where('status','=','2')->where('sub_department_id','=',$selectSubDepartmentId)->get();
        }else if($selectVoucherStatus == '1' && empty($selectSubDepartmentId) && empty($selectSupplierId)){
            //return 'Seven';
            $goodsReceiptNoteDetail = GoodsReceiptNote::whereBetween('grn_date',[$fromDate,$toDate])->where('status','=','1')->where('grn_status','=','1')->get();
        }else if($selectVoucherStatus == '2' && empty($selectSubDepartmentId) && empty($selectSupplierId)){
            //return 'Eight';
            $goodsReceiptNoteDetail = GoodsReceiptNote::whereBetween('grn_date',[$fromDate,$toDate])->where('status','=','1')->where('grn_status','=','2')->get();
        }else if($selectVoucherStatus == '3' && empty($selectSubDepartmentId) && empty($selectSupplierId)){
            //return 'Nine';
            $goodsReceiptNoteDetail = GoodsReceiptNote::whereBetween('grn_date',[$fromDate,$toDate])->where('status','=','2')->get();
        }
        else if($selectVoucherStatus == '1' && empty($selectSubDepartmentId) && !empty($selectSupplierId)){
            //return 'Ten';
            $goodsReceiptNoteDetail = GoodsReceiptNote::whereBetween('grn_date',[$fromDate,$toDate])->where('status','=','1')->where('grn_status','=','1')->where('supplier_id','=',$selectSupplierId)->get();
        }else if($selectVoucherStatus == '2' && empty($selectSubDepartmentId) && !empty($selectSupplierId)){
            //return 'Eleven';
            $goodsReceiptNoteDetail = GoodsReceiptNote::whereBetween('grn_date',[$fromDate,$toDate])->where('status','=','1')->where('grn_status','=','2')->where('supplier_id','=',$selectSupplierId)->get();
        }else if($selectVoucherStatus == '3' && empty($selectSubDepartmentId) && !empty($selectSupplierId)){
            //return 'Twelve';
            $goodsReceiptNoteDetail = GoodsReceiptNote::whereBetween('grn_date',[$fromDate,$toDate])->where('status','=','2')->where('supplier_id','=',$selectSupplierId)->get();
        }else if($selectVoucherStatus == '0' && !empty($selectSubDepartmentId) && !empty($selectSupplierId)){
            //return 'Thirteen';
            $goodsReceiptNoteDetail = GoodsReceiptNote::whereBetween('grn_date',[$fromDate,$toDate])->where('supplier_id','=',$selectSupplierId)->where('sub_department_id','=',$selectSubDepartmentId)->get();
        }else if($selectVoucherStatus == '1' && !empty($selectSubDepartmentId) && !empty($selectSupplierId)){
            //return 'Fourteen';
            $goodsReceiptNoteDetail = GoodsReceiptNote::whereBetween('grn_date',[$fromDate,$toDate])->where('status','=','1')->where('grn_status','=','1')->where('supplier_id','=',$selectSupplierId)->where('sub_department_id','=',$selectSubDepartmentId)->get();
        }else if($selectVoucherStatus == '2' && !empty($selectSubDepartmentId) && !empty($selectSupplierId)){
            //return 'Fifteen';
            $goodsReceiptNoteDetail = GoodsReceiptNote::whereBetween('grn_date',[$fromDate,$toDate])->where('status','=','1')->where('grn_status','=','2')->where('supplier_id','=',$selectSupplierId)->where('sub_department_id','=',$selectSubDepartmentId)->get();
        }else if($selectVoucherStatus == '3' && !empty($selectSubDepartmentId) && !empty($selectSupplierId)){
            //return 'Sixteen';
            $goodsReceiptNoteDetail = GoodsReceiptNote::whereBetween('grn_date',[$fromDate,$toDate])->where('status','=','2')->where('supplier_id','=',$selectSupplierId)->where('sub_department_id','=',$selectSubDepartmentId)->get();
        }

        CommonHelper::reconnectMasterDatabase();
        return view('Purchase.AjaxPages.filterGoodsReceiptNoteList',compact('goodsReceiptNoteDetail'));
    }

    public function filterGoodsForwardOrderVoucherList(){
        $fromDate = $_GET['fromDate'];
        $toDate = $_GET['toDate'];
        $m = $_GET['m'];
        $selectVoucherStatus = $_GET['selectVoucherStatus'];
        $selectBranch = $_GET['selectBranch'];
        $selectBranchId = $_GET['selectBranchId'];
        CommonHelper::companyDatabaseConnection($m);
        $goodsForwardOrderDetail = Demand::whereBetween('demand_date',[$fromDate,$toDate])->get();
        CommonHelper::reconnectMasterDatabase();
        return view('Purchase.AjaxPages.filterGoodsForwardOrderVoucherList',compact('goodsForwardOrderDetail'));
    }

    public function viewGoodsReceiptNoteDetail(){
        return view('Purchase.AjaxPages.viewGoodsReceiptNoteDetail');
    }

    public function filterApproveDemandListandCreateGoodsForwardOrder(){
        return view('Purchase.AjaxPages.filterApproveDemandListandCreateGoodsForwardOrder');
    }

    public function createGoodsForwardOrderDetailForm(Request $request){
        return view('Purchase.createGoodsForwardOrderDetailForm',compact('request'));
    }


    public function createSupplierFormAjax()
    {
        $countries = new Countries;
        $countries = $countries::where('status', '=', 1)->get();
        return view('Purchase.AjaxPages.createSupplierFormAjax',compact('countries'));

    }

    public function createWarehouseFormAjax()
    {

        return view('Purchase.AjaxPages.createWarehouseFormAjax');

    }
  public function createPurchaseTypeForm()
    {

        return view('Purchase.AjaxPages.createPurchaseTypeForm');

    }

    public function createCurrencyTypeForm()
    {

        return view('Purchase.AjaxPages.createCurrencyTypeForm');

    }

    public function createDepartmentFormAjax($id)
    {

        return view('Purchase.AjaxPages.createDepartmentFormAjax',compact('id'));

    }

    public function createCostCenterFormAjax($id)
    {

        return view('Purchase.AjaxPages.createCostCenterFormAjax',compact('id'));

    }

    public function createSubItemFormAjax($id='')
    {
        $uom = new UOM;
        $uom = $uom::where('status','=','1')->get();
        CommonHelper::companyDatabaseConnection($_GET['m']);
        $categories = new Category;
        $categories = $categories::where('status','=','1')->get();

        return view('Purchase.AjaxPages.createSubItemFormAjax',compact('categories','uom','id'));

    }

    public  function addSupplierDetail()
    {

        $supplier_name = Input::get('supplier_name');
        DB::transaction(function () {
            CommonHelper::companyDatabaseConnection($_GET['m']);
            $account_head  ='2-1';
            $supplier_name = Input::get('supplier_name');
            $country = Input::get('country');
            $state = Input::get('state');
            $city = Input::get('city');
            $email = Input::get('email');
            $o_blnc_trans = Input::get('o_blnc_trans');
            $register_income_tax=Input::get('regd_in_income_tax');
            $business_type=Input::get('optradio');
            $ntn=Input::get('ntn');
            $cnic=Input::get('cnic');
            $regd_in_sales_tax=Input::get('regd_in_sales_tax');
            $strn=Input::get('strn');
            $regd_in_srb=Input::get('regd_in_srb');
            $srb=Input::get('srb');
            $regd_in_pra=Input::get('regd_in_pra');
            $pra=Input::get('pra');

            $print_check_as=Input::get('print_check_as');
            $vendor_type=Input::get('vendor_type');
            $website=Input::get('website');
            $credit_limit=Input::get('credit_limit');
            $acc_no=Input::get('acc_no');
            $bank_name=Input::get('bank_name');
            $bank_address=Input::get('bank_address');
            $branch_name=Input::get('branch_name');
            $swift_code=Input::get('swift_code');
            $open_date=Input::get('open_date');


            $address[] = Input::get('address');
            $o_blnc = Input::get('o_blnc');
            $operational = '1';
            $sent_code = '2-1';

            $max_id = DB::selectOne('SELECT max(`id`) as id  FROM `accounts` WHERE `parent_code` LIKE \''.$account_head.'\'')->id;
            if($max_id == '')
            {
                $code = $sent_code.'-1';
            }
            else
            {
                $max_code2 = DB::selectOne('SELECT `code`  FROM `accounts` WHERE `id` LIKE \''.$max_id.'\'')->code;
                $max_code2;
                $max = explode('-',$max_code2);
                $code = $sent_code.'-'.(end($max)+1);
            }

            $level_array = explode('-',$code);
            $counter = 1;
            foreach($level_array as $level):
                $data1['level'.$counter] = strip_tags($level);
                $counter++;
            endforeach;
            $data1['code']              = strip_tags($code);
            $data1['name']              = strip_tags($supplier_name);
            $data1['parent_code']       = strip_tags($account_head);
            $data1['username'] 		 	= Auth::user()->name;
            $data1['date']     		    = date("Y-m-d");
            $data1['time']     		    = date("H:i:s");
            $data1['action']     		= 'create';
            $data1['operational']		= strip_tags($operational);
            $data1['acc_type']		= 1;
            $acc_id = DB::table('accounts')->insertGetId($data1);


            $data2['acc_id']		    =  strip_tags($acc_id);
            $data2['resgister_income_tax']     		    = strip_tags($register_income_tax);
            $data2['business_type']     		= strip_tags($business_type);
            $data2['cnic']     	    = strip_tags($cnic);
            $data2['ntn']     	        = strip_tags($ntn);
            $data2['register_sales_tax']     	        = strip_tags($regd_in_sales_tax);
            $data2['strn']     	        = strip_tags($strn);
            $data2['register_srb']     	        = strip_tags($regd_in_srb);
            $data2['srb']     	        = strip_tags($srb);
            $data2['register_pra']     	        = strip_tags($regd_in_pra);
            $data2['pra']     	        = strip_tags($pra);
            $data2['name']     		    = strip_tags($supplier_name);
            $data2['country']     		= strip_tags($country);
            $data2['province']     	    = strip_tags($state);
            $data2['city']     	        = strip_tags($city);
            $data2['email']   		    = strip_tags($email);
            $data2['username']	 	    = Auth::user()->name;
            $data2['date']     		    = date("Y-m-d");
            $data2['time']     		    = date("H:i:s");
            $data2['action']     		= 'create';
            $data2['company_id']     		= $_GET['m'];
            $data2['print_check_as']     		= $print_check_as;
            $data2['vendor_type']	 	    = $vendor_type;
            $data2['website']     		    = $website;
            $data2['credit_limit']     		    = $credit_limit;
            $data2['acc_no']     		= $acc_no;
            $data2['bank_name']     		= $bank_name;
            $data2['bank_address']     		= $bank_address;
            $data2['swift_code']     		= $swift_code;
            $data2['branch_name']     		= $branch_name;
            $data2['opening_bal_date']     		= $open_date;
            $lastInsertedID = DB::table('supplier')->InsertGetId($data2);

            $count1 = count(Input::get('contact_no'));
            $count2 = count(Input::get('address'));
            if ($count1==$count2):
                $count=$count1;
            else:

                if ($count1 >$count2):
                    $count=$count1;
                else:
                    $count=$count2;
                endif;
            endif;
            $count=$count-1;

            for($i=0; $i<=$count;$i++):
                $data4['supp_id']=$lastInsertedID;



                $ii=$i+1;
                if ($count2 >=$ii):


                    $data4['address']=Input::get('address')[$i];
                else:
                    $data4['address']='';
                endif;

                if ($count1 >=$ii):


                    $data4['contact_no']=Input::get('contact_no')[$i];
                else:
                    $data4['contact_no']='';
                endif;
                DB::table('supplier_info')->insert($data4);
            endfor;

            $data3['acc_id']            = strip_tags($acc_id);
            $data3['acc_code']          = strip_tags($code);
            $data3['debit_credit']      = 0;
            $data3['amount'] 	        = strip_tags($o_blnc);
            $data3['opening_bal'] 	    = 1;
            $data3['username'] 		 	= Auth::user()->name;
            $data3['date']     		    = date("Y-m-d");
            $data3['v_date']     		= date("Y-m-d");

            $data3['action']     		= 'create';
            DB::table('transactions')->insert($data3);

            echo $lastInsertedID.'+'.ucwords($supplier_name).'+'.Input::get('address')[0].'+'.$ntn;
        });
        CommonHelper::reconnectMasterDatabase();

    }

    public function addPurchaseType(Request $request)
    {

        $name=$request->purchase_type;
        $purchase_type=new PurchaseType();
        $purchase_type=$purchase_type->SetConnection('mysql2');
        $purchase_type_count=$purchase_type->where('status',1)->where('name',$name)->count();;

        if ($purchase_type_count >0):
            echo 0;

        else:

            $purchase_type->name=$name;
            $purchase_type->username=Auth::user()->name;
            $purchase_type->date=date('Y-m-d');
            $purchase_type->save();
            $id=$purchase_type->id;
            echo $id.','.$name;
        endif;
    }

    public  function addCurrency()
    {
        $currency_name= $_GET['currency'];

        $currecy=new Currency();
        $currecy=$currecy->SetConnection('mysql2');
        $currecy_count=$currecy->where('status',1)->where('curreny',$currency_name)->count();;

        if ($currecy_count >0):
            echo 0;

        else:
            $currecy->curreny=$currency_name;
            $currecy->username=Auth::user()->name;;
            $currecy->date=date('Y-m-d');

            $currecy->save();
            $id=$currecy->id;

            echo $id.','.'0.00'.'/'.ucfirst($currency_name);
        endif;
    }

    public function addCurrencyForm(Request $request)
    {


        $currency=new Currency();
        $currency=$currency->SetConnection('mysql2');
        $data['rate']=$request->rate;
        $id=$request->dropdown_currency;
        $id=explode(',',$id);
        $id=$id[0];
        $currency->where('id', array($id))->update($data);
        $request->rate;

        $currency_data=$currency->where('status',1)->get();
          ?>

        <select>
            <option value="0,1">Select</option>
        <?php foreach($currency_data as $row):?>
        <option value="<?php echo $row->id.','.$row->rate ?>"><?php echo $row->curreny.'-------'.$row->rate ?></option><?php
        endforeach;?></select>
<?php
    }
public function addSubItemDetailAjax()
{



    $m = $_GET['m'];
    CommonHelper::companyDatabaseConnection($_GET['m']);

    $category_name = Input::get('category_name');
    $sub_item_name = Input::get('sub_item_name');
    $opening_qty = Input::get('opening_qty');
    $opening_value = Input::get('opening_value');
    $reorder_level = Input::get('reorder_level');
    $id = Input::get('id');
    //  $rate = Input::get('rate');
    $uom = Input::get('uom_id');

    $pack_size = Input::get('pack_size');
    $desc = Input::get('desc');
    $type = Input::get('type');
    $rate = Input::get('rate');
    $username = '';
    $branch_id = '';
    $o_blnc_trans_form 		= 	1;
    $wip_finish_g_form = 'fara';
    //  $acc_id = DB::selectOne('select `acc_id` from `category` where `id` = '.$category_name.'')->acc_id;
    //  $parent_code = DB::selectOne('select code from `accounts` where `id` = '.$acc_id.'')->code;
    //  $max_id = DB::selectOne('SELECT max(`id`) as id  FROM `accounts` WHERE `parent_code` LIKE \''.$parent_code.'\'')->id;
    //  if($max_id == ''){
    //     $code = $parent_code.'-1';
    //  }else{
    //      $max_code2 = DB::selectOne('SELECT `code`  FROM `accounts` WHERE `id` LIKE \''.$max_id.'\'')->code;
    //     $max_code2;
    //     $max = explode('-',$max_code2);
    //     $code = $parent_code.'-'.(end($max)+1);
    //   }
    //  $level_array = explode('-',$code);
    //  $counter = 1;
    //  foreach($level_array as $level):
    //      $data1['level'.$counter] = strip_tags($level);
    //     $counter++;
    //  endforeach;

    //  $data1['code']              = strip_tags($code);
    //   $data1['name']              = strip_tags($sub_item_name);
    //   $data1['parent_code']       = strip_tags($parent_code);
    $data1['username'] 		 	= Auth::user()->name;
    $data1['date']     		    = date("Y-m-d");
    $data1['time']     		    = date("H:i:s");
    $data1['action']     		= 'create';
    $data1['operational']		= 1;


    //  $acc_id_new = DB::table('accounts')->insertGetId($data1);

    //  $data2['acc_id']			= strip_tags($acc_id_new);
    $data2['sub_ic']     		= strip_tags($sub_item_name);
    $data2['main_ic_id']     	= strip_tags($category_name);
    $data2['reorder_level']     = strip_tags($reorder_level);
    $data2['uom']     	        = strip_tags($uom);
    $data2['rate']     	        = $rate;
    $data2['username']	 	    = Auth::user()->name;
    $data2['date']     		    = date("Y-m-d");
    $data2['time']     		    = date("H:i:s");
    $data2['action']     		= 'create';
    $data2['company_id']        = $m;
    $data2['pack_size']         = $pack_size;
    $data2['description']     	= $desc;
    $data2['itemType']     	    = $type;


    $s_id = DB::table('subitem')->insertGetId($data2);
    echo $s_id.','.ucfirst($sub_item_name).','.$category_name.','.$id;

 


    die;

    $m = $_GET['m'];
    CommonHelper::companyDatabaseConnection($_GET['m']);

    $category_name = Input::get('category_name');
    $sub_item_name = Input::get('sub_item_name');
    $opening_qty = Input::get('opening_qty');
    $opening_value = Input::get('opening_value');
    $reorder_level = Input::get('reorder_level');
    $rate = Input::get('rate');
    $uom = Input::get('uom_id');
    $username = '';
    $branch_id = '';
    $o_blnc_trans_form 		= 	1;
    $wip_finish_g_form = 'fara';
    $acc_id = DB::selectOne('select `acc_id` from `category` where `id` = '.$category_name.'')->acc_id;
    $parent_code = DB::selectOne('select code from `accounts` where `id` = '.$acc_id.'')->code;
    $max_id = DB::selectOne('SELECT max(`id`) as id  FROM `accounts` WHERE `parent_code` LIKE \''.$parent_code.'\'')->id;
    if($max_id == ''){
        $code = $parent_code.'-1';
    }else{
        $max_code2 = DB::selectOne('SELECT `code`  FROM `accounts` WHERE `id` LIKE \''.$max_id.'\'')->code;
        $max_code2;
        $max = explode('-',$max_code2);
        $code = $parent_code.'-'.(end($max)+1);
    }
    $level_array = explode('-',$code);
    $counter = 1;
    foreach($level_array as $level):
        $data1['level'.$counter] = strip_tags($level);
        $counter++;
    endforeach;

    $data1['code']              = strip_tags($code);
    $data1['name']              = strip_tags($sub_item_name);
    $data1['parent_code']       = strip_tags($parent_code);
    $data1['username'] 		 	= Auth::user()->name;
    $data1['date']     		    = date("Y-m-d");
    $data1['time']     		    = date("H:i:s");
    $data1['action']     		= 'create';
    $data1['operational']		= 1;


    $acc_id_new = DB::table('accounts')->insertGetId($data1);

    $data2['acc_id']			= strip_tags($acc_id_new);
    $data2['sub_ic']     		= strip_tags($sub_item_name);
    $data2['main_ic_id']     	= strip_tags($category_name);
    $data2['reorder_level']     = strip_tags($reorder_level);
    $data2['uom']     	        = strip_tags($uom);
    $data2['rate']     	        = $rate;
    $data2['username']	 	    = Auth::user()->name;
    $data2['date']     		    = date("Y-m-d");
    $data2['time']     		    = date("H:i:s");
    $data2['action']     		= 'create';
    $data2['company_id']        = $m;

    $s_id = DB::table('subitem')->insertGetId($data2);

    $data3['acc_code']		    = strip_tags($code);
    $data3['acc_id']		    = strip_tags($acc_id_new);
    $data3['debit_credit']	    = 1;
    $data3['opening_bal']	    = 1;
    $data3['username'] 		    = Auth::user()->name;
    $data3['v_date']     		= date("Y-m-d");
    $data3['date']     		    = date("Y-m-d");

    $data3['action']     	    = 'create';
    $data3['status']			= 1;
    $data3['amount']		    = $opening_value;

    DB::table('transactions')->insert($data3);

    $data4['main_ic_id']        = strip_tags($category_name);
    $data4['sub_ic_id']         = strip_tags($s_id);
    $data4['value'] 	        = $opening_value;
    $data4['qty']     		    = strip_tags($opening_qty);
    $data4['date']     	        = date("Y-m-d");
    $data4['time']     	        = date("H:i:s");
    $data4['action']     	    = '1';//1 for opening
    $data4['username'] 	        = Auth::user()->name;
    $data4['date']     	        = date("Y-m-d");
    $data4['time']     	        = date("H:i:s");
    $data4['company_id']        = $m;

    DB::table('fara')->insert($data4);

    CommonHelper::reconnectMasterDatabase();

    echo $s_id.','.ucfirst($sub_item_name);
 //   return Redirect::to('purchase/viewSubItemList?pageType='.Input::get('pageType').'&&parentCode='.Input::get('parentCode').'&&m='.$_GET['m'].'#SFR');

}


    public function addDepartmentFormAjax(Request $request)
    {
        $name=$request->dept_name;
        $department=new FinanceDepartment();
        $department=$department->SetConnection('mysql2');
        $department_count=$department->where('status',1)->where('name',$name)->count();
        if ($department_count >0):
            Session::flash('dataDelete',$name.' '.'Already Exists.');
            return Redirect::to('finance/createDepartmentForm?pageType=add&&parentCode=82&&m=1#SFR');
        else:
            $parent_code = $request->account_id;
            $sent_code = $parent_code;


            if ($request->first_level==1):
                $max_id = DB::connection('mysql2')->selectOne('SELECT max(`id`) as id  FROM `finance_department` WHERE `first_level`=1')->id;
                $code=$max_id+1;
                $level=$code;
                $department->level1=$level;

            else:


                $max_id = DB::connection('mysql2')->selectOne('SELECT max(`id`) as id  FROM `finance_department` WHERE `parent_code` LIKE \''.$parent_code.'\'')->id;
                if($max_id == '')
                {
                    $code = $sent_code.'-1';
                }
                else
                {
                    $max_code2 = DB::connection('mysql2')->selectOne('SELECT `code`  FROM `finance_department` WHERE `id` LIKE \''.$max_id.'\'')->code;
                    $max_code2;
                    $max = explode('-',$max_code2);
                    $code = $sent_code.'-'.(end($max)+1);
                }



                $level_array = explode('-',$code);
                $counter = 1;
                foreach($level_array as $level):
                    $levell='level'.$counter.'';
                    $department->$levell=$level;

                    $counter++;
                endforeach;


            endif;
            $department->code = $code;
            $department->parent_code = $parent_code;
            $department->first_level = $request->first_level;
            $department->name=$name;
            $department->username=Auth::user()->name;
            $department->date=date('Y-m-d');
            $department->save();
            $id=$department->id;
         //   Session::flash('dataInsert','successfully saved.');
          //  return Redirect::to('finance/createDepartmentForm?pageType=add&&parentCode=82&&m=1#SFR');
        endif;

        echo $id.','.ucwords($name).','.$request->id;

    }


    public function addCostCenterFormajax(Request $request)
    {
        $name = $request->cost_center;
        $cost_center = new CostCenter();
        $cost_center = $cost_center->SetConnection('mysql2');
        $cost_center_count = $cost_center->where('status', 1)->where('name', $name)->count();
        if ($cost_center_count > 0):
            echo 0;
        //    Session::flash('dataDelete', $name . ' ' . 'Already Exists.');
         //   return Redirect::to('finance/createCostCenterForm?pageType=add&&parentCode=82&&m=1#SFR');
        else:
            $parent_code = $request->parent_cost_center;
            $sent_code = $parent_code;
            if ($request->first_level == 1):
                $id = DB::connection('mysql2')->selectOne('SELECT max(`id`) as id  FROM `cost_center` WHERE `first_level`=1')->id;
                $max_id=DB::connection('mysql2')->selectOne('SELECT code  FROM `cost_center` WHERE `first_level`=1 and id="'.$id.'"')->code;
                $code = $max_id + 1;
                $level = $code;
                $cost_center->level1 = $level;
            else:
                $max_id = DB::connection('mysql2')->selectOne('SELECT max(`id`) as id  FROM `cost_center` WHERE `parent_code` LIKE \'' . $parent_code . '\'')->id;
                if ($max_id == '') {
                    $code = $sent_code . '-1';
                } else {
                    $max_code2 = DB::connection('mysql2')->selectOne('SELECT `code`  FROM `cost_center` WHERE `id` LIKE \'' . $max_id . '\'')->code;
                    $max_code2;
                    $max = explode('-', $max_code2);
                    $code = $sent_code . '-' . (end($max) + 1);
                }
                $level_array = explode('-', $code);
                $counter = 1;
                foreach ($level_array as $level):
                    $levell = 'level' . $counter . '';
                    $cost_center->$levell = $level;
                    $counter++;
                endforeach;
            endif;
            $cost_center->code = $code;
            $cost_center->parent_code = $parent_code;
            $cost_center->first_level = $request->first_level;
            $cost_center->name = $name;
            $cost_center->username = Auth::user()->name;
            $cost_center->date = date('Y-m-d');
            $cost_center->save();
            $id=$cost_center->id;

            echo $id.','.ucwords($name).','.$request->id;
          //  Session::flash('dataInsert', 'successfully saved.');
         //   return Redirect::to('finance/createCostCenterForm?pageType=add&&parentCode=82&&m=1#SFR');
        endif;
    }

    public function viewPurchaseVoucherDetailAfterSubmit($id)
    {

        $purchase_voucher=new PurchaseVoucher();
        $purchase_voucher=$purchase_voucher->SetConnection('mysql2');
        $purchase_voucher=$purchase_voucher->where('status',1)->where('id',$id)->select('id','pv_no','current_amount','currency','supplier','description','pv_date','purchase_type','due_date','slip_no','total_net_amount','amount_in_words')->first();
        $PurchaseVoucherData=new PurchaseVoucherData();
        $PurchaseVoucherData=$PurchaseVoucherData->SetConnection('mysql2');
        $PurchaseVoucherData=$PurchaseVoucherData->where('master_id',$id)->select('id','pv_no','category_id','sub_item','uom','qty','rate','amount','sales_tax_per','sales_tax_amount','net_amount','dept_id')->get();
        return view('Purchase.viewPurchaseVoucherDetailAfterSubmit',compact('purchase_voucher','PurchaseVoucherData'));
    }
    public function deletepurchasevoucher()
    {
        $cn = DB::connection('mysql2');
        $cn->beginTransaction();
         $id = $_GET['id'];

        $purchase_voucher=new PurchaseVoucher();
        $purchase_voucher=$purchase_voucher->SetConnection('mysql2');
        $purchase_voucher->where('id',$id)->delete();

        $purchase_voucher_data=new PurchaseVoucherData();
        $purchase_voucher_data=$purchase_voucher_data->SetConnection('mysql2');
        $purchase_voucher_data->where('master_id',$id)->delete();

        $department=new DepartmentAllocation1();
        $department=$department->SetConnection('mysql2');
        $department->where('Main_master_id',$id)->delete();

        $cost_center=new CostCenterDepartmentAllocation();
        $cost_center=$cost_center->SetConnection('mysql2');
        $cost_center->where('Main_master_id',$id)->delete();


        $sales_tax=new SalesTaxDepartmentAllocation();
        $sales_tax=$sales_tax->SetConnection('mysql2');
        $sales_tax->where('Main_master_id',$id)->delete();


        $tran=new Transactions();
        $tran=$tran->SetConnection('mysql2');
        $tran->where('master_id',$id)->where('voucher_type',4)->delete();
        $cn->rollBack();
    }


    public function purchase_voucher_list_ajax(){

        $fromDate = $_GET['from'];
        $to = $_GET['to'];
        $purchase_voucher=new PurchaseVoucher();
        $purchase_voucher=$purchase_voucher->SetConnection('mysql2');
        $purchase_voucher=$purchase_voucher->where('status',1)->whereBetween('pv_date', [$fromDate, $to])->
        select('id','pv_no','pv_date','supplier','slip_no','bill_date','total_net_amount')->orderBy('pv_date','ASC')->
        get();

        return view('Purchase.AjaxPages.purchase_voucher_list_ajax',compact('purchase_voucher'));

    }

    public function createCategoryFormAjax()
    {

        return view('Purchase.AjaxPages.createCategoryFormAjax');

    }
    public function addCategoryDetailAjax()
    {
        $m = $_GET['m'];
        $category_name = Input::get('category_name');
        $wip_finish_g_form = 'fara';
        $branch_id = '';
        $username = '';
        $o_blnc_trans = 1;
        $o_blnc = 0;
        $data2['main_ic'] = strip_tags($category_name);
        $data2['type'] = 2;
        $data2['username'] = Auth::user()->name;
        $data2['date'] = date("Y-m-d");
        $data2['time'] = date("H:i:s");
        $data2['action'] = 'create';
        $data2['company_id'] = $m;
        $m_id = DB::connection('mysql2')->table('category')->insertGetId($data2);
        CommonHelper::reconnectMasterDatabase();
        echo $m_id.','.ucwords($category_name);
        // return Redirect::to('purchase/viewCategoryList?pageType=' . Input::get('pageType') . '&&parentCode=' . Input::get('parentCode') . '&&m=' . $_GET['m'] . '#SFR');
    }

    public function addWarehouseDetailAjax(Request $request)
    {
        $name = $request->warehouse;
        $warehouse = new Warehouse();
        $warehouse = $warehouse->SetConnection('mysql2');
        $warehouse_count = $warehouse->where('status', 1)->where('name', $name)->count();
        if ($warehouse_count > 0):
            echo 0;
         //   Session::flash('dataDelete', $name . ' ' . 'Already Exists.');
         //   return Redirect::to('purchase/createWarehouseForm?pageType=add&&parentCode=82&&m=1#SFR');
        else:

            $warehouse->name = $name;
            $warehouse->username = Auth::user()->name;
            $warehouse->date = date('Y-m-d');
            $warehouse->save();
            $id=$warehouse->id;
         //   Session::flash('dataInsert', 'successfully saved.');
           echo $id.','.ucwords($name);
         //   return Redirect::to('purchase/createWarehouseForm?pageType=add&&parentCode=82&&m=1#SFR');
        endif;

    }
}
