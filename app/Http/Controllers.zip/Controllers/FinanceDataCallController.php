<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use Illuminate\Http\Request;
use App\category;
use App\Models\Account;
use App\Models\Jvs;
use App\Models\Jvs_data;
use App\Models\Pvs;
use App\Models\Pvs_data;
use App\Models\Rvs;
use App\Models\Rvs_data;
use App\Helpers\FinanceHelper;
use App\Helpers\CommonHelper;
use Input;
use Auth;
use DB;
use Config;
use Session;
use PDF;
class FinanceDataCallController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */

    public function viewJournalVoucherDetail(){
        return view('Finance.AjaxPages.viewJournalVoucherDetail');
    }

    public function viewCashPaymentVoucherDetail(){
        return view('Finance.AjaxPages.viewCashPaymentVoucherDetail');
	}
	
	public function viewBankPaymentVoucherDetail(){
        return view('Finance.AjaxPages.viewBankPaymentVoucherDetail');
	}
	
	public function viewCashReceiptVoucherDetail(){
        return view('Finance.AjaxPages.viewCashReceiptVoucherDetail');
	}
	
	public function viewBankReceiptVoucherDetail(){
        return view('Finance.AjaxPages.viewBankReceiptVoucherDetail');
	}

    public function filterJournalVoucherList(){
        return view('Finance.AjaxPages.filterJournalVoucherList');
    }
	
	public function filterCashPaymentVoucherList(){
        return view('Finance.AjaxPages.filterCashPaymentVoucherList');
    }

	public function filterBankPaymentVoucherList(){
        return view('Finance.AjaxPages.filterBankPaymentVoucherList');
	}
    public function createAccountFormAjax($id){

        $accounts = new Account;
        $accounts=$accounts->SetConnection('mysql2');
        $accounts = $accounts->orderBy('level1', 'ASC')
            ->orderBy('level2', 'ASC')
            ->orderBy('level3', 'ASC')
            ->orderBy('level4', 'ASC')
            ->orderBy('level5', 'ASC')
            ->orderBy('level6', 'ASC')
            ->orderBy('level7', 'ASC')
            ->get();
        return view('Finance.AjaxPages.createAccountFormAjax',compact('accounts','id'));

    }
	public function filterCashReceiptVoucherList(){
        return view('Finance.AjaxPages.filterCashReceiptVoucherList');
	}

	public function filterBankReceiptVoucherList(){
        return view('Finance.AjaxPages.filterBankReceiptVoucherList');
	}

	public function loadFilterLedgerReport(){
        return view('Finance.AjaxPages.loadFilterLedgerReport');
    }

    public function filterPurchaseCashPaymentVoucherList(){
        return view('Finance.AjaxPages.filterPurchaseCashPaymentVoucherList');
    }

    public function filterPurchaseBankPaymentVoucherList(){
        return view('Finance.AjaxPages.filterPurchaseBankPaymentVoucherList');
    }

    public function filterSaleCashReceiptVoucherList(){
        return view('Finance.AjaxPages.filterSaleCashReceiptVoucherList');
    }

    public function filterSaleBankReceiptVoucherList(){
        return view('Finance.AjaxPages.filterSaleBankReceiptVoucherList');
    }

    public function filterPurchaseJournalVoucherList(){
        return view('Finance.AjaxPages.filterPurchaseJournalVoucherList');
    }

    public function filterSaleJournalVoucherList(){
        return view('Finance.AjaxPages.filterSaleJournalVoucherList');
    }

    public function addChartOfAccount(){

        FinanceHelper::companyDatabaseConnection($_GET['m']);
        $parent_code = Input::get('account_id');
        $acc_name = Input::get('acc_name');
        $o_blnc = Input::get('o_blnc');
        $o_blnc_trans = Input::get('o_blnc_trans');
        $operational = Input::get('operational');
        $sent_code = $parent_code;


        $max_id = DB::selectOne('SELECT max(`id`) as id  FROM `accounts` WHERE `parent_code` LIKE \''.$parent_code.'\'')->id;
        if($max_id == '')
        {
            $code = $sent_code.'-1';
        }
        else
        {
            $max_code2 = DB::selectOne('SELECT `code`  FROM `accounts` WHERE `id` LIKE \''.$max_id.'\'')->code;
            $max_code2;
            $max = explode('-',$max_code2);
            $code = $sent_code.'-'.(end($max)+1);
        }

        $level_array = explode('-',$code);
        $counter = 1;
        foreach($level_array as $level):
            $data1['level'.$counter] = $level;
            $counter++;
        endforeach;
        $data1['code'] = $code;
        $data1['name'] = $acc_name;
        $data1['parent_code'] = $parent_code;
        $data1['username'] 		 	= Auth::user()->name;

        $data1['date']     		  = date("Y-m-d");
        $data1['time']     		  = date("H:i:s");
        $data1['action']     		  = 'create';
        $data1['operational']		= $operational;


        $acc_id = DB::table('accounts')->insertGetId($data1);


        //$acc_id = $data1->id;

        $data2['acc_id'] =	$acc_id;
        $data2['acc_code']=	$code;
        $data2['debit_credit']=	$o_blnc_trans;
        $data2['amount'] 	  = 	$o_blnc;
        $data2['opening_bal'] 	  = 	1;
        $data2['username'] 		 	= Auth::user()->name;

        $data2['date']     		  = date("Y-m-d");
        $data2['v_date']     		= date("Y-m-d");
        $data2['time']     		  = date("H:i:s");
        $data2['action']     		  = 'create';
        DB::table('transactions')->insert($data2);

        FinanceHelper::reconnectMasterDatabase();
        echo ucwords($acc_name).','.$acc_id.','.Input::get('id');
       // return Redirect::to('finance/viewChartofAccountList?pageType='.Input::get('pageType').'&&parentCode='.Input::get('parentCode').'&&m='.$_GET['m'].'#SFR');
    }
}