<?php

namespace App\Http\Controllers;
use Illuminate\Database\DatabaseManager;
use App\Http\Requests;
use Illuminate\Http\Request;
use App\Helpers\CommonHelper;
use App\Helpers\FinanceHelper;
use Input;
use Auth;
use DB;
use Config;
use Redirect;
class SalesAddDetailControler extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
		
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
   
   	public function addCashCustomerDetail(){
        CommonHelper::companyDatabaseConnection($_GET['m']);
		
		$account_head = Input::get('account_head');
		$customer_name = Input::get('customer_name');
		$country = Input::get('country');
		$state = Input::get('state');
		$city = Input::get('city');
		$contact_no = Input::get('contact_no');
		$email = Input::get('email');
		$o_blnc_trans = Input::get('o_blnc_trans');
		$o_blnc = Input::get('o_blnc');
		$operational = '1';
		$customer_type = '2';
		$sent_code = $account_head;
		
		$max_id = DB::selectOne('SELECT max(`id`) as id  FROM `accounts` WHERE `parent_code` LIKE \''.$account_head.'\'')->id;
		if($max_id == ''){
        	$code = $sent_code.'-1';
		}else{
			$max_code2 = DB::selectOne('SELECT `code`  FROM `accounts` WHERE `id` LIKE \''.$max_id.'\'')->code;
			$max_code2;
			$max = explode('-',$max_code2);
        	$code = $sent_code.'-'.(end($max)+1);
		}
			
        $level_array = explode('-',$code);
        $counter = 1;
        foreach($level_array as $level):
        	$data1['level'.$counter] = $level;
            $counter++;
       	endforeach;
       	$data1['code'] = $code;
        $data1['name'] = $customer_name;
        $data1['parent_code'] = $account_head;
        $data1['username'] 		 	= Auth::user()->name;
        $data1['date']     		  = date("Y-m-d");
        $data1['time']     		  = date("H:i:s");
        $data1['action']     		  = 'create';
        $data1['operational']		= $operational;
		
		
		$acc_id = DB::table('accounts')->insertGetId($data1);
		
		
		$data2['acc_id']		     = $acc_id;
		$data2['name']     		   = $customer_name;
		$data2['country']     		= $country;
		$data2['province']     	   = $state;
		$data2['city']     	       = $city;
		$data2['contact']   		    = $contact_no;									
		$data2['email']   		      = $email;												
		$data2['username']	 	   = Auth::user()->name;
		$data2['date']     		   = date("Y-m-d");
		$data2['time']     		   = date("H:i:s");			
		$data2['action']     		 = 'create';
		$data2['customer_type']     = $customer_type;
		
		DB::table('customers')->insert($data2);
		
		$data3['acc_id'] =	$acc_id;
        $data3['acc_code']=	$code;
        $data3['debit_credit']=	$o_blnc_trans;
		$data3['amount'] 	  = 	$o_blnc;
        $data3['opening_bal'] 	  = 	1;
       	$data3['username'] 		 	= Auth::user()->name;
        $data3['date']     		  = date("Y-m-d");
        $data3['v_date']     		= date("Y-m-d");
        $data3['time']     		  = date("H:i:s");
        $data3['action']     		  = 'create';
		DB::table('transactions')->insert($data3);

        CommonHelper::reconnectMasterDatabase();
        return Redirect::to('sales/viewCashCustomerList?pageType='.Input::get('pageType').'&&parentCode='.Input::get('parentCode').'&&m='.$_GET['m'].'#SFR');
   	}
	
	
	public function addCreditCustomerDetail(){
        CommonHelper::companyDatabaseConnection($_GET['m']);
		
		$account_head = Input::get('account_head');
		$customer_name = Input::get('customer_name');
		$country = Input::get('country');
		$state = Input::get('state');
		$city = Input::get('city');
		$contact_no = Input::get('contact_no');
		$email = Input::get('email');
		$o_blnc_trans = Input::get('o_blnc_trans');
		$o_blnc = Input::get('o_blnc');
		$operational = '1';
		$customer_type = '3';
		$sent_code = $account_head;
		
		$max_id = DB::selectOne('SELECT max(`id`) as id  FROM `accounts` WHERE `parent_code` LIKE \''.$account_head.'\'')->id;
		if($max_id == ''){
        	$code = $sent_code.'-1';
		}else{
			$max_code2 = DB::selectOne('SELECT `code`  FROM `accounts` WHERE `id` LIKE \''.$max_id.'\'')->code;
			$max_code2;
			$max = explode('-',$max_code2);
        	$code = $sent_code.'-'.(end($max)+1);
		}
			
        $level_array = explode('-',$code);
        $counter = 1;
        foreach($level_array as $level):
        	$data1['level'.$counter] = $level;
            $counter++;
       	endforeach;
       	$data1['code'] = $code;
        $data1['name'] = $customer_name;
        $data1['parent_code'] = $account_head;
        $data1['username'] 		 	= Auth::user()->name;
        $data1['date']     		  = date("Y-m-d");
        $data1['time']     		  = date("H:i:s");
        $data1['action']     		  = 'create';
        $data1['operational']		= $operational;
		
		
		$acc_id = DB::table('accounts')->insertGetId($data1);
		
		
		$data2['acc_id']		     = $acc_id;
		$data2['name']     		   = $customer_name;
		$data2['country']     		= $country;
		$data2['province']     	   = $state;
		$data2['city']     	       = $city;
		$data2['contact']   		    = $contact_no;									
		$data2['email']   		      = $email;												
		$data2['username']	 	   = Auth::user()->name;
		$data2['date']     		   = date("Y-m-d");
		$data2['time']     		   = date("H:i:s");			
		$data2['action']     		 = 'create';
		$data2['customer_type']     = $customer_type;
		
		DB::table('customers')->insert($data2);
		
		$data3['acc_id'] =	$acc_id;
        $data3['acc_code']=	$code;
        $data3['debit_credit']=	$o_blnc_trans;
		$data3['amount'] 	  = 	$o_blnc;
        $data3['opening_bal'] 	  = 	1;
       	$data3['username'] 		 	= Auth::user()->name;
        $data3['date']     		  = date("Y-m-d");
        $data3['v_date']     		= date("Y-m-d");
        $data3['time']     		  = date("H:i:s");
        $data3['action']     		  = 'create';
		DB::table('transactions')->insert($data3);

        CommonHelper::reconnectMasterDatabase();
        return Redirect::to('sales/viewCreditCustomerList?pageType='.Input::get('pageType').'&&parentCode='.Input::get('parentCode').'&&m='.$_GET['m'].'#SFR');
   	}

   	public function addCreditSaleVoucherDetail(){
        $m = $_GET['m'];
        CommonHelper::companyDatabaseConnection($_GET['m']);
        $creditSaleSection = Input::get('creditSaleSection');
        foreach ($creditSaleSection as $row){
            $invoice_date = strip_tags(Input::get('invoice_date_'.$row.''));
            $dc_no = strip_tags(Input::get('dc_no_'.$row.''));
            $vehicle_no = strip_tags(Input::get('vehicle_no_'.$row.''));
            $customer_name_id = strip_tags(Input::get('customer_name_id_'.$row.''));
            $credit_acc_id = strip_tags(Input::get('credit_acc_id_'.$row.''));
            $invoice_against_discount = strip_tags(Input::get('invoice_against_discount_'.$row.''));
            $main_description = strip_tags(Input::get('main_description_'.$row.''));
            $creditSaleDataSection = Input::get('creditSaleDataSection_'.$row.'');

            $str = DB::selectOne("select max(convert(substr(`inv_no`,4,length(substr(`inv_no`,4))-4),signed integer)) reg from `invoice` where substr(`inv_no`,-4,2) = ".date('m')." and substr(`inv_no`,-2,2) = ".date('y')."")->reg;
            $inv_no = 'cre'.($str+1).date('my');

            $data1['inv_no']         = $inv_no;
            $data1['dc_no']           = $dc_no;
            $data1['vehicle_no']       = $vehicle_no;
            $data1['invoiceType']       = '3';
            $data1['inv_against_discount'] = $invoice_against_discount;
            $data1['inv_date']         = $invoice_date;
            $data1['consignee']           = $customer_name_id;
            $data1['main_description']       = $main_description;
            $data1['credit_acc_id']       = $credit_acc_id;
            $data1['date']     		  	= date("Y-m-d");
            $data1['time']     		  	= date("H:i:s");
            $data1['username']          = Auth::user()->name;
            $data1['status']            = 1;
            $data1['inv_status']     = 1;

            DB::table('invoice')->insert($data1);
            foreach($creditSaleDataSection as $row2){
                $category_id = strip_tags(Input::get('category_id_'.$row.'_'.$row2.''));
                $sub_item_id = strip_tags(Input::get('sub_item_id_'.$row.'_'.$row2.''));
                $description = strip_tags(Input::get('description_'.$row.'_'.$row2.''));
                $price = strip_tags(Input::get('price_'.$row.'_'.$row2.''));
                $qty = strip_tags(Input::get('qty_'.$row.'_'.$row2.''));
                $amount = strip_tags(Input::get('amount_'.$row.'_'.$row2.''));

                $data2['inv_no']         = $inv_no;
                $data2['inv_date']       = $invoice_date;
                $data2['category_id']       = $category_id;
                $data2['sub_item_id']       = $sub_item_id;
                $data2['description']       = $description;
                $data2['price']               = $price;
                $data2['qty']               = $qty;
                $data2['amount']               = $amount;
                $data2['date']     		  	= date("Y-m-d");
                $data2['time']     		  	= date("H:i:s");
                $data2['username']          = Auth::user()->name;
                $data2['status']            = 1;
                $data2['inv_status']     = 1;

                DB::table('inv_data')->insert($data2);

            }
        }
        CommonHelper::reconnectMasterDatabase();
        return Redirect::to('sales/viewCreditSaleVouchersList?pageType='.Input::get('pageType').'&&parentCode='.Input::get('parentCode').'&&m='.$_GET['m'].'#SFR');
    }

    public function addCashSaleVoucherDetail(){
        $m = $_GET['m'];
        CommonHelper::companyDatabaseConnection($_GET['m']);
        $cashSaleSection = Input::get('cashSaleSection');
        foreach ($cashSaleSection as $row){
            $invoice_date = strip_tags(Input::get('invoice_date_'.$row.''));
            $dc_no = strip_tags(Input::get('dc_no_'.$row.''));
            $vehicle_no = strip_tags(Input::get('vehicle_no_'.$row.''));
            $customer_name_id = strip_tags(Input::get('customer_name_id_'.$row.''));
            $credit_acc_id = strip_tags(Input::get('credit_acc_id_'.$row.''));
            $debit_acc_id = strip_tags(Input::get('debit_acc_id_'.$row.''));
            $invoice_against_discount = strip_tags(Input::get('invoice_against_discount_'.$row.''));
            $main_description = strip_tags(Input::get('main_description_'.$row.''));
            $cashSaleDataSection = Input::get('cashSaleDataSection_'.$row.'');
            $totalAmount = 0;

            $str_inv = DB::selectOne("select max(convert(substr(`inv_no`,4,length(substr(`inv_no`,4))-4),signed integer)) reg from `invoice` where substr(`inv_no`,-4,2) = ".date('m')." and substr(`inv_no`,-2,2) = ".date('y')."")->reg;
            $inv_no = 'cas'.($str_inv+1).date('my');

            $data1['inv_no']         = $inv_no;
            $data1['dc_no']           = $dc_no;
            $data1['vehicle_no']       = $vehicle_no;
            $data1['invoiceType']       = '2';
            $data1['inv_against_discount'] = $invoice_against_discount;
            $data1['inv_date']         = $invoice_date;
            $data1['consignee']           = $customer_name_id;
            $data1['main_description']       = $main_description;
            $data1['credit_acc_id']       = $credit_acc_id;
            $data1['debit_acc_id']       = $debit_acc_id;
            $data1['date']     		  	= date("Y-m-d");
            $data1['time']     		  	= date("H:i:s");
            $data1['username']          = Auth::user()->name;
            $data1['approve_username']          = Auth::user()->name;
            $data1['status']            = 1;
            $data1['inv_status']     = 2;

            $lastId = DB::table('invoice')->insertGetId($data1);
            foreach($cashSaleDataSection as $row2){
                $category_id = strip_tags(Input::get('category_id_'.$row.'_'.$row2.''));
                $sub_item_id = strip_tags(Input::get('sub_item_id_'.$row.'_'.$row2.''));
                $description = strip_tags(Input::get('description_'.$row.'_'.$row2.''));
                $price = strip_tags(Input::get('price_'.$row.'_'.$row2.''));
                $qty = strip_tags(Input::get('qty_'.$row.'_'.$row2.''));
                $amount = strip_tags(Input::get('amount_'.$row.'_'.$row2.''));
                $totalAmount += $amount;

                $data2['inv_no']         = $inv_no;
                $data2['inv_date']       = $invoice_date;
                $data2['category_id']       = $category_id;
                $data2['sub_item_id']       = $sub_item_id;
                $data2['description']       = $description;
                $data2['price']               = $price;
                $data2['qty']               = $qty;
                $data2['amount']               = $amount;
                $data2['date']     		  	= date("Y-m-d");
                $data2['time']     		  	= date("H:i:s");
                $data2['username']          = Auth::user()->name;
                $data2['approve_username']          = Auth::user()->name;
                $data2['status']            = 1;
                $data2['inv_status']     = 2;

                DB::table('inv_data')->insert($data2);

                $data3['inv_no']         = $inv_no;
                $data3['inv_date']       = $invoice_date;
                $data3['main_ic_id']       = $category_id;
                $data3['sub_ic_id']       = $sub_item_id;
                $data3['customer_id'] = $customer_name_id;
                $data3['inv_against_discount'] = $invoice_against_discount;
                $data3['qty']               = $qty;
                $data3['price']               = $price;
                $data3['value']               = $amount;
                $data3['action']               = '5';
                $data3['date']     		  	= date("Y-m-d");
                $data3['time']     		  	= date("H:i:s");
                $data3['username']          = Auth::user()->name;
                $data3['status']            = 1;
                $data3['company_id']     = $m;

                DB::table('fara')->insert($data3);
            }

            $calculatedTotalDiscount = $totalAmount*$invoice_against_discount/100;

            $str_jv = DB::selectOne("select max(convert(substr(`jv_no`,3,length(substr(`jv_no`,3))-4),signed integer)) reg from `jvs` where substr(`jv_no`,-4,2) = ".date('m')." and substr(`jv_no`,-2,2) = ".date('y')."")->reg;
            $jv_no = 'jv'.($str_jv+1).date('my');

            $data_jvs['jv_no'] 	 = $jv_no;
            $data_jvs['jv_date']   = $invoice_date;
            $data_jvs['inv_no'] 	 = $inv_no;
            $data_jvs['inv_date']   = $invoice_date;
            $data_jvs['slip_no'] = $dc_no;
            $data_jvs['description'] 	 = '('.$main_description.') * ( Invoice No  => '.$inv_no.' ) * ( Invoice Date  => '.$invoice_date.' ) * ( Slip No => '.$dc_no.' )';
            $data_jvs['jv_status'] = 2;
            $data_jvs['voucherType'] 	  = 3;
            $data_jvs['status'] 	  = 1;
            $data_jvs['username']  = Auth::user()->name;
            $data_jvs['date'] 	  = date('Y-m-d');
            $data_jvs['time'] 	  = date('H:i:s' );
            $data_jvs['approve_username']   = Auth::user()->name;

            DB::table('jvs')->insert($data_jvs);

            CommonHelper::reconnectMasterDatabase();
            $congsinee_acc = CommonHelper::getAccountIdByMasterTable($m,$customer_name_id,'customers');
            CommonHelper::companyDatabaseConnection($_GET['m']);
            $data_jvdebit['acc_id'] 		= $congsinee_acc;
		    $data_jvdebit['amount'] 		= $totalAmount - $calculatedTotalDiscount;
		    $data_jvdebit['debit_credit']  = '1';
		    $data_jvdebit['jv_no'] 		 = $jv_no;
		    $data_jvdebit['jv_date'] 		 = $invoice_date;
		    $data_jvdebit['description'] = '('.$main_description.') * ( Invoice No  => '.$inv_no.' ) * ( Invoice Date  => '.$invoice_date.' ) * ( Slip No => '.$dc_no.' )';
		    $data_jvdebit['username']  = Auth::user()->name;
            $data_jvdebit['date'] 	  = date('Y-m-d');
            $data_jvdebit['time'] 	  = date('H:i:s' );
            $data_jvdebit['approve_username']   = Auth::user()->name;
            $data_jvdebit['jv_status'] = 2;


		    $data_jvcredit['acc_id'] 	   = $credit_acc_id;
		    $data_jvcredit['amount'] 		= $totalAmount - $calculatedTotalDiscount;
		    $data_jvcredit['debit_credit']  = '0';
		    $data_jvcredit['jv_no'] 		 = $jv_no;
		    $data_jvcredit['jv_date'] 		 = $invoice_date;
		    $data_jvcredit['description'] = '('.$main_description.') * ( Invoice No  => '.$inv_no.' ) * ( Invoice Date  => '.$invoice_date.' ) * ( Slip No => '.$dc_no.' )';
		    $data_jvcredit['username']  = Auth::user()->name;
            $data_jvcredit['date'] 	  = date('Y-m-d');
            $data_jvcredit['time'] 	  = date('H:i:s' );
            $data_jvcredit['approve_username']   = Auth::user()->name;
            $data_jvcredit['jv_status'] = 2;

            DB::table('jv_data')->insert($data_jvdebit);
            DB::table('jv_data')->insert($data_jvcredit);

            $jvsDataDetail = DB::table('jv_data')
                ->where('jv_no', $jv_no)
                ->where('jv_status', '2')->get();
            foreach ($jvsDataDetail as $jvRow){
                $jvdata['acc_id'] = $jvRow->acc_id;
                CommonHelper::reconnectMasterDatabase();
                $jvdata['acc_code'] = FinanceHelper::getAccountCodeByAccId($jvRow->acc_id,$m);
                CommonHelper::companyDatabaseConnection($_GET['m']);
                $jvdata['particulars'] = $jvRow->description;
                $jvdata['opening_bal'] = '0';
                $jvdata['debit_credit'] = $jvRow->debit_credit;
                $jvdata['amount'] = $jvRow->amount;
                $jvdata['voucher_no'] = $jvRow->jv_no;
                $jvdata['voucher_type'] = 1;
                $jvdata['v_date'] = $jvRow->jv_date;
                $jvdata['date'] = date("Y-m-d");
                $jvdata['time'] = date("H:i:s");
                $jvdata['username'] = Auth::user()->name;

                DB::table('transactions')->insert($jvdata);
            }


            $str_rv = DB::selectOne("select max(convert(substr(`rv_no`,4,length(substr(`rv_no`,4))-4),signed integer)) reg from `rvs` where substr(`rv_no`,-4,2) = ".date('m')." and substr(`rv_no`,-2,2) = ".date('y')."")->reg;
            $rv_no = 'crv'.($str_rv+1).date('my');

            $data_rvs['rv_no'] 	 = $rv_no;
            $data_rvs['rv_date']   = $invoice_date;
            $data_rvs['inv_no'] 	 = $inv_no;
            $data_rvs['inv_date']   = $invoice_date;
            $data_rvs['slip_no'] = $dc_no;
            $data_rvs['description'] 	 = '('.$main_description.') * ( Invoice No  => '.$inv_no.' ) * ( Invoice Date  => '.$invoice_date.' ) * ( Slip No => '.$dc_no.' )';
            $data_rvs['rv_status'] = 2;
            $data_rvs['voucherType'] 	  = 3;
            $data_rvs['sale_receipt_type'] 	  = 1;
            $data_rvs['status'] 	  = 1;
            $data_rvs['username']  = Auth::user()->name;
            $data_rvs['date'] 	  = date('Y-m-d');
            $data_rvs['time'] 	  = date('H:i:s' );
            $data_rvs['approve_username']   = Auth::user()->name;

            DB::table('rvs')->insert($data_rvs);

            $data_rvdebit['acc_id'] 		= $congsinee_acc;
		    $data_rvdebit['amount'] 		= $totalAmount - $calculatedTotalDiscount;
		    $data_rvdebit['debit_credit']  = '0';
		    $data_rvdebit['rv_no'] 		 = $rv_no;
            $data_rvdebit['description'] = '('.$main_description.') * ( Invoice No  => '.$inv_no.' ) * ( Invoice Date  => '.$invoice_date.' ) * ( Slip No => '.$dc_no.' )';
		    $data_rvdebit['rv_date'] 	 = $invoice_date;
		    $data_rvdebit['rv_status'] = 2;
            $data_rvdebit['status'] 	  = 1;
            $data_rvdebit['username']  = Auth::user()->name;
            $data_rvdebit['date'] 	  = date('Y-m-d');
            $data_rvdebit['time'] 	  = date('H:i:s' );
            $data_rvdebit['approve_username']   = Auth::user()->name;

            DB::table('rv_data')->insert($data_rvdebit);

		    $data_rvcredit['acc_id'] 	   = $debit_acc_id;
		    $data_rvcredit['amount'] 	   = $totalAmount - $calculatedTotalDiscount;
		    $data_rvcredit['debit_credit'] = '1';
		    $data_rvcredit['rv_no'] 	 	= $rv_no;
		    $data_rvcredit['rv_date'] 	 = $invoice_date;
            $data_rvcredit['description'] = '('.$main_description.') * ( Invoice No  => '.$inv_no.' ) * ( Invoice Date  => '.$invoice_date.' ) * ( Slip No => '.$dc_no.' )';
		    $data_rvcredit['rv_status'] = 2;
            $data_rvcredit['status'] 	  = 1;
            $data_rvcredit['username']  = Auth::user()->name;
            $data_rvcredit['date'] 	  = date('Y-m-d');
            $data_rvcredit['time'] 	  = date('H:i:s' );
            $data_rvcredit['approve_username']   = Auth::user()->name;

            DB::table('rv_data')->insert($data_rvcredit);

            $rvsDataDetail = DB::table('rv_data')
                ->where('rv_no', $rv_no)
                ->where('rv_status', '2')->get();
            foreach ($rvsDataDetail as $rvRow){
                $rvdata['acc_id'] = $rvRow->acc_id;
                CommonHelper::reconnectMasterDatabase();
                $rvdata['acc_code'] = FinanceHelper::getAccountCodeByAccId($rvRow->acc_id,$m);
                CommonHelper::companyDatabaseConnection($_GET['m']);
                $rvdata['particulars'] = $rvRow->description;
                $rvdata['opening_bal'] = '0';
                $rvdata['debit_credit'] = $rvRow->debit_credit;
                $rvdata['amount'] = $rvRow->amount;
                $rvdata['voucher_no'] = $rvRow->rv_no;
                $rvdata['voucher_type'] = 3;
                $rvdata['v_date'] = $rvRow->rv_date;
                $rvdata['date'] = date("Y-m-d");
                $rvdata['time'] = date("H:i:s");
                $rvdata['username'] = Auth::user()->name;

                DB::table('transactions')->insert($rvdata);
            }
        }
        CommonHelper::reconnectMasterDatabase();
        return Redirect::to('sales/viewCashSaleVouchersList?pageType='.Input::get('pageType').'&&parentCode='.Input::get('parentCode').'&&m='.$_GET['m'].'#SFR');
    }
}
