<?php
$accType = Auth::user()->acc_type;
$m = Input::get('m');

use App\Helpers\HrHelper;
use App\Helpers\CommonHelper;
$counter = '1';

?>


<div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="well">
            <div class="row">
                <input type="hidden" name="_token" value="{{ csrf_token() }}">
                <input type="hidden" name="m" value="{{ $m }}">
                <input type="hidden" name="employeeSection[]" id="employeeSection" value="1" />
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                    <div class="panel">
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="table-responsive">
                                        <table class="table table-bordered sf-table-list" id="LeaveTypeList">
                                            <thead>
                                            <th class="text-center col-sm-1">S.No</th>
                                            <th class="text-center hidden-print">Action</th>
                                            </thead>
                                            <tbody>
                                            @if($promotion_letter->count() > 0)
                                                @foreach ($promotion_letter->get() as $value)
                                                    <?php $url1 = url('/').Storage::url($value->file_path); ?>
                                                    <tr class="remove_row_<?=$value->id?>">
                                                        <input id="path_<?=$value->id?>" type="hidden" value="<?=$url1?>">
                                                        <td class="text-center"><span class="badge badge-pill badge-secondary">{{$counter++}}</span></td>
                                                        <td class="text-center">
                                                            <button data-toggle="tooltip" data-placement="right" title="Delete" onclick="deleteEmployeeDocument('<?= $m ?>','<?=$value->id?>')" class="btn btn-xs btn-danger" type="button">
                                                                Delete
                                                            </button>
                                                        </td>
                                                    </tr>

                                                    <tr class="remove_row_<?=$value->id?>">
                                                        <td class="text-center" colspan="5">
                                                            <?php $url = url('/').Storage::url($value->file_path);?>
                                                            @if($value->file_type == 'doc' || $value->file_type == 'docx')
                                                                <iframe height="789" style="width: 100%" src="https://docs.google.com/gview?url=<?=$url?>&embedded=true"></iframe>
                                                            @elseif($value->file_type == 'pdf')
                                                                <embed src="https://drive.google.com/viewerng/viewer?embedded=true&url=<?=$url?>" style="width: 100%" height="789">
                                                            @elseif($value->file_type == 'jpeg' || $value->file_type == 'jpg' || $value->file_type == 'png' || $value->file_type == 'PNG' || $value->file_type == 'gif')
                                                                <img style="width: 100%;" src="{{$url}}">
                                                            @endif
                                                        </td>
                                                    </tr>
                                            @endforeach
                                            @else
                                                <tr><td class="text-center" style="color: red" colspan="2">No Record Found</td></tr>
                                            @endif
                                        </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    function deleteEmployeeDocument(company_id,recordId) {
        var data = {'companyId':company_id,'recordId':recordId};
        var url= '<?php echo url('/')?>/cdOne/deletePromotionLetter';
        $.get(url,data, function(result){
            $(".remove_row_"+recordId).fadeOut();
        });
    }
</script>
