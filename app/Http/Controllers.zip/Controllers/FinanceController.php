<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use Illuminate\Http\Request;
use App\category;
use App\Models\Account;
use App\Models\Jvs;
use App\Models\Jvs_data;
use App\Models\Pvs;
use App\Models\Employee;
use App\Models\Pvs_data;
use App\Models\Rvs;
use App\Models\Rvs_data;
use App\Models\GRNData;
use App\Models\InvoiceData;
use App\Models\Invoice;
use App\Models\Department;
use App\Models\Tax;
use App\Models\Eobi;
use App\Models\PurchaseVoucher;
use App\Helpers\FinanceHelper;
use App\Models\FinanceDepartment;
use App\Models\CostCenter;
use App\Helpers\CommonHelper;
use Input;
use Auth;
use DB;
use Config;
class FinanceController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */

   	public function toDayActivity(){
   		return view('Finance.toDayActivity');
   	}
	public function createDepartmentForm(){

		$department=new FinanceDepartment();
		$department=$department->SetConnection('mysql2');
		$department=$department->where('status',1)
			->orderBy('level1', 'ASC')
			->orderBy('level2', 'ASC')
			->orderBy('level3', 'ASC')
			->orderBy('level4', 'ASC')
			->orderBy('level5', 'ASC')
			->get();
		return view('Finance.createDepartmentForm',compact('department'));
	}

	public function createCostCenterForm(){

		$cost_center=new CostCenter();
		$cost_center=$cost_center->SetConnection('mysql2');
		$cost_center=$cost_center->where('status',1)
			->orderBy('level1', 'ASC')
			->orderBy('level2', 'ASC')
			->orderBy('level3', 'ASC')
			->orderBy('level4', 'ASC')
			->orderBy('level5', 'ASC')
			->get();
		return view('Finance.createCostCenterForm',compact('cost_center'));
	}

	public function viewDepartmentList()
	{
		$department=new FinanceDepartment();
		$department=$department->SetConnection('mysql2');
		$department=$department->where('status',1)->select('name','code')
			->orderBy('level1', 'ASC')
			->orderBy('level2', 'ASC')
			->orderBy('level3', 'ASC')
			->orderBy('level4', 'ASC')
			->orderBy('level5', 'ASC')
			->get();
		return view('Finance.viewDepartmentList',compact('department'));
	}

	public function viewCostCenterList()
	{
		$cost_center=new CostCenter();
		$cost_center=$cost_center->SetConnection('mysql2');
		$cost_center=$cost_center->where('status',1)->select('name','code')
			->orderBy('level1', 'ASC')
			->orderBy('level2', 'ASC')
			->orderBy('level3', 'ASC')
			->orderBy('level4', 'ASC')
			->orderBy('level5', 'ASC')
			->get();
		return view('Finance.viewCostCenterList',compact('cost_center'));
	}
	public function viewChartofAccountList(){
        CommonHelper::companyDatabaseConnection($_GET['m']);
		$accounts = new Account;
		$accounts = $accounts->where('status',1)->orderBy('level1', 'ASC')
    				->orderBy('level2', 'ASC')
					->orderBy('level3', 'ASC')
					->orderBy('level4', 'ASC')
					->orderBy('level5', 'ASC')
					->orderBy('level6', 'ASC')
					->orderBy('level7', 'ASC')
    				->get();
		
   		return view('Finance.viewChartofAccountList',compact('accounts'));
        CommonHelper::reconnectMasterDatabase();
   	}
	
	public function createAccountForm(){
	
        CommonHelper::companyDatabaseConnection($_GET['m']);
		$accounts = new Account;
		$accounts = $accounts::orderBy('level1', 'ASC')
    				->orderBy('level2', 'ASC')
					->orderBy('level3', 'ASC')
					->orderBy('level4', 'ASC')
					->orderBy('level5', 'ASC')
					->orderBy('level6', 'ASC')
					->orderBy('level7', 'ASC')
    				->get();
   		return view('Finance.createAccountForm',compact('accounts'));
        CommonHelper::reconnectMasterDatabase();
   	}
	
	public function ccoa(){
		return view('Finance.ccoa');
	}
	
	public function ccoa_detail(){
        CommonHelper::companyDatabaseConnection($_GET['m']);
		$category = new category;
		$category->name = Input::get('cName');
		$category->save();
		return view('Finance.ccoa');
        CommonHelper::reconnectMasterDatabase();
	}

    public function createJournalVoucherForm(){
        CommonHelper::companyDatabaseConnection($_GET['m']);
        $accounts = new Account;
        $accounts = $accounts::orderBy('level1', 'ASC')
            ->orderBy('level2', 'ASC')
            ->orderBy('level3', 'ASC')
            ->orderBy('level4', 'ASC')
            ->orderBy('level5', 'ASC')
            ->orderBy('level6', 'ASC')
            ->orderBy('level7', 'ASC')
            ->get();
        CommonHelper::reconnectMasterDatabase();
        return view('Finance.createJournalVoucherForm',compact('accounts'));

    }

    public function viewJournalVoucherList(){
        CommonHelper::companyDatabaseConnection($_GET['m']);
        $currentMonthStartDate = date('Y-m-01');
        $currentMonthEndDate   = date('Y-m-t');
        $accounts = new Account;
        $accounts = $accounts::orderBy('level1', 'ASC')
            ->orderBy('level2', 'ASC')
            ->orderBy('level3', 'ASC')
            ->orderBy('level4', 'ASC')
            ->orderBy('level5', 'ASC')
            ->orderBy('level6', 'ASC')
            ->orderBy('level7', 'ASC')
            ->get();
        $jvs = new Jvs;
        $jvs = $jvs::whereBetween('jv_date',[$currentMonthStartDate,$currentMonthEndDate])
            ->where('voucherType','=','1')
            ->where('status','=','1')
            ->get();
        CommonHelper::reconnectMasterDatabase();
        return view('Finance.viewJournalVoucherList',compact('accounts','jvs'));
    }

    public function editJournalVoucherForm(){
        CommonHelper::companyDatabaseConnection($_GET['m']);
        $accounts = new Account;
        $accounts = $accounts::orderBy('level1', 'ASC')
            ->orderBy('level2', 'ASC')
            ->orderBy('level3', 'ASC')
            ->orderBy('level4', 'ASC')
            ->orderBy('level5', 'ASC')
            ->orderBy('level6', 'ASC')
            ->orderBy('level7', 'ASC')
            ->get();
        CommonHelper::reconnectMasterDatabase();
        return view('Finance.editJournalVoucherForm',compact('accounts'));

    }
	
	public function createCashPaymentVoucherForm(){
        CommonHelper::companyDatabaseConnection($_GET['m']);
		$accounts = new Account;
		$accounts = $accounts::orderBy('level1', 'ASC')
    				->orderBy('level2', 'ASC')
					->orderBy('level3', 'ASC')
					->orderBy('level4', 'ASC')
					->orderBy('level5', 'ASC')
					->orderBy('level6', 'ASC')
					->orderBy('level7', 'ASC')
    				->get();
        CommonHelper::reconnectMasterDatabase();
   		return view('Finance.createCashPaymentVoucherForm',compact('accounts'));

   	}
	
	public function viewCashPaymentVoucherList(){
        CommonHelper::companyDatabaseConnection($_GET['m']);
		$currentMonthStartDate = date('Y-m-01');
    	$currentMonthEndDate   = date('Y-m-t');
		$accounts = new Account;
		$accounts = $accounts::orderBy('level1', 'ASC')
    				->orderBy('level2', 'ASC')
					->orderBy('level3', 'ASC')
					->orderBy('level4', 'ASC')
					->orderBy('level5', 'ASC')
					->orderBy('level6', 'ASC')
					->orderBy('level7', 'ASC')
    				->get();
		$pvs = new Pvs;
		$pvs = $pvs::whereBetween('pv_date',[$currentMonthStartDate,$currentMonthEndDate])
					 ->where('voucherType','=','1')
					 ->where('status','=','1')
					 ->get();
        CommonHelper::reconnectMasterDatabase();
		return view('Finance.viewCashPaymentVoucherList',compact('accounts','pvs'));
	}

	public function editCashPaymentVoucherForm(){
        CommonHelper::companyDatabaseConnection($_GET['m']);
		$accounts = new Account;
		$accounts = $accounts::orderBy('level1', 'ASC')
    				->orderBy('level2', 'ASC')
					->orderBy('level3', 'ASC')
					->orderBy('level4', 'ASC')
					->orderBy('level5', 'ASC')
					->orderBy('level6', 'ASC')
					->orderBy('level7', 'ASC')
    				->get();
        CommonHelper::reconnectMasterDatabase();
   		return view('Finance.editCashPaymentVoucherForm',compact('accounts'));

   	}

	
	public function createBankPaymentVoucherForm(){
        CommonHelper::companyDatabaseConnection($_GET['m']);
		$accounts = new Account;
		$accounts = $accounts::orderBy('level1', 'ASC')
    				->orderBy('level2', 'ASC')
					->orderBy('level3', 'ASC')
					->orderBy('level4', 'ASC')
					->orderBy('level5', 'ASC')
					->orderBy('level6', 'ASC')
					->orderBy('level7', 'ASC')
    				->get();
        CommonHelper::reconnectMasterDatabase();
   		return view('Finance.createBankPaymentVoucherForm',compact('accounts'));

   	}
	
	public function viewBankPaymentVoucherList(){
        CommonHelper::companyDatabaseConnection($_GET['m']);
		$currentMonthStartDate = date('Y-m-01');
    	$currentMonthEndDate   = date('Y-m-t');
		$accounts = new Account;
		$accounts = $accounts::orderBy('level1', 'ASC')
    				->orderBy('level2', 'ASC')
					->orderBy('level3', 'ASC')
					->orderBy('level4', 'ASC')
					->orderBy('level5', 'ASC')
					->orderBy('level6', 'ASC')
					->orderBy('level7', 'ASC')
    				->get();
		$pvs = new Pvs;
		$pvs = $pvs::whereBetween('pv_date',[$currentMonthStartDate,$currentMonthEndDate])
					 ->where('voucherType','=','2')
					 ->get();
        CommonHelper::reconnectMasterDatabase();
		return view('Finance.viewBankPaymentVoucherList',compact('accounts','pvs'));
	}

	public function editBankPaymentVoucherForm(){
        CommonHelper::companyDatabaseConnection($_GET['m']);
		$accounts = new Account;
		$accounts = $accounts::orderBy('level1', 'ASC')
    				->orderBy('level2', 'ASC')
					->orderBy('level3', 'ASC')
					->orderBy('level4', 'ASC')
					->orderBy('level5', 'ASC')
					->orderBy('level6', 'ASC')
					->orderBy('level7', 'ASC')
    				->get();
        CommonHelper::reconnectMasterDatabase();
   		return view('Finance.editBankPaymentVoucherForm',compact('accounts'));

   	}
	
	public function createCashReceiptVoucherForm(){
        CommonHelper::companyDatabaseConnection($_GET['m']);
		$accounts = new Account;
		$accounts = $accounts::orderBy('level1', 'ASC')
    				->orderBy('level2', 'ASC')
					->orderBy('level3', 'ASC')
					->orderBy('level4', 'ASC')
					->orderBy('level5', 'ASC')
					->orderBy('level6', 'ASC')
					->orderBy('level7', 'ASC')
    				->get();
        CommonHelper::reconnectMasterDatabase();
   		return view('Finance.createCashReceiptVoucherForm',compact('accounts'));
	}
	
	public function viewCashReceiptVoucherList(){
        CommonHelper::companyDatabaseConnection($_GET['m']);
		$currentMonthStartDate = date('Y-m-01');
    	$currentMonthEndDate   = date('Y-m-t');
		$accounts = new Account;
		$accounts = $accounts::orderBy('level1', 'ASC')
    				->orderBy('level2', 'ASC')
					->orderBy('level3', 'ASC')
					->orderBy('level4', 'ASC')
					->orderBy('level5', 'ASC')
					->orderBy('level6', 'ASC')
					->orderBy('level7', 'ASC')
    				->get();
		$rvs = new Rvs;
		$rvs = $rvs::whereBetween('rv_date',[$currentMonthStartDate,$currentMonthEndDate])
					 ->where('voucherType','=','1')
					 ->get();
        CommonHelper::reconnectMasterDatabase();
		return view('Finance.viewCashReceiptVoucherList',compact('accounts','rvs'));
	}

	public function editCashReceiptVoucherForm(){
        CommonHelper::companyDatabaseConnection($_GET['m']);
		$accounts = new Account;
		$accounts = $accounts::orderBy('level1', 'ASC')
    				->orderBy('level2', 'ASC')
					->orderBy('level3', 'ASC')
					->orderBy('level4', 'ASC')
					->orderBy('level5', 'ASC')
					->orderBy('level6', 'ASC')
					->orderBy('level7', 'ASC')
    				->get();
        CommonHelper::reconnectMasterDatabase();
   		return view('Finance.editCashReceiptVoucherForm',compact('accounts'));
	}
	
	public function createBankReceiptVoucherForm(){
        CommonHelper::companyDatabaseConnection($_GET['m']);
		$accounts = new Account;
		$accounts = $accounts::orderBy('level1', 'ASC')
    				->orderBy('level2', 'ASC')
					->orderBy('level3', 'ASC')
					->orderBy('level4', 'ASC')
					->orderBy('level5', 'ASC')
					->orderBy('level6', 'ASC')
					->orderBy('level7', 'ASC')
    				->get();
        CommonHelper::reconnectMasterDatabase();
   		return view('Finance.createBankReceiptVoucherForm',compact('accounts'));
	}
	
	public function viewBankReceiptVoucherList(){
        CommonHelper::companyDatabaseConnection($_GET['m']);
		$currentMonthStartDate = date('Y-m-01');
    	$currentMonthEndDate   = date('Y-m-t');
		$accounts = new Account;
		$accounts = $accounts::orderBy('level1', 'ASC')
    				->orderBy('level2', 'ASC')
					->orderBy('level3', 'ASC')
					->orderBy('level4', 'ASC')
					->orderBy('level5', 'ASC')
					->orderBy('level6', 'ASC')
					->orderBy('level7', 'ASC')
    				->get();
		$rvs = new Rvs;
		$rvs = $rvs::whereBetween('rv_date',[$currentMonthStartDate,$currentMonthEndDate])
					 ->where('voucherType','=','2')
					 ->get();
        CommonHelper::reconnectMasterDatabase();
		return view('Finance.viewBankReceiptVoucherList',compact('accounts','rvs'));
	}

	public function editBankReceiptVoucherForm(){
        CommonHelper::companyDatabaseConnection($_GET['m']);
		$accounts = new Account;
		$accounts = $accounts::orderBy('level1', 'ASC')
    				->orderBy('level2', 'ASC')
					->orderBy('level3', 'ASC')
					->orderBy('level4', 'ASC')
					->orderBy('level5', 'ASC')
					->orderBy('level6', 'ASC')
					->orderBy('level7', 'ASC')
    				->get();
        CommonHelper::reconnectMasterDatabase();
   		return view('Finance.editBankReceiptVoucherForm',compact('accounts'));
	}

	public function viewLedgerReport(){
        CommonHelper::companyDatabaseConnection($_GET['m']);
		$accounts = new Account;
		$accounts = $accounts::orderBy('level1', 'ASC')
    				->orderBy('level2', 'ASC')
					->orderBy('level3', 'ASC')
					->orderBy('level4', 'ASC')
					->orderBy('level5', 'ASC')
					->orderBy('level6', 'ASC')
					->orderBy('level7', 'ASC')
    				->get();
        CommonHelper::reconnectMasterDatabase();
   		return view('Finance.viewLedgerReport',compact('accounts'));
	}

	public function createPurchaseCashPaymentVoucherForm(){
        CommonHelper::companyDatabaseConnection($_GET['m']);
        $GRNData = new GRNData;
        $GRNDatas = $GRNData::distinct()->where('grn_status','=','2')->get(['grn_no','grn_date']);
        CommonHelper::reconnectMasterDatabase();

        return view('Finance.createPurchaseCashPaymentVoucherForm',compact('GRNDatas'));
    }

    public function viewPurchaseCashPaymentVoucherList(){
        CommonHelper::companyDatabaseConnection($_GET['m']);
        $currentMonthStartDate = date('Y-m-01');
        $currentMonthEndDate   = date('Y-m-t');
        $accounts = new Account;
        $accounts = $accounts::orderBy('level1', 'ASC')
            ->orderBy('level2', 'ASC')
            ->orderBy('level3', 'ASC')
            ->orderBy('level4', 'ASC')
            ->orderBy('level5', 'ASC')
            ->orderBy('level6', 'ASC')
            ->orderBy('level7', 'ASC')
            ->get();
        $pvs = new Pvs;
        $pvs = $pvs::whereBetween('pv_date',[$currentMonthStartDate,$currentMonthEndDate])
            ->where('voucherType','=','3')
            ->where('status','=','1')
            ->get();
        CommonHelper::reconnectMasterDatabase();
        return view('Finance.viewPurchaseCashPaymentVoucherList',compact('accounts','pvs'));
    }


    public function createPurchaseBankPaymentVoucherForm(){
        CommonHelper::companyDatabaseConnection($_GET['m']);
        $GRNData = new GRNData;
        $GRNDatas = $GRNData::distinct()->where('grn_status','=','2')->get(['grn_no','grn_date']);
        CommonHelper::reconnectMasterDatabase();

        return view('Finance.createPurchaseBankPaymentVoucherForm',compact('GRNDatas'));
    }

    public function viewPurchaseBankPaymentVoucherList(){
        CommonHelper::companyDatabaseConnection($_GET['m']);
        $currentMonthStartDate = date('Y-m-01');
        $currentMonthEndDate   = date('Y-m-t');
        $accounts = new Account;
        $accounts = $accounts::orderBy('level1', 'ASC')
            ->orderBy('level2', 'ASC')
            ->orderBy('level3', 'ASC')
            ->orderBy('level4', 'ASC')
            ->orderBy('level5', 'ASC')
            ->orderBy('level6', 'ASC')
            ->orderBy('level7', 'ASC')
            ->get();
        $pvs = new Pvs;
        $pvs = $pvs::whereBetween('pv_date',[$currentMonthStartDate,$currentMonthEndDate])
            ->where('voucherType','=','4')
            ->where('status','=','1')
            ->get();
        CommonHelper::reconnectMasterDatabase();
        return view('Finance.viewPurchaseBankPaymentVoucherList',compact('accounts','pvs'));
    }

    public function viewSaleCashReceiptVoucherList(){
        return view('Finance.viewSaleCashReceiptVoucherList');
    }

    public function createSaleCashReceiptVoucherForm(){
        CommonHelper::companyDatabaseConnection($_GET['m']);
        $Invoice = new Invoice;
        $Invoices = $Invoice::distinct()->where('inv_status','=','2')->where('invoiceType','=','3')->get(['inv_no','inv_date']);
        CommonHelper::reconnectMasterDatabase();

        return view('Finance.createSaleCashReceiptVoucherForm',compact('Invoices'));
    }

    public function viewSaleBankReceiptVoucherList(){
        return view('Finance.viewSaleBankReceiptVoucherList');
    }

    public function createSaleBankReceiptVoucherForm(){
        CommonHelper::companyDatabaseConnection($_GET['m']);
        $Invoice = new Invoice;
        $Invoices = $Invoice::distinct()->where('inv_status','=','2')->where('invoiceType','=','3')->get(['inv_no','inv_date']);
        CommonHelper::reconnectMasterDatabase();

        return view('Finance.createSaleBankReceiptVoucherForm',compact('Invoices'));
    }

    public function viewPurchaseJournalVoucherList(){
        CommonHelper::companyDatabaseConnection($_GET['m']);
        $currentMonthStartDate = date('Y-m-01');
        $currentMonthEndDate   = date('Y-m-t');
        $accounts = new Account;
        $accounts = $accounts::orderBy('level1', 'ASC')
            ->orderBy('level2', 'ASC')
            ->orderBy('level3', 'ASC')
            ->orderBy('level4', 'ASC')
            ->orderBy('level5', 'ASC')
            ->orderBy('level6', 'ASC')
            ->orderBy('level7', 'ASC')
            ->get();
        CommonHelper::reconnectMasterDatabase();
        return view('Finance.viewPurchaseJournalVoucherList',compact('accounts'));
    }

    public function viewSaleJournalVoucherList(){
        CommonHelper::companyDatabaseConnection($_GET['m']);
        $currentMonthStartDate = date('Y-m-01');
        $currentMonthEndDate   = date('Y-m-t');
        $accounts = new Account;
        $accounts = $accounts::orderBy('level1', 'ASC')
            ->orderBy('level2', 'ASC')
            ->orderBy('level3', 'ASC')
            ->orderBy('level4', 'ASC')
            ->orderBy('level5', 'ASC')
            ->orderBy('level6', 'ASC')
            ->orderBy('level7', 'ASC')
            ->get();
        CommonHelper::reconnectMasterDatabase();
        return view('Finance.viewSaleJournalVoucherList',compact('accounts'));
    }



    public function createEmployeeTaxForm()
    {
        $taxesList = Tax::where([['company_id','=',Input::get('m')],['status','=',1]])->get();
        $departmentList = Department::where([['company_id','=',Input::get('m')],['status','=',1]])->get();

        return view('Finance.createEmployeeTaxForm',compact('taxesList','departmentList'));
    }

    public function viewEmployeeTaxList()
    {

        CommonHelper::companyDatabaseConnection(Input::get('m'));
        $employeeTax = Employee::select('id','emp_name','tax_id','emp_department_id')->where([['status','=',1]])->get();
        CommonHelper::reconnectMasterDatabase();

        return view('Finance.viewEmployeeTaxList',compact('employeeTax'));
    }
    public function editEmployeeTaxDetailForm()
    {

        $taxesList = Tax::where([['company_id','=',Input::get('m')],['status','=',1]])->get();
        $departmentList = Department::where([['company_id','=',Input::get('m')],['status','=',1]])->get();
        CommonHelper::companyDatabaseConnection(Input::get('m'));
        $employeeTax = Employee::select('id','tax_id','emp_department_id')->where([['id','=',Input::get('id')]])->first();
        $employeeList = Employee::select('emp_name','id')->where([['emp_department_id','=',$employeeTax->emp_department_id]])->get();
        CommonHelper::reconnectMasterDatabase();

        return view('Finance.editEmployeeTaxDetailForm',compact('taxesList','departmentList','employeeTax','employeeList'));
    }


    public function createEmployeeEOBIForm()
    {
        $eobiList = Eobi::where([['company_id','=',Input::get('m')],['status','=',1]])->get();

        $departmentList = Department::where([['company_id','=',Input::get('m')],['status','=',1]])->get();

        return view('Finance.createEmployeeEOBIForm',compact('eobiList','departmentList'));
    }

    public function viewEmployeeEOBIList()
    {
        CommonHelper::companyDatabaseConnection(Input::get('m'));
        $employeeTax = Employee::select('id','emp_name','eobi_id','emp_department_id')->where([['status','=',1]])->get();
        CommonHelper::reconnectMasterDatabase();

        return view('Finance.viewEmployeeEOBIList',compact('employeeTax'));
    }

    public function editEmployeeEOBIDetailForm()
    {

        $eobiList = Eobi::where([['company_id','=',Input::get('m')],['status','=',1]])->get();
        $departmentList = Department::where([['company_id','=',Input::get('m')],['status','=',1]])->get();
        CommonHelper::companyDatabaseConnection(Input::get('m'));
        $employeeEobi = Employee::select('id','eobi_id','emp_department_id')->where([['id','=',Input::get('id')]])->first();
        $employeeList = Employee::select('emp_name','id')->where([['emp_department_id','=',$employeeEobi->emp_department_id]])->get();
        CommonHelper::reconnectMasterDatabase();

        return view('Finance.editEmployeeEOBIDetailForm',compact('eobiList','departmentList','employeeEobi','employeeList'));
    }


	public function viewPurchaseVoucherList()
	{

		$purchase_voucher=new PurchaseVoucher();
		$purchase_voucher=$purchase_voucher->SetConnection('mysql2');
		$purchase_voucher=$purchase_voucher->where('status',1)->where('pv_status',1)->select('id','pv_no','purchase_date','due_date','supplier','total_qty','total_rate','total_salesTax','total_salesTax_amount','total_net_amount')->get();
		return view('Finance.viewPurchaseVoucherList',compact('purchase_voucher'));
	}


	public function createPaymentForOutstanding(Request $request)

	{

		$val=$request->checkbox;
		$accounts = new Account;
		$accounts=$accounts->SetConnection('mysql2');
		$accounts = $accounts->where('status',1)->select('id','name','code')->orderBy('level1', 'ASC')
			->orderBy('level2', 'ASC')
			->orderBy('level3', 'ASC')
			->orderBy('level4', 'ASC')
			->orderBy('level5', 'ASC')
			->orderBy('level6', 'ASC')
			->orderBy('level7', 'ASC')
			->get();

		return view('Finance.createPaymentForOutstanding',compact('accounts','val'));

	}
}
