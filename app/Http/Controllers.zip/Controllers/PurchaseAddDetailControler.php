<?php

namespace App\Http\Controllers;
use Illuminate\Database\DatabaseManager;
use App\Http\Requests;
use Illuminate\Http\Request;
use App\Helpers\CommonHelper;
use App\Helpers\PurchaseHelper;
use App\Models\PurchaseVoucher;
use App\Models\PurchaseVoucherData;
use App\Models\Transactions;
use App\Models\DepartmentAllocation1;
use App\Models\SalesTaxDepartmentAllocation;
use App\Models\CostCenterDepartmentAllocation;
use App\Models\DemandType;
use App\Models\Warehouse;
use App\Helpers\FinanceHelper;
use Session;
use Input;
use Auth;
use DB;
use Config;
use Redirect;
class PurchaseAddDetailControler extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');

    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */

    public function addSupplierDetail()
    {

        DB::transaction(function () {
            CommonHelper::companyDatabaseConnection($_GET['m']);
            $account_head = '2-1';
            $supplier_name = Input::get('supplier_name');
            $country = Input::get('country');
            $state = Input::get('state');
            $city = Input::get('city');
            $email = Input::get('email');
            $o_blnc_trans = Input::get('o_blnc_trans');
            $register_income_tax = Input::get('regd_in_income_tax');
            $business_type = Input::get('optradio');
            $ntn = Input::get('ntn');
            $cnic = Input::get('cnic');
            $regd_in_sales_tax = Input::get('regd_in_sales_tax');
            $strn = Input::get('strn');
            $regd_in_srb = Input::get('regd_in_srb');
            $srb = Input::get('srb');
            $regd_in_pra = Input::get('regd_in_pra');
            $pra = Input::get('pra');

            $print_check_as = Input::get('print_check_as');
            $vendor_type = Input::get('vendor_type');
            $website = Input::get('website');
            $credit_limit = Input::get('credit_limit');
            $acc_no = Input::get('acc_no');
            $bank_name = Input::get('bank_name');
            $bank_address = Input::get('bank_address');
            $branch_name = Input::get('branch_name');
            $swift_code = Input::get('swift_code');
            $open_date = Input::get('open_date');


            $address[] = Input::get('address');
            $o_blnc = Input::get('o_blnc');
            $operational = '1';
            $sent_code = '2-1';

            $max_id = DB::selectOne('SELECT max(`id`) as id  FROM `accounts` WHERE `parent_code` LIKE \'' . $account_head . '\'')->id;
            if ($max_id == '') {
                $code = $sent_code . '-1';
            } else {
                $max_code2 = DB::selectOne('SELECT `code`  FROM `accounts` WHERE `id` LIKE \'' . $max_id . '\'')->code;
                $max_code2;
                $max = explode('-', $max_code2);
                $code = $sent_code . '-' . (end($max) + 1);
            }

            $level_array = explode('-', $code);
            $counter = 1;
            foreach ($level_array as $level):
                $data1['level' . $counter] = strip_tags($level);
                $counter++;
            endforeach;
            $data1['code'] = strip_tags($code);
            $data1['name'] = strip_tags($supplier_name);
            $data1['parent_code'] = strip_tags($account_head);
            $data1['username'] = Auth::user()->name;
            $data1['date'] = date("Y-m-d");
            $data1['time'] = date("H:i:s");
            $data1['action'] = 'create';
            $data1['operational'] = strip_tags($operational);
            $acc_id = DB::table('accounts')->insertGetId($data1);


            $data2['acc_id'] = strip_tags($acc_id);
            $data2['resgister_income_tax'] = strip_tags($register_income_tax);
            $data2['business_type'] = strip_tags($business_type);
            $data2['cnic'] = strip_tags($cnic);
            $data2['ntn'] = strip_tags($ntn);
            $data2['register_sales_tax'] = strip_tags($regd_in_sales_tax);
            $data2['strn'] = strip_tags($strn);
            $data2['register_srb'] = strip_tags($regd_in_srb);
            $data2['srb'] = strip_tags($srb);
            $data2['register_pra'] = strip_tags($regd_in_pra);
            $data2['pra'] = strip_tags($pra);
            $data2['name'] = strip_tags($supplier_name);
            $data2['country'] = strip_tags($country);
            $data2['province'] = strip_tags($state);
            $data2['city'] = strip_tags($city);
            $data2['email'] = strip_tags($email);
            $data2['username'] = Auth::user()->name;
            $data2['date'] = date("Y-m-d");
            $data2['time'] = date("H:i:s");
            $data2['action'] = 'create';
            $data2['company_id'] = $_GET['m'];
            $data2['print_check_as'] = $print_check_as;
            $data2['vendor_type'] = $vendor_type;
            $data2['website'] = $website;
            $data2['credit_limit'] = $credit_limit;
            $data2['acc_no'] = $acc_no;
            $data2['bank_name'] = $bank_name;
            $data2['bank_address'] = $bank_address;
            $data2['swift_code'] = $swift_code;
            $data2['branch_name'] = $branch_name;
            $data2['opening_bal_date'] = $open_date;
            $lastInsertedID = DB::table('supplier')->InsertGetId($data2);

            $count1 = count(Input::get('contact_no'));
            $count2 = count(Input::get('address'));
            if ($count1 == $count2):
                $count = $count1;
            else:

                if ($count1 > $count2):
                    $count = $count1;
                else:
                    $count = $count2;
                endif;
            endif;
            $count = $count - 1;

            for ($i = 0; $i <= $count; $i++):
                $data4['supp_id'] = $lastInsertedID;


                $ii = $i + 1;
                if ($count2 >= $ii):


                    $data4['address'] = Input::get('address')[$i];
                else:
                    $data4['address'] = '';
                endif;
                echo $count1 . ' ' . $ii . '</br>';
                if ($count1 >= $ii):


                    $data4['contact_no'] = Input::get('contact_no')[$i];
                else:
                    $data4['contact_no'] = '';
                endif;
                DB::table('supplier_info')->insert($data4);
            endfor;

            $data3['acc_id'] = strip_tags($acc_id);
            $data3['acc_code'] = strip_tags($code);
            $data3['debit_credit'] = 0;
            $data3['amount'] = strip_tags($o_blnc);
            $data3['opening_bal'] = 1;
            $data3['username'] = Auth::user()->name;
            $data3['date'] = date("Y-m-d");
            $data3['v_date'] = date("Y-m-d");

            $data3['action'] = 'create';
            DB::table('transactions')->insert($data3);


        });
        CommonHelper::reconnectMasterDatabase();
        return Redirect::to('purchase/viewSupplierList?pageType=' . Input::get('pageType') . '&&parentCode=' . Input::get('parentCode') . '&&m=' . $_GET['m'] . '#SFR');
    }

    public function addCategoryDetail()
    {
        $m = $_GET['m'];
        $category_name = Input::get('category_name');
        $wip_finish_g_form = 'fara';
        $branch_id = '';
        $username = '';
        $o_blnc_trans = 1;
        $o_blnc = 0;


        $data2['main_ic'] = strip_tags($category_name);
        //   $data2['acc_id']		    = strip_tags($acc_id);
        $data2['type'] = 2;
        $data2['username'] = Auth::user()->name;
        $data2['date'] = date("Y-m-d");
        $data2['time'] = date("H:i:s");
        $data2['action'] = 'create';
        //   $data2['tran_type']		    = strip_tags($tran_type);
        //   $data2['head']		    = $account_head;
        $data2['company_id'] = $m;

        $m_id = DB::connection('mysql2')->table('category')->insertGetId($data2);

        CommonHelper::reconnectMasterDatabase();
        return Redirect::to('purchase/viewCategoryList?pageType=' . Input::get('pageType') . '&&parentCode=' . Input::get('parentCode') . '&&m=' . $_GET['m'] . '#SFR');
        die;

        if ($wip_finish_g_form == 'wip') {
            $tran_type = '1';
        } else if ($wip_finish_g_form == 'finished_goods') {
            $tran_type = '2';
        } else if ($wip_finish_g_form == 'fara') {
            $tran_type = '3';
        }
        CommonHelper::companyDatabaseConnection($_GET['m']);
        $account_head = Input::get('account_head');
        $sent_code = $account_head;
        $max_id = DB::selectOne('SELECT max(`id`) as id  FROM `accounts` WHERE `parent_code` LIKE \'' . $account_head . '\'')->id;
        if ($max_id == '') {
            $code = $sent_code . '-1';
        } else {
            $max_code2 = DB::selectOne('SELECT `code`  FROM `accounts` WHERE `id` LIKE \'' . $max_id . '\'')->code;
            $max_code2;
            $max = explode('-', $max_code2);
            $code = $sent_code . '-' . (end($max) + 1);
        }
        $level_array = explode('-', $code);
        $counter = 1;
        foreach ($level_array as $level):
            $data1['level' . $counter] = strip_tags($level);
            $counter++;
        endforeach;

        $data1['code'] = strip_tags($code);
        $data1['name'] = strip_tags($category_name);
        $data1['parent_code'] = strip_tags($account_head);
        $data1['username'] = Auth::user()->name;
        $data1['date'] = date("Y-m-d");
        $data1['time'] = date("H:i:s");
        $data1['action'] = 'create';
        $data1['operational'] = 1;

        $acc_id = DB::table('accounts')->insertGetId($data1);


        $data3['acc_id'] = strip_tags($acc_id);
        $data3['acc_code'] = strip_tags($code);
        $data3['debit_credit'] = strip_tags($o_blnc_trans);
        $data3['amount'] = strip_tags($o_blnc);
        $data3['opening_bal'] = 1;
        $data3['username'] = Auth::user()->name;
        $data3['date'] = date("Y-m-d");
        $data3['v_date'] = date("Y-m-d");

        $data3['action'] = 'create';
        DB::table('transactions')->insert($data3);

        $data4['main_ic_id'] = strip_tags($m_id);
        $data4['value'] = 0;
        $data4['qty'] = 0;
        $data4['company_id'] = $m;
        $data4['date'] = date("Y-m-d");
        $data4['time'] = date("H:i:s");
        $data4['action'] = '1';//1 for opening
        $data4['username'] = Auth::user()->name;

        DB::table('fara')->insert($data4);

        $data5['type'] = 1;
        DB::table('accounts')->where('id', $account_head)->update($data5);


    }

    public function addSubItemDetail()
    {

        $m = $_GET['m'];
        CommonHelper::companyDatabaseConnection($_GET['m']);

        $category_name = Input::get('category_name');
        $sub_item_name = Input::get('sub_item_name');
        $opening_qty = Input::get('opening_qty');
        $opening_value = Input::get('opening_value');
        $reorder_level = Input::get('reorder_level');
        $pack_size = Input::get('pack_size');
        $desc = Input::get('desc');
        $type = Input::get('type');
        $rate = Input::get('rate');
        $uom = Input::get('uom_id');
        $username = '';
        $branch_id = '';
        $o_blnc_trans_form = 1;
        $wip_finish_g_form = 'fara';

        //    $data2['acc_id']			= strip_tags($acc_id_new);
        $data2['sub_ic'] = strip_tags($sub_item_name);
        $data2['main_ic_id'] = strip_tags($category_name);
        $data2['reorder_level'] = strip_tags($reorder_level);
        $data2['uom'] = strip_tags($uom);
        $data2['rate'] = $rate;
        $data2['pack_size'] = $pack_size;
        $data2['description'] = $desc;
        $data2['itemType'] = $type;
        $data2['username'] = Auth::user()->name;
        $data2['date'] = date("Y-m-d");
        $data2['time'] = date("H:i:s");
        $data2['action'] = 'create';
        $data2['company_id'] = $m;

        $s_id = DB::table('subitem')->insertGetId($data2);
        CommonHelper::reconnectMasterDatabase();
        return Redirect::to('purchase/viewSubItemList?pageType=' . Input::get('pageType') . '&&parentCode=' . Input::get('parentCode') . '&&m=' . $_GET['m'] . '#SFR');

        die;
        $acc_id = DB::selectOne('select `acc_id` from `category` where `id` = ' . $category_name . '')->acc_id;
        $parent_code = DB::selectOne('select code from `accounts` where `id` = ' . $acc_id . '')->code;
        $max_id = DB::selectOne('SELECT max(`id`) as id  FROM `accounts` WHERE `parent_code` LIKE \'' . $parent_code . '\'')->id;
        if ($max_id == '') {
            $code = $parent_code . '-1';
        } else {
            $max_code2 = DB::selectOne('SELECT `code`  FROM `accounts` WHERE `id` LIKE \'' . $max_id . '\'')->code;
            $max_code2;
            $max = explode('-', $max_code2);
            $code = $parent_code . '-' . (end($max) + 1);
        }
        $level_array = explode('-', $code);
        $counter = 1;
        foreach ($level_array as $level):
            $data1['level' . $counter] = strip_tags($level);
            $counter++;
        endforeach;

        $data1['code'] = strip_tags($code);
        $data1['name'] = strip_tags($sub_item_name);
        $data1['parent_code'] = strip_tags($parent_code);
        $data1['username'] = Auth::user()->name;
        $data1['date'] = date("Y-m-d");
        $data1['time'] = date("H:i:s");
        $data1['action'] = 'create';
        $data1['operational'] = 1;


        $acc_id_new = DB::table('accounts')->insertGetId($data1);


        $data3['acc_code'] = strip_tags($code);
        $data3['acc_id'] = strip_tags($acc_id_new);
        $data3['debit_credit'] = 1;
        $data3['opening_bal'] = 1;
        $data3['username'] = Auth::user()->name;
        $data3['v_date'] = date("Y-m-d");
        $data3['date'] = date("Y-m-d");

        $data3['action'] = 'create';
        $data3['status'] = 1;
        $data3['amount'] = $opening_value;

        DB::table('transactions')->insert($data3);

        $data4['main_ic_id'] = strip_tags($category_name);
        $data4['sub_ic_id'] = strip_tags($s_id);
        $data4['value'] = $opening_value;
        $data4['qty'] = strip_tags($opening_qty);
        $data4['date'] = date("Y-m-d");
        $data4['time'] = date("H:i:s");
        $data4['action'] = '1';//1 for opening
        $data4['username'] = Auth::user()->name;
        $data4['date'] = date("Y-m-d");
        $data4['time'] = date("H:i:s");
        $data4['company_id'] = $m;

        DB::table('fara')->insert($data4);


    }

    public function addUOMDetail()
    {
        $uomName = Input::get('uom_name');
        $data1['uom_name'] = strip_tags($uomName);
        $data1['username'] = Auth::user()->name;
        $data1['company_id'] = $_GET['m'];
        $data1['date'] = date("Y-m-d");
        $data1['time'] = date("H:i:s");

        DB::table('uom')->insert($data1);
        return Redirect::to('purchase/viewUOMList?pageType=' . Input::get('pageType') . '&&parentCode=' . Input::get('parentCode') . '&&m=' . $_GET['m'] . '#SFR');
    }

    public function addDemandDetail()
    {
        $m = $_GET['m'];
        CommonHelper::companyDatabaseConnection($_GET['m']);
        $demandsSection = Input::get('demandsSection');
        foreach ($demandsSection as $row) {
            $slip_no = strip_tags(Input::get('slip_no_' . $row . ''));
            $demand_date = strip_tags(Input::get('demand_date_' . $row . ''));
            $demand_type = strip_tags(Input::get('demand_type'));
            $description = strip_tags(Input::get('description_' . $row . ''));
            $sub_department_id = strip_tags(Input::get('sub_department_id_' . $row . ''));
            $demandDataSection = Input::get('demandDataSection_' . $row . '');

            $str = DB::selectOne("select max(convert(substr(`demand_no`,3,length(substr(`demand_no`,3))-4),signed integer)) reg from `demand` where substr(`demand_no`,-4,2) = " . date('m') . " and substr(`demand_no`,-2,2) = " . date('y') . "")->reg;
            $demand_no = 'pr' . ($str + 1) . date('my');

            $data1['demand_no'] = $demand_no;
            $data1['slip_no'] = $slip_no;

            $data1['demand_date'] = $demand_date;
            $data1['description'] = $description;
            $data1['sub_department_id'] = $sub_department_id;
            $data1['date'] = date("Y-m-d");
            $data1['time'] = date("H:i:s");
            $data1['username'] = Auth::user()->name;
            $data1['status'] = 1;
            $data1['demand_status'] = 1;

          //  DB::table('demand')->insert($data1);
            $master_id = DB::table('demand')->insertGetId($data1);
            foreach ($demandDataSection as $row2) {
                $category_id = strip_tags(Input::get('category_id_' . $row . '_' . $row2 . ''));
                $sub_item_id = strip_tags(Input::get('sub_item_id_' . $row . '_' . $row2 . ''));
                $description = strip_tags(Input::get('description_' . $row . '_' . $row2 . ''));
                $demand_type_id = strip_tags(Input::get('demand_type_id_' . $row . '_' . $row2 . ''));
                $qty = strip_tags(Input::get('qty_' . $row . '_' . $row2 . ''));

                $data2['demand_no'] = $demand_no;
                $data2['master_id'] = $master_id;
                $data2['demand_send_type'] = $demand_type_id;
                $data2['demand_date'] = $demand_date;
                $data2['category_id'] = $category_id;
                $data2['sub_item_id'] = $sub_item_id;
                $data2['description'] = $description;
                $data2['qty'] = $qty;
                $data2['date'] = date("Y-m-d");
                $data2['time'] = date("H:i:s");
                $data2['username'] = Auth::user()->name;
                $data2['status'] = 1;
                $data2['demand_status'] = 1;

                DB::table('demand_data')->insert($data2);

            }
        }
        CommonHelper::reconnectMasterDatabase();
        return Redirect::to('purchase/viewDemandList?pageType=' . Input::get('pageType') . '&&parentCode=' . Input::get('parentCode') . '&&m=' . $_GET['m'] . '#SFR');
    }

    public function addGoodsReceiptNoteDetail()
    {
        $m = $_GET['m'];
        CommonHelper::companyDatabaseConnection($_GET['m']);

        $str = DB::selectOne("select max(convert(substr(`grn_no`,4,length(substr(`grn_no`,4))-4),signed integer)) reg from `goods_receipt_note` where substr(`grn_no`,-4,2) = " . date('m') . " and substr(`grn_no`,-2,2) = " . date('y') . "")->reg;
        $grn_no = 'grn' . ($str + 1) . date('my');

        $prNo = strip_tags(Input::get('prNo'));
        $prDate = strip_tags(Input::get('prDate'));
        $subDepartmentId = strip_tags(Input::get('subDepartmentId'));
        $supplierId = strip_tags(Input::get('supplierId'));
        $invoice_no = strip_tags(Input::get('invoice_no'));
        $grn_date = strip_tags(Input::get('grn_date'));
        $main_description = strip_tags(Input::get('main_description'));
        $delivery_challan_no=strip_tags(Input::get('del_chal_no'));
        $delivery_vehicale=strip_tags(Input::get('del_detail'));
        $warehouse=strip_tags(Input::get('warehouse_id'));

        //  $mainDemandType = strip_tags(Input::get('demandType'));

        $data1['grn_no'] = $grn_no;
        $data1['grn_date'] = $grn_date;
        $data1['po_no'] = $prNo;
        $data1['po_date'] = $prDate;

        // $data1['demand_type'] = $mainDemandType;
        $data1['sub_department_id'] = $subDepartmentId;
        $data1['supplier_id'] = $supplierId;
        $data1['main_description'] = $main_description;
        $data1['supplier_invoice_no'] = $invoice_no;
        $data1['delivery_challan_no'] = $delivery_challan_no;
        $data1['delivery_detail'] = $delivery_vehicale;
        $data1['warehouse'] = $warehouse;
        $data1['date'] = date("Y-m-d");
        $data1['time'] = date("H:i:s");

        $data1['username'] = Auth::user()->name;

        DB::table('goods_receipt_note')->insert($data1);

        $seletedPurchaseRequestRow = Input::get('seletedPurchaseRequestRow');
        foreach ($seletedPurchaseRequestRow as $row1)
        {

            $demandSendType = strip_tags(Input::get('demandSendType_' . $row1 . ''));
            $category_id = strip_tags(Input::get('categoryId_' . $row1 . ''));
            $sub_item_id = strip_tags(Input::get('subItemId_' . $row1 . ''));
            $purchase_approved_qty = strip_tags(Input::get('approved_qty_' . $row1 . ''));
            $purchase_recived_qty = strip_tags(Input::get('qty_recived_' . $row1 . ''));
            $balance_qty_recived = strip_tags(Input::get('balqty_' . $row1 . ''));
            $remarks = strip_tags(Input::get('description_' . $row1 . ''));
            $manufac_date = strip_tags(Input::get('maufac_date_' . $row1 . ''));
            $expiry_date = strip_tags(Input::get('expiry_date_' . $row1 . ''));
            $batch_no = strip_tags(Input::get('batch_no_' . $row1 . ''));
            $no_pack = strip_tags(Input::get('no_pack_per_item_' . $row1 . ''));
            $net_gross = strip_tags(Input::get('net_gross_' . $row1 . ''));
            $rate = strip_tags(Input::get('rate_' . $row1 . ''));




            $subTotal = strip_tags(Input::get('purchase_request_sub_total_' . $row1 . ''));
            $receivedQty = strip_tags(Input::get('received_qty_' . $row1 . ''));



            $data2['demand_send_type'] = $demandSendType;
            $data2['grn_no'] = $grn_no;
            $data2['grn_date'] = $grn_date;
            $data2['category_id'] = $category_id;
            $data2['sub_item_id'] = $sub_item_id;
            $data2['purchase_approved_qty'] = $purchase_approved_qty;
            $data2['purchase_recived_qty'] = $purchase_recived_qty;
            $data2['bal_reciable'] = $balance_qty_recived;
            $data2['remarks'] = $remarks;
            $data2['manufac_date'] = $manufac_date;
            $data2['expiry_date'] = $expiry_date;
            $data2['batch_no'] = $batch_no;
            $data2['no_pkg_item'] = $no_pack;
            $data2['net_gross_item'] = $net_gross;
            $data2['rate'] = $rate;
            //    $data2['rate'] = $rate;
            //   $data2['subTotal'] = $subTotal;
            // $data2['receivedQty'] = $receivedQty;
            $data2['date'] = date("Y-m-d");
            $data2['time'] = date("H:i:s");
            $data2['username'] = Auth::user()->name;

            DB::table('grn_data')->insert($data2);



        }

        $data = array(

            'purchase_request_status'=>3
        );
        DB::table('purchase_request')
            ->where('purchase_request_no',$prNo)
            ->where('status',1)
            ->update($data);

        $data4 = array(
            'grn_status' => 2,
            'purchase_request_status'=>3
        );

        DB::table('purchase_request_data')
            ->where('purchase_request_no', $prNo)
            ->where('status',1)
            ->update($data4);
        CommonHelper::reconnectMasterDatabase();
        return Redirect::to('purchase/viewGoodsReceiptNoteList?pageType=' . Input::get('pageType') . '&&parentCode=' . Input::get('parentCode') . '&&m=' . $_GET['m'] . '#SFR');
    }

    public function createStoreChallanandApproveGoodsReceiptNote()
    {
        $m = $_GET['m'];
        CommonHelper::companyDatabaseConnection($_GET['m']);
        $pageType = Input::get('pageType');
        $parentCode = Input::get('parentCode');
        $grnNo = Input::get('grnNo');
        $grnDate = Input::get('grnDate');
        $prNo = Input::get('prNo');
        $prDate = Input::get('prDate');
        $supplier_id = Input::get('supplier_id');


        $updateDetails = array(
            'grn_status' => 2,
            'approve_username' => Auth::user()->name
        );

        DB::table('goods_receipt_note')
            ->where('grn_no', $grnNo)
            ->update($updateDetails);

        DB::table('grn_data')
            ->where('grn_no', $grnNo)
            ->update($updateDetails);


        $secondTableRecord = DB::table('grn_data')->where('grn_no', '=', $grnNo)->get();
        foreach ($secondTableRecord as $row) {
            $action = '3';
            $qty = $row->receivedQty;
            $value = $row->subTotal;
            $tableThree = 'fara';

            $data['grn_no'] = $grnNo;
            $data['grn_date'] = $grnDate;
            $data['pr_no'] = $prNo;
            $data['pr_date'] = $prDate;
            $data['supp_id'] = $supplier_id;
            $data['main_ic_id'] = $row->category_id;
            $data['sub_ic_id'] = $row->sub_item_id;
            $data['demand_type'] = $row->demand_type;
            $data['demand_send_type'] = $row->demand_send_type;
            $data['main_ic_id'] = $row->category_id;
            $data['sub_ic_id'] = $row->sub_item_id;
            $data['qty'] = $qty;
            $data['value'] = $value;
            $data['action'] = $action;
            $data['status'] = 1;
            $data['username'] = Auth::user()->name;
            $data['date'] = date("Y-m-d");
            $data['time'] = date("H:i:s");
            $data['company_id'] = $m;
            DB::table($tableThree)->insert($data);
        }


        $str = DB::selectOne("select max(convert(substr(`store_challan_no`,3,length(substr(`store_challan_no`,3))-4),signed integer)) reg from `store_challan` where substr(`store_challan_no`,-4,2) = " . date('m') . " and substr(`store_challan_no`,-2,2) = " . date('y') . "")->reg;
        $storeChallanNo = 'sc' . ($str + 1) . date('my');
        $slip_no = Input::get('slip_no');
        $departmentId = Input::get('sub_deparment_id');
        $main_description = Input::get('description');

        $data1['slip_no'] = $slip_no;
        $data1['store_challan_no'] = $storeChallanNo;
        $data1['store_challan_date'] = date("Y-m-d");
        $data1['sub_department_id'] = $departmentId;
        $data1['description'] = $main_description;
        $data1['username'] = Auth::user()->name;
        $data1['approve_username'] = Auth::user()->name;
        $data1['date'] = date("Y-m-d");
        $data1['time'] = date("H:i:s");
        $data1['store_challan_status'] = 2;

        DB::table('store_challan')->insert($data1);

        $rowId = Input::get('rowId');
        foreach ($rowId as $row1) {
            $demandNo = Input::get('demandNo_' . $row1 . '');
            $demandDate = Input::get('demandDate_' . $row1 . '');
            $demandType = Input::get('demandType_' . $row1 . '');
            $demandSendType = Input::get('demandSendType_' . $row1 . '');
            $categoryId = Input::get('categoryId_' . $row1 . '');
            $subItemId = Input::get('subItemId_' . $row1 . '');
            $issue_qty = Input::get('issue_qty_' . $row1 . '');
            $demandAndRemainingQty = Input::get('demandAndRemainingQty_' . $row1 . '');
            if ($demandType == 2) {
            } else {
                $data2['store_challan_no'] = $storeChallanNo;
                $data2['store_challan_date'] = date("Y-m-d");
                $data2['demand_no'] = $demandNo;
                $data2['demand_date'] = $demandDate;
                $data2['category_id'] = $categoryId;
                $data2['sub_item_id'] = $subItemId;
                $data2['issue_qty'] = $issue_qty;
                $data2['username'] = Auth::user()->name;
                $data2['approve_username'] = Auth::user()->name;
                $data2['date'] = date("Y-m-d");
                $data2['time'] = date("H:i:s");
                $data2['store_challan_status'] = 2;

                DB::table('store_challan_data')->insert($data2);

                if ($issue_qty == $demandAndRemainingQty) {
                    DB::table('demand_data')
                        ->where('category_id', $categoryId)
                        ->where('sub_item_id', $subItemId)
                        ->where('demand_no', $demandNo)
                        ->update(['store_challan_status' => "2"]);
                }
                $data3['sc_no'] = $storeChallanNo;
                $data3['sc_date'] = date("Y-m-d");
                $data3['demand_no'] = $demandNo;
                $data3['demand_date'] = $demandDate;
                $data3['main_ic_id'] = $categoryId;
                $data3['sub_ic_id'] = $subItemId;
                $data3['qty'] = $issue_qty;
                $data3['value'] = 0;
                $data3['username'] = Auth::user()->name;
                $data3['date'] = date("Y-m-d");
                $data3['time'] = date("H:i:s");
                $data3['action'] = 2;
                $data3['status'] = 1;
                $data3['company_id'] = $m;
                DB::table('fara')->insert($data3);
            }
        }


        CommonHelper::reconnectMasterDatabase();
        return Redirect::to('purchase/viewGoodsReceiptNoteList?pageType=' . Input::get('pageType') . '&&parentCode=' . Input::get('parentCode') . '&&m=' . $_GET['m'] . '#SFR');
    }

    function createPurchaseVoucher(Request $request)
    {
        $cn = DB::connection('mysql2');
        $cn->beginTransaction();
        $str = DB::connection('mysql2')->selectOne("select count(id)id from purchase_voucher where status=1 and purchase_date='" . Input::get('purchase_date') . "'")->id;
        $pv_no = 'pv' . ($str + 1);
        $total_salesTax = str_replace('%', '', $request->total_salesTax);
        $purchase_voucher = new PurchaseVoucher();
        $purchase_voucher = $purchase_voucher->SetConnection('mysql2');
        $purchase_voucher->pv_no = $pv_no;
        $purchase_voucher->slip_no = $request->slip_no;
        $purchase_voucher->purchase_date = $request->purchase_date;
        $purchase_voucher->bill_date = $request->bill_date;
        $purchase_voucher->purchase_type = $request->p_type;
        $purchase_voucher->current_amount = $request->current_amount;
        $purchase_voucher->amount_in_words = $request->rupeess;
        $purchase_voucher->due_date = $request->due_date;
        $purchase_voucher->supplier = $request->supplier;
        $purchase_voucher->total_qty = $request->total_qty;
        $purchase_voucher->total_rate = $request->total_rate;
        $purchase_voucher->total_amount = $request->total_amount;

        $purchase_voucher->total_salesTax_amount = $request->total_salesTax_amount;
        $purchase_voucher->total_net_amount = $request->total_net_amount;
        $purchase_voucher->username = Auth::user()->name;
        $purchase_voucher->date = date('Y-m-d');
        $purchase_voucher->description = $request->description;
        $purchase_voucher->pv_date = $request->purchase_date;
        $purchase_voucher->pv_no = $pv_no;
        $currency = $request->curren;
        $currency = explode(',', $currency);
        $purchase_voucher->currency = $currency[0];
        $purchase_voucher->save();
        $master_id = $purchase_voucher->id;
        $purchase_voucher_dataa = $request->demandDataSection_1;

        $count = 1;
        foreach ($purchase_voucher_dataa as $row):

            $purchase_voucher_data = new PurchaseVoucherData();
            $purchase_voucher_data = $purchase_voucher_data->SetConnection('mysql2');
            $request->input('sales_tax_amount_1_' . $count);
            $purchase_voucher_data->master_id = $master_id;
            $purchase_voucher_data->pv_no = $pv_no;
            $purchase_voucher_data->category_id = $request->input('category_id_1_' . $count);;
            $purchase_voucher_data->sub_item = $request->input('sub_item_id_1_' . $count);;

            $purchase_voucher_data->uom = $request->input('uom_id_1_' . $count);;
            $purchase_voucher_data->qty = $request->input('qty_1_' . $count);;
            $purchase_voucher_data->rate = $request->input('rate_1_' . $count);;
            $purchase_voucher_data->amount = str_replace(',', '', $request->input('amount_1_' . $count));
            $purchase_voucher_data->sales_tax_per = $request->input('accounts_1_' . $count);
            $purchase_voucher_data->sales_tax_amount = $request->input('sales_tax_amount_1_' . $count);
            $purchase_voucher_data->net_amount = $request->input('net_amount_1_' . $count);;
            $purchase_voucher_data->username = Auth::user()->name;
            $purchase_voucher_data->date = date('Y-m-d');
            $purchase_voucher->pv_no = $pv_no;
            $purchase_voucher_data->save();
            $other_id = $purchase_voucher_data->id;


            $trans = new Transactions();
            $trans = $trans->SetConnection('mysql2');
            $account = $request->input('category_id_1_' . $count);
            //    $account=CommonHelper::get_item_acc_id($sub_ic_id);

            $trans->acc_id = $account;
            $trans->acc_code = FinanceHelper::getAccountCodeByAccId($account, '');;
            $trans->master_id = $master_id;
            $trans->particulars = $request->description;
            $trans->opening_bal = 0;
            $trans->debit_credit = 1;
            $trans->amount = str_replace(',', '', $request->input('amount_1_' . $count));;
            $trans->voucher_no = $pv_no;
            $trans->voucher_type = 4;
            $trans->v_date = $request->purchase_date;
            $trans->date = date('Y-m-d');
            $trans->action = 1;
            $trans->username = Auth::user()->name;
            $trans->save();

            // for tax
            if ($request->input('accounts_1_' . $count) != 0):
                $trans1 = new Transactions();
                $trans1 = $trans1->SetConnection('mysql2');
                $account = $request->input('accounts_1_' . $count);
                $trans1->acc_id = $account;
                $trans1->acc_code = FinanceHelper::getAccountCodeByAccId($account, '');;
                $trans1->master_id = $master_id;
                $trans1->particulars = $request->description;
                $trans1->opening_bal = 0;
                $trans1->debit_credit = 1;
                $trans1->amount = str_replace(',', '', $request->input('sales_tax_amount_1_' . $count));;
                $trans1->voucher_no = $pv_no;
                $trans1->voucher_type = 4;
                $trans1->v_date = $request->purchase_date;
                $trans1->date = date('Y-m-d');
                $trans1->action = 1;
                $trans1->username = Auth::user()->name;
                $trans1->save();
            endif;
            // end for tax

            // for department

            $allow_null = $request->input('dept_check_box' . $count);
            if ($allow_null == 0):
                $department1 = $request->input('department' . $count);
                $counter = 0;
                foreach ($department1 as $row1):
                    $dept_allocation1 = new DepartmentAllocation1();
                    $dept_allocation1 = $dept_allocation1->SetConnection('mysql2');
                    $dept_allocation1->Main_master_id = $master_id;
                    $dept_allocation1->master_id = $other_id;
                    $dept_allocation1->pv_no = $pv_no;
                    $dept_allocation1->dept_id = $row1;
                    $perccent = $request->input('percent' . $count);
                    $dept_allocation1->percent = $perccent[$counter];
                    $amount = $request->input('department_amount' . $count);
                    $amount = str_replace(",", "", $amount);
                    $dept_allocation1->amount = $amount[$counter];
                    $dept_allocation1->item = $request->input('sub_item_id_1_' . $count);
                    $dept_allocation1->save();
                    $counter++;

                endforeach;
            endif;

            // end for department


            // for sales tax department

            $allow_null = $request->input('sales_tax_check_box' . $count);
            if ($allow_null == 0):
                $sales_tax_department = $request->input('sales_tax_department' . $count);
                $counter = 0;
                foreach ($sales_tax_department as $row2):
                    if ($row2 != 0):
                        $salestaxdepartment = new SalesTaxDepartmentAllocation();
                        $salestaxdepartment = $salestaxdepartment->SetConnection('mysql2');
                        $salestaxdepartment->Main_master_id = $master_id;
                        $salestaxdepartment->master_id = $other_id;
                        $salestaxdepartment->pv_no = $pv_no;
                        $salestaxdepartment->dept_id = $row2;
                        $perccent = $request->input('sales_tax_percent' . $count);
                        $salestaxdepartment->percent = $perccent[$counter];
                        $amount = $request->input('sales_tax_department_amount' . $count);
                        $amount = str_replace(",", "", $amount);
                        $salestaxdepartment->amount = $amount[$counter];
                        $salestaxdepartment->sales_tax = $request->input('accounts_1_' . $count);

                        $salestaxdepartment->save();
                    endif;
                    $counter++;

                endforeach;
            endif;

            // End for sales tax department


            // for Cost center department

            $allow_null = $request->input('cost_center_check_box' . $count);
            if ($allow_null == 0):
                $sales_tax_department = $request->input('cost_center_department' . $count);
                $counter = 0;
                foreach ($sales_tax_department as $row3):
                    $costcenter = new CostCenterDepartmentAllocation();
                    $costcenter = $costcenter->SetConnection('mysql2');
                    $costcenter->Main_master_id = $master_id;
                    $costcenter->master_id = $other_id;
                    $costcenter->pv_no = $pv_no;
                    $costcenter->dept_id = $row3;
                    $perccent = $request->input('cost_center_percent' . $count);
                    $costcenter->percent = $perccent[$counter];
                    $amount = $request->input('cost_center_department_amount' . $count);
                    $amount = str_replace(",", "", $amount);
                    if ($amount[$counter] != ''):
                        $costcenter->amount = $amount[$counter];
                    endif;
                    $costcenter->item = $request->input('sub_item_id_1_' . $count);
                    $costcenter->save();
                    $counter++;

                endforeach;
            endif;

            // End for Cost center department


            $count++; endforeach;


        $trans2 = new Transactions();
        $trans2 = $trans2->SetConnection('mysql2');
        $account = CommonHelper::get_supplier_acc_id($request->supplier);
        $trans2->acc_id = $account;
        $trans2->acc_code = FinanceHelper::getAccountCodeByAccId($account, '');;
        $trans2->master_id = $master_id;
        $trans2->particulars = $request->description;
        $trans2->opening_bal = 0;
        $trans2->debit_credit = 0;
        $trans2->amount = $request->total_net_amount;
        $trans2->voucher_no = $pv_no;
        $trans2->voucher_type = 4;
        $trans2->v_date = $request->purchase_date;
        $trans2->date = date('Y-m-d');
        $trans2->action = 1;
        $trans2->username = Auth::user()->name;

        $trans2->save();

        $cn->rollBack();
        //  return Redirect::to('purchase/createPurchaseVoucherForm?pageType=add&&parentCode=80&&m=1');
        return Redirect::to('pdc/viewPurchaseVoucherDetailAfterSubmit/' . $master_id);

    }


    public function addDemandTypeDetail(Request $request)
    {
        $name = $request->demand_type;
        $demand_type = new DemandType();
        $demand_type = $demand_type->SetConnection('mysql2');
        $demand_type_count = $demand_type->where('status', 1)->where('name', $name)->count();
        if ($demand_type_count > 0):
            Session::flash('dataDelete', $name . ' ' . 'Already Exists.');
            return Redirect::to('purchase/createDemandTypeForm?pageType=add&&parentCode=82&&m=1#SFR');
        else:

            $demand_type->name = $name;
            $demand_type->username = Auth::user()->name;
            $demand_type->date = date('Y-m-d');
            $demand_type->save();
            Session::flash('dataInsert', 'successfully saved.');
            return Redirect::to('purchase/createDemandTypeForm?pageType=add&&parentCode=82&&m=1#SFR');
        endif;

    }

    public function addWareHouseDetail(Request $request)
    {
        $name = $request->warehouse;
        $warehouse = new Warehouse();
        $warehouse = $warehouse->SetConnection('mysql2');
        $warehouse_count = $warehouse->where('status', 1)->where('name', $name)->count();
        if ($warehouse_count > 0):
            Session::flash('dataDelete', $name . ' ' . 'Already Exists.');
            return Redirect::to('purchase/createWarehouseForm?pageType=add&&parentCode=82&&m=1#SFR');
        else:

            $warehouse->name = $name;
            $warehouse->username = Auth::user()->name;
            $warehouse->date = date('Y-m-d');
            $warehouse->save();
            Session::flash('dataInsert', 'successfully saved.');
            return Redirect::to('purchase/createWarehouseForm?pageType=add&&parentCode=82&&m=1#SFR');
        endif;

    }
}