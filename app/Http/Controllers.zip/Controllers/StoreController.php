<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use Illuminate\Http\Request;
use App\Helpers\CommonHelper;
use Auth;
use DB;
use Config;
use App\Models\Department;
use App\Models\Category;
class StoreController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function toDayActivity()
    {
        return view('Store.toDayActivity');
    }

    public  function viewDemandList(){
        return view('Store.viewDemandList');
    }

    public function createStoreChallanForm(){
        $departments = new Department;
        $departments = $departments::where([['company_id', '=', $_GET['m']], ['status', '=', '1'], ])->orderBy('id')->get();
        return view('Store.createStoreChallanForm',compact('departments'));
    }

    public  function viewStoreChallanList(){
        return view('Store.viewStoreChallanList');
    }

    public  function editStoreChallanVoucherForm(){
        $departments = new Department;
        $departments = $departments::where([['company_id', '=', $_GET['m']], ['status', '=', '1'], ])->orderBy('id')->get();
        return view('Store.AjaxPages.editStoreChallanVoucherForm',compact('departments'));
    }

    public function createPurchaseRequestForm(){
        $departments = new Department;
        $departments = $departments::where([['company_id', '=', $_GET['m']], ['status', '=', '1'], ])->orderBy('id')->get();
        return view('Store.createPurchaseRequestForm',compact('departments'));
    }

    public  function viewPurchaseRequestList(){
        return view('Store.viewPurchaseRequestList');
    }

    public  function editPurchaseRequestVoucherForm(){
        $departments = new Department;
        $departments = $departments::where([['company_id', '=', $_GET['m']], ['status', '=', '1'], ])->orderBy('id')->get();
        return view('Store.AjaxPages.editPurchaseRequestVoucherForm',compact('departments'));
    }


    public function createPurchaseRequestSaleForm(){
        $departments = new Department;
        $departments = $departments::where([['company_id', '=', $_GET['m']], ['status', '=', '1'], ])->orderBy('id')->get();
        return view('Store.createPurchaseRequestSaleForm',compact('departments'));
    }

    public  function viewPurchaseRequestSaleList(){
        return view('Store.viewPurchaseRequestSaleList');
    }

    public  function editPurchaseRequestSaleVoucherForm(){
        $departments = new Department;
        $departments = $departments::where([['company_id', '=', $_GET['m']], ['status', '=', '1'], ])->orderBy('id')->get();
        return view('Store.AjaxPages.editPurchaseRequestSaleVoucherForm',compact('departments'));
    }



    public function createStoreChallanReturnForm(){
        $departments = new Department;
        $departments = $departments::where([['company_id', '=', $_GET['m']], ['status', '=', '1'], ])->orderBy('id')->get();
        return view('Store.createStoreChallanReturnForm',compact('departments'));
    }

    public  function viewStoreChallanReturnList(){
        return view('Store.viewStoreChallanReturnList');
    }

    public  function editStoreChallanReturnForm(){
        $departments = new Department;
        $departments = $departments::where([['company_id', '=', $_GET['m']], ['status', '=', '1'], ])->orderBy('id')->get();
        return view('Store.AjaxPages.editStoreChallanReturnForm',compact('departments'));
    }

    public function viewDateWiseStockInventoryReport(){
        CommonHelper::companyDatabaseConnection($_GET['m']);
        $categorys = new Category;
        $categorys = $categorys::where([['company_id', '=', $_GET['m']], ['status', '=', '1'], ])->orderBy('id')->get();
        CommonHelper::reconnectMasterDatabase();
        return view('Store.viewDateWiseStockInventoryReport',compact('categorys'));
    }

    

}
