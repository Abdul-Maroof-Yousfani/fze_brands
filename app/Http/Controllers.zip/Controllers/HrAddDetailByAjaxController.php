<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use Illuminate\Http\Request;
use Auth;
use DB;
use Config;
use Input;
use Session;
use Redirect;

use App\Helpers\CommonHelper;
use App\Helpers\HrHelper;
use App\Models\Department;
use App\Models\Employee;
use App\Models\Attendence;
use App\Models\Payslip;
use App\Models\Allowance;
use App\Models\Deduction;
use App\Models\JobType;
use App\Models\SubDepartment;
use App\Models\MaritalStatus;
use App\Models\LeavesPolicy;
use App\Models\LeavesData;
use App\Models\CarPolicy;



class HrAddDetailByAjaxController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */


    public function addLeaveApplicationDetail()
    {
        CommonHelper::companyDatabaseConnection(Input::get('company_id'));


        $leaveApplicationData['emp_id']          = Input::get('emp_id');
        $leaveApplicationData['leave_policy_id'] = Input::get('leave_policy_id');
        $leaveApplicationData['leave_type']      = Input::get('leave_type');
        $leaveApplicationData['leave_day_type']  = Input::get('leave_day_type');
        $leaveApplicationData['reason']          = Input::get('reason');
        $leaveApplicationData['leave_address']   = Input::get('leave_address');
        $leaveApplicationData['approval_status'] = 1;
        $leaveApplicationData['status']          = 1;
        $leaveApplicationData['username']        = Auth::user()->name;
        $leaveApplicationData['date']            = date("Y-m-d");
        $leaveApplicationData['time']            = date("H:i:s");

        $leave_application_id = DB::table('leave_application')->insertGetId($leaveApplicationData);


        /* Annual Leaves ID = 3 */
        if(Input::get('leave_type') == 4):

            $maternityLeavesData['emp_id']               = Input::get('emp_id');
            $maternityLeavesData['leave_application_id'] = $leave_application_id;
            $maternityLeavesData['leave_type']           = Input::get('leave_type');
            $maternityLeavesData['leave_day_type']       = Input::get('leave_day_type');
            $maternityLeavesData['no_of_days']           = Input::get('no_of_days');
            $maternityLeavesData['from_date']            = Input::get('from_date');
            $maternityLeavesData['to_date']              = Input::get('to_date');
            $maternityLeavesData['status']               = 1;
            $maternityLeavesData['username']             = Auth::user()->name;
            $maternityLeavesData['date']                 = date("Y-m-d");
            $maternityLeavesData['time']                 = date("H:i:s");

            DB::table('leave_application_data')->insert($maternityLeavesData);

        elseif(Input::get('leave_type') == 3):

        /* Full Day Leaves */
            if(Input::get('leave_day_type') == 1):

            $annualLeavesData['emp_id']               = Input::get('emp_id');
            $annualLeavesData['leave_application_id'] = $leave_application_id;
            $annualLeavesData['leave_type']           = Input::get('leave_type');
            $annualLeavesData['leave_day_type']       = Input::get('leave_day_type');
            $annualLeavesData['no_of_days']           = Input::get('no_of_days');
            $annualLeavesData['from_date']            = Input::get('from_date');
            $annualLeavesData['to_date']              = Input::get('to_date');
            $annualLeavesData['status']               = 1;
            $annualLeavesData['username']             = Auth::user()->name;
            $annualLeavesData['date']                 = date("Y-m-d");
            $annualLeavesData['time']                 = date("H:i:s");

            DB::table('leave_application_data')->insert($annualLeavesData);

            /* Half Day Leaves */
            elseif(Input::get('leave_day_type') == 2):

            $halfdayLeavesData['emp_id']                   = Input::get('emp_id');
            $halfdayLeavesData['leave_application_id']     = $leave_application_id;
            $halfdayLeavesData['leave_type']               = Input::get('leave_type');
            $halfdayLeavesData['leave_day_type']           = Input::get('leave_day_type');
            $halfdayLeavesData['no_of_days']               = Input::get('no_of_days');
            $halfdayLeavesData['first_second_half']        = Input::get('first_second_half');
            $halfdayLeavesData['first_second_half_date']   = Input::get('first_second_half_date');
            $halfdayLeavesData['status']                   = $leave_application_id;
            $halfdayLeavesData['username']                 = Auth::user()->name;
            $halfdayLeavesData['date']                     = date("Y-m-d");
            $halfdayLeavesData['time']                     = date("H:i:s");

            DB::table('leave_application_data')->insert($halfdayLeavesData);

             else:
                 /* Short Leaves */

                 $shortLeavesData['emp_id']               = Input::get('emp_id');
                 $shortLeavesData['leave_application_id'] = $leave_application_id;
                 $shortLeavesData['leave_type']           = Input::get('leave_type');
                 $shortLeavesData['leave_day_type']       = Input::get('leave_day_type');
                 $shortLeavesData['no_of_days']           = Input::get('no_of_days');
                 $shortLeavesData['short_leave_time_from']= Input::get('short_leave_time_from');
                 $shortLeavesData['short_leave_time_to']  = Input::get('short_leave_time_to');
                 $shortLeavesData['short_leave_date']     = Input::get('short_leave_date');
                 $shortLeavesData['status']               = $leave_application_id;
                 $shortLeavesData['username']             = Auth::user()->name;
                 $shortLeavesData['date']                 = date("Y-m-d");
                 $shortLeavesData['time']                 = date("H:i:s");


                 DB::table('leave_application_data')->insert($shortLeavesData);

            endif;

        elseif(Input::get('leave_type') == 2):


            /* Full Day Leaves */
            if(Input::get('leave_day_type') == 1):

                $annualLeavesData['emp_id']               = Input::get('emp_id');
                $annualLeavesData['leave_application_id'] = $leave_application_id;
                $annualLeavesData['leave_type']           = Input::get('leave_type');
                $annualLeavesData['leave_day_type']       = Input::get('leave_day_type');
                $annualLeavesData['no_of_days']           = Input::get('no_of_days');
                $annualLeavesData['from_date']            = Input::get('from_date');
                $annualLeavesData['to_date']              = Input::get('to_date');
                $annualLeavesData['status']               = 1;
                $annualLeavesData['username']             = Auth::user()->name;
                $annualLeavesData['date']                 = date("Y-m-d");
                $annualLeavesData['time']                 = date("H:i:s");

                DB::table('leave_application_data')->insert($annualLeavesData);

            /* Half Day Leaves */
            elseif(Input::get('leave_day_type') == 2):

                $halfdayLeavesData['emp_id']                   = Input::get('emp_id');
                $halfdayLeavesData['leave_application_id']     = $leave_application_id;
                $halfdayLeavesData['leave_type']               = Input::get('leave_type');
                $halfdayLeavesData['leave_day_type']           = Input::get('leave_day_type');
                $halfdayLeavesData['no_of_days']               = Input::get('no_of_days');
                $halfdayLeavesData['first_second_half']        = Input::get('first_second_half');
                $halfdayLeavesData['first_second_half_date']   = Input::get('first_second_half_date');
                $halfdayLeavesData['status']                   = 1;
                $halfdayLeavesData['username']                 = Auth::user()->name;
                $halfdayLeavesData['date']                     = date("Y-m-d");
                $halfdayLeavesData['time']                     = date("H:i:s");

              DB::table('leave_application_data')->insert($halfdayLeavesData);

            else:
                /* Short Leaves */

                $shortLeavesData['emp_id']               = Input::get('emp_id');
                $shortLeavesData['leave_application_id'] = $leave_application_id;
                $shortLeavesData['leave_type']           = Input::get('leave_type');
                $shortLeavesData['leave_day_type']       = Input::get('leave_day_type');
                $shortLeavesData['no_of_days']           = Input::get('no_of_days');
                $shortLeavesData['short_leave_time_from']= Input::get('short_leave_time_from');
                $shortLeavesData['short_leave_time_to']  = Input::get('short_leave_time_to');
                $shortLeavesData['short_leave_date']     = Input::get('short_leave_date');
                $shortLeavesData['status']               = 1;
                $shortLeavesData['username']             = Auth::user()->name;
                $shortLeavesData['date']                 = date("Y-m-d");
                $shortLeavesData['time']                 = date("H:i:s");


                DB::table('leave_application_data')->insert($shortLeavesData);

            endif;

        else:


            /* Full Day Leaves */
            if(Input::get('leave_day_type') == 1):

                $annualLeavesData['emp_id']               = Input::get('emp_id');
                $annualLeavesData['leave_application_id'] = $leave_application_id;
                $annualLeavesData['leave_type']           = Input::get('leave_type');
                $annualLeavesData['leave_day_type']       = Input::get('leave_day_type');
                $annualLeavesData['no_of_days']           = Input::get('no_of_days');
                $annualLeavesData['from_date']            = Input::get('from_date');
                $annualLeavesData['to_date']              = Input::get('to_date');
                $annualLeavesData['status']               = 1;
                $annualLeavesData['username']             = Auth::user()->name;
                $annualLeavesData['date']                 = date("Y-m-d");
                $annualLeavesData['time']                 = date("H:i:s");

                DB::table('leave_application_data')->insert($annualLeavesData);

            /* Half Day Leaves */
            elseif(Input::get('leave_day_type') == 2):

                $halfdayLeavesData['emp_id']                   = Input::get('emp_id');
                $halfdayLeavesData['leave_application_id']     = $leave_application_id;
                $halfdayLeavesData['leave_type']               = Input::get('leave_type');
                $halfdayLeavesData['leave_day_type']           = Input::get('leave_day_type');
                $halfdayLeavesData['no_of_days']               = Input::get('no_of_days');
                $halfdayLeavesData['first_second_half']        = Input::get('first_second_half');
                $halfdayLeavesData['first_second_half_date']   = Input::get('first_second_half_date');
                $halfdayLeavesData['status']                   = 1;
                $halfdayLeavesData['username']                 = Auth::user()->name;
                $halfdayLeavesData['date']                     = date("Y-m-d");
                $halfdayLeavesData['time']                     = date("H:i:s");

                DB::table('leave_application_data')->insert($halfdayLeavesData);

            else:
                /* Short Leaves */

                $shortLeavesData['emp_id']               = Input::get('emp_id');
                $shortLeavesData['leave_application_id'] = $leave_application_id;
                $shortLeavesData['leave_type']           = Input::get('leave_type');
                $shortLeavesData['leave_day_type']       = Input::get('leave_day_type');
                $shortLeavesData['no_of_days']           = Input::get('no_of_days');
                $shortLeavesData['short_leave_time_from']= Input::get('short_leave_time_from');
                $shortLeavesData['short_leave_time_to']  = Input::get('short_leave_time_to');
                $shortLeavesData['short_leave_date']     = Input::get('short_leave_date');
                $shortLeavesData['status']               = 1;
                $shortLeavesData['username']             = Auth::user()->name;
                $shortLeavesData['date']                 = date("Y-m-d");
                $shortLeavesData['time']                 = date("H:i:s");

                DB::table('leave_application_data')->insert($shortLeavesData);

            endif;

        endif;

        Session::flash('dataInsert','successfully saved.');
        CommonHelper::reconnectMasterDatabase();

    }


}
?>