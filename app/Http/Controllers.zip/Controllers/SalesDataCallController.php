<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use Illuminate\Http\Request;
use App\Helpers\CommonHelper;
use Auth;
use DB;
use Config;
use App\Models\Customer;
use App\Models\Invoice;
use App\Models\InvoiceData;
class SalesDataCallController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
   	public function viewCashCustomerList(){
        CommonHelper::companyDatabaseConnection($_GET['m']);
		$customers = new Customer;
		$customers = $customers::where('status', '=', '1')
						->where('customer_type', '=', '2')->get();
        CommonHelper::reconnectMasterDatabase();
		$counter = 1;
		foreach($customers as $row){
	?>
		<tr>
			<td class="text-center"><?php echo $counter++;?></td>
			<td><?php echo $row['name'];?></td>
			<td class="text-center"><?php echo $row['contact'];?></td>
			<td><?php echo $row['email'];?></td>
			<td></td>
		</tr>
	<?php
		}
	}
	
	public function viewCreditCustomerList(){
        CommonHelper::companyDatabaseConnection($_GET['m']);
		$customers = new Customer;
		$customers = $customers::where('status', '=', '1')
						->where('customer_type', '=', '3')->get();
        CommonHelper::reconnectMasterDatabase();
		$counter = 1;
		foreach($customers as $row){
	?>
		<tr>
			<td class="text-center"><?php echo $counter++;?></td>
			<td><?php echo $row['name'];?></td>
			<td class="text-center"><?php echo $row['contact'];?></td>
			<td><?php echo $row['email'];?></td>
			<td></td>
		</tr>
	<?php
		}
	}

	public function filterCreditSaleVoucherList(){
        $fromDate = $_GET['fromDate'];
        $toDate = $_GET['toDate'];
        $m = $_GET['m'];

        $selectVoucherStatus = $_GET['selectVoucherStatus'];
        $selectSubItem = $_GET['selectSubItem'];
        $selectSubItemId = $_GET['selectSubItemId'];
        $selectCreditCustomer = $_GET['selectCustomer'];
        $selectCreditCustomerId = $_GET['selectCustomerId'];


        CommonHelper::companyDatabaseConnection($m);

        if($selectVoucherStatus == '0' && empty($selectSubItemId) && empty($selectCreditCustomerId)){
            //return 'One';
            $creditSaleInvoiceDetail = Invoice::whereBetween('inv_date',[$fromDate,$toDate])->where('invoiceType','=','3')->get();
        }else if($selectVoucherStatus == '0' && !empty($selectSubItemId) && empty($selectCreditCustomerId)){
            //return 'Two';
            $creditSaleInvoiceDetail = DB::table('invoice')
                ->select('invoice.inv_no','invoice.dc_no','invoice.consignee','invoice.inv_date','invoice.inv_against_discount','invoice.inv_status','invoice.status','inv_data.sub_item_id')
                ->join('inv_data', 'invoice.inv_no', '=', 'inv_data.inv_no')
                ->whereBetween('invoice.inv_date',[$fromDate,$toDate])
                ->where('inv_data.sub_item_id','=',$selectSubItemId)
                ->where('invoiceType','=','3')
                ->groupBy('invoice.inv_no')
                ->get();
        }else if($selectVoucherStatus == '0' && empty($selectSubItemId) && !empty($selectCreditCustomerId)){
            //return 'Three';
            $creditSaleInvoiceDetail = Invoice::whereBetween('inv_date',[$fromDate,$toDate])->where('consignee','=',$selectCreditCustomerId)->where('invoiceType','=','3')->get();
        }else if($selectVoucherStatus == '1' && !empty($selectSubItemId) && empty($selectCreditCustomerId)){
            //return 'Four';
            $creditSaleInvoiceDetail = DB::table('invoice')
                ->select('invoice.inv_no','invoice.dc_no','invoice.consignee','invoice.inv_date','invoice.inv_against_discount','invoice.inv_status','invoice.status','inv_data.sub_item_id')
                ->join('inv_data', 'invoice.inv_no', '=', 'inv_data.inv_no')
                ->whereBetween('invoice.inv_date',[$fromDate,$toDate])
                ->where('inv_data.sub_item_id','=',$selectSubItemId)
                ->where('invoice.invoiceType','=','3')
                ->where('invoice.inv_status','=','1')
                ->where('invoice.status','=','1')
                ->groupBy('invoice.inv_no')
                ->get();
        }else if($selectVoucherStatus == '2' && !empty($selectSubItemId) && empty($selectCreditCustomerId)){
            //return 'Five';
            $creditSaleInvoiceDetail = DB::table('invoice')
                ->select('invoice.inv_no','invoice.dc_no','invoice.consignee','invoice.inv_date','invoice.inv_against_discount','invoice.inv_status','invoice.status','inv_data.sub_item_id')
                ->join('inv_data', 'invoice.inv_no', '=', 'inv_data.inv_no')
                ->whereBetween('invoice.inv_date',[$fromDate,$toDate])
                ->where('inv_data.sub_item_id','=',$selectSubItemId)
                ->where('invoice.invoiceType','=','3')
                ->where('invoice.inv_status','=','2')
                ->where('invoice.status','=','1')
                ->groupBy('invoice.inv_no')
                ->get();
        }else if($selectVoucherStatus == '3' && !empty($selectSubItemId) && empty($selectCreditCustomerId)){
            //return 'Six';
            $creditSaleInvoiceDetail = DB::table('invoice')
                ->select('invoice.inv_no','invoice.dc_no','invoice.consignee','invoice.inv_date','invoice.inv_against_discount','invoice.inv_status','invoice.status','inv_data.sub_item_id')
                ->join('inv_data', 'invoice.inv_no', '=', 'inv_data.inv_no')
                ->whereBetween('invoice.inv_date',[$fromDate,$toDate])
                ->where('inv_data.sub_item_id','=',$selectSubItemId)
                ->where('invoice.invoiceType','=','3')
                ->where('invoice.status','=','2')
                ->groupBy('invoice.inv_no')
                ->get();
        }else if($selectVoucherStatus == '1' && empty($selectSubItemId) && empty($selectCreditCustomerId)){
            //return 'Seven';
            $creditSaleInvoiceDetail = Invoice::whereBetween('inv_date',[$fromDate,$toDate])->where('status','=','1')->where('inv_status','=','1')->where('invoice.invoiceType','=','3')->get();
        }else if($selectVoucherStatus == '2' && empty($selectSubItemId) && empty($selectCreditCustomerId)){
            //return 'Eight';
            $creditSaleInvoiceDetail = Invoice::whereBetween('inv_date',[$fromDate,$toDate])->where('status','=','1')->where('inv_status','=','2')->where('invoice.invoiceType','=','3')->get();
        }else if($selectVoucherStatus == '3' && empty($selectSubItemId) && empty($selectCreditCustomerId)){
            //return 'Nine';
            $creditSaleInvoiceDetail = Invoice::whereBetween('inv_date',[$fromDate,$toDate])->where('status','=','2')->where('invoice.invoiceType','=','3')->get();
        }else if($selectVoucherStatus == '1' && empty($selectSubItemId) && !empty($selectCreditCustomerId)){
            //return 'Ten';
            $creditSaleInvoiceDetail = Invoice::whereBetween('inv_date',[$fromDate,$toDate])->where('status','=','1')->where('inv_status','=','1')->where('consignee','=',$selectCreditCustomerId)->where('invoice.invoiceType','=','3')->get();
        }else if($selectVoucherStatus == '2' && empty($selectSubItemId) && !empty($selectCreditCustomerId)){
            //return 'Eleven';
            $creditSaleInvoiceDetail = Invoice::whereBetween('inv_date',[$fromDate,$toDate])->where('status','=','1')->where('inv_status','=','2')->where('consignee','=',$selectCreditCustomerId)->where('invoice.invoiceType','=','3')->get();
        }else if($selectVoucherStatus == '3' && empty($selectSubItemId) && !empty($selectCreditCustomerId)){
            //return 'Twelve';
            $creditSaleInvoiceDetail = Invoice::whereBetween('inv_date',[$fromDate,$toDate])->where('status','=','2')->where('consignee','=',$selectCreditCustomerId)->where('invoice.invoiceType','=','3')->get();
        }else if($selectVoucherStatus == '0' && !empty($selectSubItemId) && !empty($selectCreditCustomerId)){
            //return 'Thirteen';
            $creditSaleInvoiceDetail = DB::table('invoice')
                ->select('invoice.inv_no','invoice.dc_no','invoice.consignee','invoice.inv_date','invoice.inv_against_discount','invoice.inv_status','invoice.status','inv_data.sub_item_id')
                ->join('inv_data', 'invoice.inv_no', '=', 'inv_data.inv_no')
                ->whereBetween('invoice.inv_date',[$fromDate,$toDate])
                ->where('inv_data.sub_item_id','=',$selectSubItemId)
                ->where('invoice.consignee','=',$selectCreditCustomerId)
                ->where('invoice.invoiceType','=','3')
                ->groupBy('invoice.inv_no')
                ->get();
        }else if($selectVoucherStatus == '1' && !empty($selectSubItemId) && !empty($selectCreditCustomerId)){
            //return 'Fourteen';
            $creditSaleInvoiceDetail = DB::table('invoice')
                ->select('invoice.inv_no','invoice.dc_no','invoice.consignee','invoice.inv_date','invoice.inv_against_discount','invoice.inv_status','invoice.status','inv_data.sub_item_id')
                ->join('inv_data', 'invoice.inv_no', '=', 'inv_data.inv_no')
                ->whereBetween('invoice.inv_date',[$fromDate,$toDate])
                ->where('inv_data.sub_item_id','=',$selectSubItemId)
                ->where('invoice.consignee','=',$selectCreditCustomerId)
                ->where('invoice.invoiceType','=','3')
                ->where('invoice.inv_status','=','1')
                ->groupBy('invoice.inv_no')
                ->get();
        }else if($selectVoucherStatus == '2' && !empty($selectSubItemId) && !empty($selectCreditCustomerId)){
            //return 'Fifteen';
            $creditSaleInvoiceDetail = DB::table('invoice')
                ->select('invoice.inv_no','invoice.dc_no','invoice.consignee','invoice.inv_date','invoice.inv_against_discount','invoice.inv_status','invoice.status','inv_data.sub_item_id')
                ->join('inv_data', 'invoice.inv_no', '=', 'inv_data.inv_no')
                ->whereBetween('invoice.inv_date',[$fromDate,$toDate])
                ->where('inv_data.sub_item_id','=',$selectSubItemId)
                ->where('invoice.consignee','=',$selectCreditCustomerId)
                ->where('invoice.invoiceType','=','3')
                ->where('invoice.inv_status','=','2')
                ->groupBy('invoice.inv_no')
                ->get();
        }else if($selectVoucherStatus == '3' && !empty($selectSubItemId) && !empty($selectCreditCustomerId)){
            //return 'Sixteen';
            $creditSaleInvoiceDetail = DB::table('invoice')
                ->select('invoice.inv_no','invoice.dc_no','invoice.consignee','invoice.inv_date','invoice.inv_against_discount','invoice.inv_status','invoice.status','inv_data.sub_item_id')
                ->join('inv_data', 'invoice.inv_no', '=', 'inv_data.inv_no')
                ->whereBetween('invoice.inv_date',[$fromDate,$toDate])
                ->where('inv_data.sub_item_id','=',$selectSubItemId)
                ->where('invoice.consignee','=',$selectCreditCustomerId)
                ->where('invoice.invoiceType','=','3')
                ->where('invoice.status','=','2')
                ->groupBy('invoice.inv_no')
                ->get();
        }

        CommonHelper::reconnectMasterDatabase();
        return view('Sales.AjaxPages.filterCreditSaleVoucherList',compact('creditSaleInvoiceDetail'));
    }

    public function filterCashSaleVoucherList(){
        $fromDate = $_GET['fromDate'];
        $toDate = $_GET['toDate'];
        $m = $_GET['m'];

        $selectVoucherStatus = $_GET['selectVoucherStatus'];
        $selectSubItem = $_GET['selectSubItem'];
        $selectSubItemId = $_GET['selectSubItemId'];
        $selectCashCustomer = $_GET['selectCustomer'];
        $selectCashCustomerId = $_GET['selectCustomerId'];


        CommonHelper::companyDatabaseConnection($m);

        if($selectVoucherStatus == '0' && empty($selectSubItemId) && empty($selectCashCustomerId)){
            //return 'One';
            $cashSaleInvoiceDetail = Invoice::whereBetween('inv_date',[$fromDate,$toDate])->where('invoiceType','=','2')->get();
        }else if($selectVoucherStatus == '0' && !empty($selectSubItemId) && empty($selectCashCustomerId)){
            //return 'Two';
            $cashSaleInvoiceDetail = DB::table('invoice')
                ->select('invoice.inv_no','invoice.dc_no','invoice.consignee','invoice.inv_date','invoice.inv_status','invoice.inv_against_discount','invoice.status','inv_data.sub_item_id')
                ->join('inv_data', 'invoice.inv_no', '=', 'inv_data.inv_no')
                ->whereBetween('invoice.inv_date',[$fromDate,$toDate])
                ->where('inv_data.sub_item_id','=',$selectSubItemId)
                ->where('invoiceType','=','2')
                ->groupBy('invoice.inv_no')
                ->get();
        }else if($selectVoucherStatus == '0' && empty($selectSubItemId) && !empty($selectCashCustomerId)){
            //return 'Three';
            $cashSaleInvoiceDetail = Invoice::whereBetween('inv_date',[$fromDate,$toDate])->where('consignee','=',$selectCashCustomerId)->where('invoiceType','=','2')->get();
        }else if($selectVoucherStatus == '1' && !empty($selectSubItemId) && empty($selectCashCustomerId)){
            //return 'Four';
            $cashSaleInvoiceDetail = DB::table('invoice')
                ->select('invoice.inv_no','invoice.dc_no','invoice.consignee','invoice.inv_date','invoice.inv_status','invoice.status','invoice.inv_against_discount','inv_data.sub_item_id')
                ->join('inv_data', 'invoice.inv_no', '=', 'inv_data.inv_no')
                ->whereBetween('invoice.inv_date',[$fromDate,$toDate])
                ->where('inv_data.sub_item_id','=',$selectSubItemId)
                ->where('invoice.invoiceType','=','2')
                ->where('invoice.inv_status','=','1')
                ->where('invoice.status','=','1')
                ->groupBy('invoice.inv_no')
                ->get();
        }else if($selectVoucherStatus == '2' && !empty($selectSubItemId) && empty($selectCashCustomerId)){
            //return 'Five';
            $cashSaleInvoiceDetail = DB::table('invoice')
                ->select('invoice.inv_no','invoice.dc_no','invoice.consignee','invoice.inv_date','invoice.inv_against_discount','invoice.inv_status','invoice.status','inv_data.sub_item_id')
                ->join('inv_data', 'invoice.inv_no', '=', 'inv_data.inv_no')
                ->whereBetween('invoice.inv_date',[$fromDate,$toDate])
                ->where('inv_data.sub_item_id','=',$selectSubItemId)
                ->where('invoice.invoiceType','=','2')
                ->where('invoice.inv_status','=','2')
                ->where('invoice.status','=','1')
                ->groupBy('invoice.inv_no')
                ->get();
        }else if($selectVoucherStatus == '3' && !empty($selectSubItemId) && empty($selectCashCustomerId)){
            //return 'Six';
            $cashSaleInvoiceDetail = DB::table('invoice')
                ->select('invoice.inv_no','invoice.dc_no','invoice.consignee','invoice.inv_date','invoice.inv_against_discount','invoice.inv_status','invoice.status','inv_data.sub_item_id')
                ->join('inv_data', 'invoice.inv_no', '=', 'inv_data.inv_no')
                ->whereBetween('invoice.inv_date',[$fromDate,$toDate])
                ->where('inv_data.sub_item_id','=',$selectSubItemId)
                ->where('invoice.invoiceType','=','2')
                ->where('invoice.status','=','2')
                ->groupBy('invoice.inv_no')
                ->get();
        }else if($selectVoucherStatus == '1' && empty($selectSubItemId) && empty($selectCashCustomerId)){
            //return 'Seven';
            $cashSaleInvoiceDetail = Invoice::whereBetween('inv_date',[$fromDate,$toDate])->where('status','=','1')->where('inv_status','=','1')->where('invoice.invoiceType','=','2')->get();
        }else if($selectVoucherStatus == '2' && empty($selectSubItemId) && empty($selectCashCustomerId)){
            //return 'Eight';
            $cashSaleInvoiceDetail = Invoice::whereBetween('inv_date',[$fromDate,$toDate])->where('status','=','1')->where('inv_status','=','2')->where('invoice.invoiceType','=','2')->get();
        }else if($selectVoucherStatus == '3' && empty($selectSubItemId) && empty($selectCashCustomerId)){
            //return 'Nine';
            $cashSaleInvoiceDetail = Invoice::whereBetween('inv_date',[$fromDate,$toDate])->where('status','=','2')->where('invoice.invoiceType','=','2')->get();
        }else if($selectVoucherStatus == '1' && empty($selectSubItemId) && !empty($selectCashCustomerId)){
            //return 'Ten';
            $cashSaleInvoiceDetail = Invoice::whereBetween('inv_date',[$fromDate,$toDate])->where('status','=','1')->where('inv_status','=','1')->where('consignee','=',$selectCashCustomerId)->where('invoice.invoiceType','=','2')->get();
        }else if($selectVoucherStatus == '2' && empty($selectSubItemId) && !empty($selectCashCustomerId)){
            //return 'Eleven';
            $cashSaleInvoiceDetail = Invoice::whereBetween('inv_date',[$fromDate,$toDate])->where('status','=','1')->where('inv_status','=','2')->where('consignee','=',$selectCashCustomerId)->where('invoice.invoiceType','=','2')->get();
        }else if($selectVoucherStatus == '3' && empty($selectSubItemId) && !empty($selectCashCustomerId)){
            //return 'Twelve';
            $cashSaleInvoiceDetail = Invoice::whereBetween('inv_date',[$fromDate,$toDate])->where('status','=','2')->where('consignee','=',$selectCashCustomerId)->where('invoice.invoiceType','=','2')->get();
        }else if($selectVoucherStatus == '0' && !empty($selectSubItemId) && !empty($selectCashCustomerId)){
            //return 'Thirteen';
            $cashSaleInvoiceDetail = DB::table('invoice')
                ->select('invoice.inv_no','invoice.dc_no','invoice.consignee','invoice.inv_date','invoice.inv_against_discount','invoice.inv_status','invoice.status','inv_data.sub_item_id')
                ->join('inv_data', 'invoice.inv_no', '=', 'inv_data.inv_no')
                ->whereBetween('invoice.inv_date',[$fromDate,$toDate])
                ->where('inv_data.sub_item_id','=',$selectSubItemId)
                ->where('invoice.consignee','=',$selectCashCustomerId)
                ->where('invoice.invoiceType','=','2')
                ->groupBy('invoice.inv_no')
                ->get();
        }else if($selectVoucherStatus == '1' && !empty($selectSubItemId) && !empty($selectCashCustomerId)){
            //return 'Fourteen';
            $cashSaleInvoiceDetail = DB::table('invoice')
                ->select('invoice.inv_no','invoice.dc_no','invoice.consignee','invoice.inv_date','invoice.inv_against_discount','invoice.inv_status','invoice.status','inv_data.sub_item_id')
                ->join('inv_data', 'invoice.inv_no', '=', 'inv_data.inv_no')
                ->whereBetween('invoice.inv_date',[$fromDate,$toDate])
                ->where('inv_data.sub_item_id','=',$selectSubItemId)
                ->where('invoice.consignee','=',$selectCashCustomerId)
                ->where('invoice.invoiceType','=','2')
                ->where('invoice.inv_status','=','1')
                ->groupBy('invoice.inv_no')
                ->get();
        }else if($selectVoucherStatus == '2' && !empty($selectSubItemId) && !empty($selectCashCustomerId)){
            //return 'Fifteen';
            $cashSaleInvoiceDetail = DB::table('invoice')
                ->select('invoice.inv_no','invoice.dc_no','invoice.consignee','invoice.inv_date','invoice.inv_against_discount','invoice.inv_status','invoice.status','inv_data.sub_item_id')
                ->join('inv_data', 'invoice.inv_no', '=', 'inv_data.inv_no')
                ->whereBetween('invoice.inv_date',[$fromDate,$toDate])
                ->where('inv_data.sub_item_id','=',$selectSubItemId)
                ->where('invoice.consignee','=',$selectCashCustomerId)
                ->where('invoice.invoiceType','=','2')
                ->where('invoice.inv_status','=','2')
                ->groupBy('invoice.inv_no')
                ->get();
        }else if($selectVoucherStatus == '3' && !empty($selectSubItemId) && !empty($selectCashCustomerId)){
            //return 'Sixteen';
            $cashSaleInvoiceDetail = DB::table('invoice')
                ->select('invoice.inv_no','invoice.dc_no','invoice.consignee','invoice.inv_date','invoice.inv_against_discount','invoice.inv_status','invoice.status','inv_data.sub_item_id')
                ->join('inv_data', 'invoice.inv_no', '=', 'inv_data.inv_no')
                ->whereBetween('invoice.inv_date',[$fromDate,$toDate])
                ->where('inv_data.sub_item_id','=',$selectSubItemId)
                ->where('invoice.consignee','=',$selectCashCustomerId)
                ->where('invoice.invoiceType','=','2')
                ->where('invoice.status','=','2')
                ->groupBy('invoice.inv_no')
                ->get();
        }

        CommonHelper::reconnectMasterDatabase();
        return view('Sales.AjaxPages.filterCashSaleVoucherList',compact('cashSaleInvoiceDetail'));
    }

    public function viewCreditSaleVoucherDetail(){
        return view('Sales.AjaxPages.viewCreditSaleVoucherDetail');
    }

    public function viewCashSaleVoucherDetail(){
        return view('Sales.AjaxPages.viewCashSaleVoucherDetail');
    }


}
