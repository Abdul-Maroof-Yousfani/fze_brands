<?php
namespace App\Http\Controllers;
use Illuminate\Database\DatabaseManager;
use App\Http\Requests;
use Illuminate\Http\Request;
use App\Helpers\FinanceHelper;
use Input;
use Auth;
use DB;
use Config;
use Redirect;
use Session;
class FinanceEditDetailControler extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');

    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */

    function editJournalPendingVoucherDetail(){
        FinanceHelper::companyDatabaseConnection($_GET['m']);

        $jv_no = Input::get('jv_no');
        $id = Input::get('id');
        //   DB::table('jvs')->where('jv_no', $jv_no)->delete();




        $slip_no = Input::get('slip_no');
        $jv_date = Input::get('jv_date');
        $description = Input::get('description');

        $data1['jv_date']   	= $jv_date;
        $data1['jv_no']   		= $jv_no;
        $data1['slip_no']   	= $slip_no;
        $data1['voucherType'] 	= 1;
        $data1['description']   = $description;
        $data1['username'] 		= Auth::user()->name;
        $data1['jv_status']  	= 1;
        $data1['date'] 			= date('Y-m-d');
        $data1['time'] 			= date('H:i:s');

        //  DB::table('jvs')->insert($data1);

        DB::table('jvs')->where('id', $id)->update($data1);
        DB::table('jv_data')->where('master_id', $id)->delete();
        DB::table('transactions')->where('master_id', $id)->where('voucher_type',1)->delete();
        $jvsDataSection = Input::get('jvsDataSection_1');
        foreach($jvsDataSection as $row1){
            $d_amount =  Input::get('d_amount_1_'.$row1.'');
            $c_amount =  Input::get('c_amount_1_'.$row1.'');
            $account  =  Input::get('account_id_1_'.$row1.'');
            if($d_amount !="")
            {
                $data2['debit_credit'] = 1;
                $data2['amount'] = $d_amount;

                $data['debit_credit'] = 1;
                $data['amount'] = $d_amount;
            }
            else if($c_amount !="")

            {
                $data2['debit_credit'] = 0;
                $data2['amount'] = $c_amount;

                $data['debit_credit'] = 0;
                $data['amount'] = $c_amount;
            }

            $data2['jv_no']   		= $jv_no;
            $data2['jv_date']   	= $jv_date;
            $data2['acc_id'] 		= $account;
            $data2['description']   = $description;
            $data2['jv_status']   	= 1;
            $data2['username'] 		= Auth::user()->name;
            $data2['status']  		= 1;
            $data2['date'] 			= date('Y-m-d');
            $data2['time'] 			= date('H:i:s');
            $data2['master_id']=$id;

            DB::table('jv_data')->insert($data2);


            $data['acc_id'] = $account;
            $data['acc_code'] = FinanceHelper::getAccountCodeByAccId($account,'');
            $data['particulars'] =$description;
            $data['opening_bal'] = '0';
            $data['voucher_no'] = $jv_no;
            $data['voucher_type'] = 1;
            $data['v_date'] = $jv_date;
            $data['date'] = date("Y-m-d");
            $data['time'] = date("H:i:s");
            $data['master_id'] = $id;
            $data['username'] = Auth::user()->name;
            DB::table('transactions')->insert($data);
        }
        echo 'Done';
        FinanceHelper::reconnectMasterDatabase();
        Session::flash('dataEdit','successfully edit.');
    }

    function editJournalApproveVoucherDetail(){
        FinanceHelper::companyDatabaseConnection($_GET['m']);

        $jv_no = Input::get('jv_no');

        DB::table('jvs')->where('jv_no', $jv_no)->delete();
        DB::table('jv_data')->where('jv_no', $jv_no)->delete();
        DB::table('transactions')->where('voucher_no', $jv_no)->delete();




        $slip_no = Input::get('slip_no');
        $jv_date = Input::get('jv_date');
        $description = Input::get('description');

        $data1['jv_date']   	= $jv_date;
        $data1['jv_no']   		= $jv_no;
        $data1['slip_no']   	= $slip_no;
        $data1['voucherType'] 	= 1;
        $data1['description']   = $description;
        $data1['username'] 		= Auth::user()->name;
        $data1['jv_status']  	= 2;
        $data1['date'] 			= date('Y-m-d');
        $data1['time'] 			= date('H:i:s');

        DB::table('jvs')->insert($data1);

        $jvsDataSection = Input::get('jvsDataSection_1');
        foreach($jvsDataSection as $row1){
            $d_amount =  Input::get('d_amount_1_'.$row1.'');
            $c_amount =  Input::get('c_amount_1_'.$row1.'');
            $account  =  Input::get('account_id_1_'.$row1.'');
            if($d_amount !=""){
                $data2['debit_credit'] = 1;
                $data2['amount'] = $d_amount;
            }else if($c_amount !=""){
                $data2['debit_credit'] = 0;
                $data2['amount'] = $c_amount;
            }

            $data2['jv_no']   		= $jv_no;
            $data2['jv_date']   	= $jv_date;
            $data2['acc_id'] 		= $account;
            $data2['description']   = $description;
            $data2['jv_status']   	= 2;
            $data2['username'] 		= Auth::user()->name;
            $data2['status']  		= 1;
            $data2['date'] 			= date('Y-m-d');
            $data2['time'] 			= date('H:i:s');

            DB::table('jv_data')->insert($data2);
        }


        $tableTwoDetail = DB::table('jv_data')
            ->where('jv_no', $jv_no)
            ->where('jv_status', '2')->get();
        FinanceHelper::reconnectMasterDatabase();
        foreach ($tableTwoDetail as $row2) {
            $vouceherType = 1;
            $voucherNo = $row2->jv_no;
            $voucherDate = $row2->jv_date;

            $data3['acc_id'] = $row2->acc_id;
            $data3['acc_code'] = FinanceHelper::getAccountCodeByAccId($row2->acc_id,$_GET['m']);
            $data3['particulars'] = $row2->description;
            $data3['opening_bal'] = '0';
            $data3['debit_credit'] = $row2->debit_credit;
            $data3['amount'] = $row2->amount;
            $data3['voucher_no'] = $voucherNo;
            $data3['voucher_type'] = $vouceherType;
            $data3['v_date'] = $voucherDate;
            $data3['date'] = date("Y-m-d");
            $data3['time'] = date("H:i:s");
            $data3['username'] = Auth::user()->name;

            DB::table('transactions')->insert($data3);
            FinanceHelper::reconnectMasterDatabase();
        }
        echo 'Done';
        FinanceHelper::reconnectMasterDatabase();
        Session::flash('dataEdit','successfully edit.');
    }

    function editCashPaymentPendingVoucherDetail(){
        FinanceHelper::companyDatabaseConnection($_GET['m']);


        $id = Input::get('id');
        $pv_no = Input::get('pv_no');





        $slip_no = Input::get('slip_no');
        $pv_date = Input::get('pv_date');
        $description = Input::get('description');

        $data1['pv_date']   	= $pv_date;
        $data1['pv_no']   		= $pv_no;
        $data1['slip_no']   	= $slip_no;
        $data1['voucherType'] 	= 1;
        $data1['description']   = $description;
        $data1['username'] 		= Auth::user()->name;
        $data1['pv_status']  	= 1;
        $data1['date'] 			= date('Y-m-d');
        $data1['time'] 			= date('H:i:s');

        DB::table('pvs')->insert($data1);
        DB::table('pvs')->where('id', $id)->update($data1);


        DB::table('pv_data')->where('master_id', $id)->delete();
        DB::table('transactions')->where('master_id', $id)->where('voucher_type',2)->delete();
        $pvsDataSection = Input::get('pvsDataSection_1');
        foreach($pvsDataSection as $row1){
            $d_amount =  Input::get('d_amount_1_'.$row1.'');
            $c_amount =  Input::get('c_amount_1_'.$row1.'');
            $account  =  Input::get('account_id_1_'.$row1.'');
            if($d_amount !=""){
                $data2['debit_credit'] = 1;
                $data2['amount'] = $d_amount;
                $data['debit_credit'] = 1;
                $data['amount'] = $d_amount;
            }else if($c_amount !=""){
                $data2['debit_credit'] = 0;
                $data2['amount'] = $c_amount;

                $data['debit_credit'] = 0;
                $data['amount'] = $c_amount;
            }

            $data2['pv_no']   		= $pv_no;
            $data2['pv_date']   	= $pv_date;
            $data2['acc_id'] 		= $account;
            $data2['description']   = $description;
            $data2['pv_status']   	= 1;
            $data2['username'] 		= Auth::user()->name;
            $data2['status']  		= 1;
            $data2['date'] 			= date('Y-m-d');
            $data2['time'] 			= date('H:i:s');
            $data2['master_id'] 			=$id;

            DB::table('pv_data')->insert($data2);


            $data['acc_id'] = $account;
            $data['acc_code'] = FinanceHelper::getAccountCodeByAccId($account,'');
            $data['particulars'] =$description;
            $data['opening_bal'] = '0';
            $data['voucher_no'] = $pv_no;
            $data['voucher_type'] = 2;
            $data['v_date'] = $pv_date;
            $data['date'] = date("Y-m-d");
            $data['time'] = date("H:i:s");
            $data['master_id'] = $id;
            $data['username'] = Auth::user()->name;
            DB::table('transactions')->insert($data);
        }
        echo 'Done';
        FinanceHelper::reconnectMasterDatabase();
        Session::flash('dataEdit','successfully edit.');
    }

    function editCashPaymentApproveVoucherDetail(){
        FinanceHelper::companyDatabaseConnection($_GET['m']);

        $pv_no = Input::get('pv_no');

        DB::table('pvs')->where('pv_no', $pv_no)->delete();
        DB::table('pv_data')->where('pv_no', $pv_no)->delete();
        DB::table('transactions')->where('voucher_no', $pv_no)->delete();



        $slip_no = Input::get('slip_no');
        $pv_date = Input::get('pv_date');
        $description = Input::get('description');

        $data1['pv_date']   	= $pv_date;
        $data1['pv_no']   		= $pv_no;
        $data1['slip_no']   	= $slip_no;
        $data1['voucherType'] 	= 1;
        $data1['description']   = $description;
        $data1['username'] 		= Auth::user()->name;
        $data1['pv_status']  	= 2;
        $data1['date'] 			= date('Y-m-d');
        $data1['time'] 			= date('H:i:s');

        DB::table('pvs')->insert($data1);

        $pvsDataSection = Input::get('pvsDataSection_1');
        foreach($pvsDataSection as $row1){
            $d_amount =  Input::get('d_amount_1_'.$row1.'');
            $c_amount =  Input::get('c_amount_1_'.$row1.'');
            $account  =  Input::get('account_id_1_'.$row1.'');
            if($d_amount !=""){
                $data2['debit_credit'] = 1;
                $data2['amount'] = $d_amount;
            }else if($c_amount !=""){
                $data2['debit_credit'] = 0;
                $data2['amount'] = $c_amount;
            }

            $data2['pv_no']   		= $pv_no;
            $data2['pv_date']   	= $pv_date;
            $data2['acc_id'] 		= $account;
            $data2['description']   = $description;
            $data2['pv_status']   	= 2;
            $data2['username'] 		= Auth::user()->name;
            $data2['status']  		= 1;
            $data2['date'] 			= date('Y-m-d');
            $data2['time'] 			= date('H:i:s');

            DB::table('pv_data')->insert($data2);
        }


        $tableTwoDetail = DB::table('pv_data')
            ->where('pv_no', $pv_no)
            ->where('pv_status', '2')->get();
        FinanceHelper::reconnectMasterDatabase();
        foreach ($tableTwoDetail as $row2) {
            $vouceherType = 2;
            $voucherNo = $row2->pv_no;
            $voucherDate = $row2->pv_date;

            $data3['acc_id'] = $row2->acc_id;
            $data3['acc_code'] = FinanceHelper::getAccountCodeByAccId($row2->acc_id,$_GET['m']);
            $data3['particulars'] = $row2->description;
            $data3['opening_bal'] = '0';
            $data3['debit_credit'] = $row2->debit_credit;
            $data3['amount'] = $row2->amount;
            $data3['voucher_no'] = $voucherNo;
            $data3['voucher_type'] = $vouceherType;
            $data3['v_date'] = $voucherDate;
            $data3['date'] = date("Y-m-d");
            $data3['time'] = date("H:i:s");
            $data3['username'] = Auth::user()->name;

            DB::table('transactions')->insert($data3);
            FinanceHelper::reconnectMasterDatabase();
        }
        echo 'Done';
        FinanceHelper::reconnectMasterDatabase();
        Session::flash('dataEdit','successfully edit.');
    }

    function editBankPaymentPendingVoucherDetail(){
        FinanceHelper::companyDatabaseConnection($_GET['m']);
        $id = Input::get('id');
        $pv_no = Input::get('pv_no');

        //DB::table('pvs')->where('pv_no', $pv_no)->delete();




        $slip_no = Input::get('slip_no');
        $pv_date = Input::get('pv_date');
        $description = Input::get('description');
        $cheque_no = Input::get('cheque_no');
        $cheque_date = Input::get('cheque_date');

        $data1['pv_date']   	= $pv_date;
        $data1['pv_no']   		= $pv_no;
        $data1['slip_no']   	= $slip_no;
        $data1['cheque_no']   	= $cheque_no;
        $data1['cheque_date']   = $cheque_date;
        $data1['voucherType'] 	= 2;
        $data1['description']   = $description;
        $data1['username'] 		= Auth::user()->name;
        $data1['pv_status']  	= 1;
        $data1['date'] 			= date('Y-m-d');
        $data1['time'] 			= date('H:i:s');
        DB::table('pvs')->where('id', $id)->update($data1);
        //   DB::table('pvs')->insert($data1);
        DB::table('pv_data')->where('master_id', $id)->delete();
        DB::table('transactions')->where('master_id', $id)->where('voucher_type',2)->delete();
        $pvsDataSection = Input::get('pvsDataSection_1');
        foreach($pvsDataSection as $row1){
            $d_amount =  Input::get('d_amount_1_'.$row1.'');
            $c_amount =  Input::get('c_amount_1_'.$row1.'');
            $account  =  Input::get('account_id_1_'.$row1.'');
            if($d_amount !=""){
                $data2['debit_credit'] = 1;
                $data2['amount'] = $d_amount;

                $data['debit_credit'] = 1;
                $data['amount'] = $d_amount;
            }else if($c_amount !=""){
                $data2['debit_credit'] = 0;
                $data2['amount'] = $c_amount;

                $data['debit_credit'] = 0;
                $data['amount'] = $c_amount;
            }

            $data2['pv_no']   		= $pv_no;
            $data2['pv_date']   	= $pv_date;
            $data2['acc_id'] 		= $account;
            $data2['description']   = $description;
            $data2['pv_status']   	= 1;
            $data2['username'] 		= Auth::user()->name;
            $data2['status']  		= 1;
            $data2['date'] 			= date('Y-m-d');
            $data2['time'] 			= date('H:i:s');
            $data2['master_id'] 			= $id;

            DB::table('pv_data')->insert($data2);

            $data['acc_id'] = $account;
            $data['acc_code'] = FinanceHelper::getAccountCodeByAccId($account,'');
            $data['particulars'] =$description;
            $data['opening_bal'] = '0';
            $data['voucher_no'] = $pv_no;
            $data['voucher_type'] = 2;
            $data['v_date'] = $pv_date;
            $data['date'] = date("Y-m-d");
            $data['time'] = date("H:i:s");
            $data['master_id'] = $id;
            $data['username'] = Auth::user()->name;
            DB::table('transactions')->insert($data);

        }
        echo 'Done';
        FinanceHelper::reconnectMasterDatabase();
        Session::flash('dataEdit','successfully edit.');
    }

    function editBankPaymentApproveVoucherDetail(){
        FinanceHelper::companyDatabaseConnection($_GET['m']);

        $pv_no = Input::get('pv_no');

        DB::table('pvs')->where('pv_no', $pv_no)->delete();
        DB::table('pv_data')->where('pv_no', $pv_no)->delete();
        DB::table('transactions')->where('voucher_no', $pv_no)->delete();



        $slip_no = Input::get('slip_no');
        $pv_date = Input::get('pv_date');
        $description = Input::get('description');
        $cheque_no = Input::get('cheque_no');
        $cheque_date = Input::get('cheque_date');

        $data1['pv_date']   	= $pv_date;
        $data1['pv_no']   		= $pv_no;
        $data1['slip_no']   	= $slip_no;
        $data1['cheque_no']   	= $cheque_no;
        $data1['cheque_date']   = $cheque_date;
        $data1['voucherType'] 	= 2;
        $data1['description']   = $description;
        $data1['username'] 		= Auth::user()->name;
        $data1['pv_status']  	= 2;
        $data1['date'] 			= date('Y-m-d');
        $data1['time'] 			= date('H:i:s');

        DB::table('pvs')->insert($data1);

        $pvsDataSection = Input::get('pvsDataSection_1');
        foreach($pvsDataSection as $row1){
            $d_amount =  Input::get('d_amount_1_'.$row1.'');
            $c_amount =  Input::get('c_amount_1_'.$row1.'');
            $account  =  Input::get('account_id_1_'.$row1.'');
            if($d_amount !=""){
                $data2['debit_credit'] = 1;
                $data2['amount'] = $d_amount;
            }else if($c_amount !=""){
                $data2['debit_credit'] = 0;
                $data2['amount'] = $c_amount;
            }

            $data2['pv_no']   		= $pv_no;
            $data2['pv_date']   	= $pv_date;
            $data2['acc_id'] 		= $account;
            $data2['description']   = $description;
            $data2['pv_status']   	= 2;
            $data2['username'] 		= Auth::user()->name;
            $data2['status']  		= 1;
            $data2['date'] 			= date('Y-m-d');
            $data2['time'] 			= date('H:i:s');

            DB::table('pv_data')->insert($data2);
        }


        $tableTwoDetail = DB::table('pv_data')
            ->where('pv_no', $pv_no)
            ->where('pv_status', '2')->get();
        FinanceHelper::reconnectMasterDatabase();
        foreach ($tableTwoDetail as $row2) {
            $vouceherType = 2;
            $voucherNo = $row2->pv_no;
            $voucherDate = $row2->pv_date;

            $data3['acc_id'] = $row2->acc_id;
            $data3['acc_code'] = FinanceHelper::getAccountCodeByAccId($row2->acc_id,$_GET['m']);
            $data3['particulars'] = $row2->description;
            $data3['opening_bal'] = '0';
            $data3['debit_credit'] = $row2->debit_credit;
            $data3['amount'] = $row2->amount;
            $data3['voucher_no'] = $voucherNo;
            $data3['voucher_type'] = $vouceherType;
            $data3['v_date'] = $voucherDate;
            $data3['date'] = date("Y-m-d");
            $data3['time'] = date("H:i:s");
            $data3['username'] = Auth::user()->name;

            DB::table('transactions')->insert($data3);
            FinanceHelper::reconnectMasterDatabase();
        }
        echo 'Done';
        FinanceHelper::reconnectMasterDatabase();
        Session::flash('dataEdit','successfully edit.');
    }


    function editCashReceiptPendingVoucherDetail(){
        FinanceHelper::companyDatabaseConnection($_GET['m']);

        $rv_no = Input::get('rv_no');
        $id = Input::get('id');
        //	DB::table('rvs')->where('rv_no', $rv_no)->delete();




        $slip_no = Input::get('slip_no');
        $rv_date = Input::get('rv_date');
        $description = Input::get('description');

        $data1['rv_date']   	= $rv_date;
        $data1['rv_no']   		= $rv_no;
        $data1['slip_no']   	= $slip_no;
        $data1['voucherType'] 	= 1;
        $data1['description']   = $description;
        $data1['username'] 		= Auth::user()->name;
        $data1['rv_status']  	= 1;
        $data1['date'] 			= date('Y-m-d');
        $data1['time'] 			= date('H:i:s');

        // DB::table('rvs')->insert($data1);
        DB::table('rvs')->where('id', $id)->update($data1);
        DB::table('rv_data')->where('master_id', $id)->delete();
        DB::table('transactions')->where('master_id', $id)->where('voucher_type',3)->delete();
        $rvsDataSection = Input::get('rvsDataSection_1');
        foreach($rvsDataSection as $row1){
            $d_amount =  Input::get('d_amount_1_'.$row1.'');
            $c_amount =  Input::get('c_amount_1_'.$row1.'');
            $account  =  Input::get('account_id_1_'.$row1.'');
            if($d_amount !="")
            {
                $data2['debit_credit'] = 1;
                $data2['amount'] = $d_amount;

                $data['debit_credit'] = 1;
                $data['amount'] = $d_amount;
            }
            else if($c_amount !="")
            {
                $data2['debit_credit'] = 0;
                $data2['amount'] = $c_amount;

                $data['debit_credit'] = 0;
                $data['amount'] = $c_amount;
            }

            $data2['rv_no']   		= $rv_no;
            $data2['rv_date']   	= $rv_date;
            $data2['acc_id'] 		= $account;
            $data2['description']   = $description;
            $data2['rv_status']   	= 1;
            $data2['username'] 		= Auth::user()->name;
            $data2['status']  		= 1;
            $data2['date'] 			= date('Y-m-d');
            $data2['time'] 			= date('H:i:s');
            $data2['master_id']         =$id;

            DB::table('rv_data')->insert($data2);

            $data['acc_id'] = $account;
            $data['acc_code'] = FinanceHelper::getAccountCodeByAccId($account,'');
            $data['particulars'] =$description;
            $data['opening_bal'] = '0';
            $data['voucher_no'] = $rv_no;
            $data['voucher_type'] = 3;
            $data['v_date'] = $rv_date;
            $data['date'] = date("Y-m-d");
            $data['time'] = date("H:i:s");
            $data['master_id'] = $id;
            $data['username'] = Auth::user()->name;
            DB::table('transactions')->insert($data);
        }
        echo 'Done';
        FinanceHelper::reconnectMasterDatabase();
        Session::flash('dataEdit','successfully edit.');
    }

    function editCashReceiptApproveVoucherDetail(){
        FinanceHelper::companyDatabaseConnection($_GET['m']);

        $rv_no = Input::get('rv_no');

        DB::table('rvs')->where('rv_no', $rv_no)->delete();
        DB::table('rv_data')->where('rv_no', $rv_no)->delete();
        DB::table('transactions')->where('voucher_no', $rv_no)->delete();



        $slip_no = Input::get('slip_no');
        $rv_date = Input::get('rv_date');
        $description = Input::get('description');

        $data1['rv_date']   	= $rv_date;
        $data1['rv_no']   		= $rv_no;
        $data1['slip_no']   	= $slip_no;
        $data1['voucherType'] 	= 1;
        $data1['description']   = $description;
        $data1['username'] 		= Auth::user()->name;
        $data1['rv_status']  	= 2;
        $data1['date'] 			= date('Y-m-d');
        $data1['time'] 			= date('H:i:s');

        DB::table('rvs')->insert($data1);

        $rvsDataSection = Input::get('rvsDataSection_1');
        foreach($rvsDataSection as $row1){
            $d_amount =  Input::get('d_amount_1_'.$row1.'');
            $c_amount =  Input::get('c_amount_1_'.$row1.'');
            $account  =  Input::get('account_id_1_'.$row1.'');
            if($d_amount !=""){
                $data2['debit_credit'] = 1;
                $data2['amount'] = $d_amount;
            }else if($c_amount !=""){
                $data2['debit_credit'] = 0;
                $data2['amount'] = $c_amount;
            }

            $data2['rv_no']   		= $rv_no;
            $data2['rv_date']   	= $rv_date;
            $data2['acc_id'] 		= $account;
            $data2['description']   = $description;
            $data2['rv_status']   	= 2;
            $data2['username'] 		= Auth::user()->name;
            $data2['status']  		= 1;
            $data2['date'] 			= date('Y-m-d');
            $data2['time'] 			= date('H:i:s');

            DB::table('rv_data')->insert($data2);
        }


        $tableTwoDetail = DB::table('rv_data')
            ->where('rv_no', $rv_no)
            ->where('rv_status', '2')->get();
        FinanceHelper::reconnectMasterDatabase();
        foreach ($tableTwoDetail as $row2) {
            $vouceherType = 2;
            $voucherNo = $row2->rv_no;
            $voucherDate = $row2->rv_date;

            $data3['acc_id'] = $row2->acc_id;
            $data3['acc_code'] = FinanceHelper::getAccountCodeByAccId($row2->acc_id,$_GET['m']);
            $data3['particulars'] = $row2->description;
            $data3['opening_bal'] = '0';
            $data3['debit_credit'] = $row2->debit_credit;
            $data3['amount'] = $row2->amount;
            $data3['voucher_no'] = $voucherNo;
            $data3['voucher_type'] = $vouceherType;
            $data3['v_date'] = $voucherDate;
            $data3['date'] = date("Y-m-d");
            $data3['time'] = date("H:i:s");
            $data3['username'] = Auth::user()->name;

            DB::table('transactions')->insert($data3);
            FinanceHelper::reconnectMasterDatabase();
        }
        echo 'Done';
        FinanceHelper::reconnectMasterDatabase();
        Session::flash('dataEdit','successfully edit.');
    }


    function editBankReceiptPendingVoucherDetail(){
        FinanceHelper::companyDatabaseConnection($_GET['m']);
        DB::beginTransaction();
        try {
            $id = Input::get('id');
            $rv_no = Input::get('rv_no');

            //	DB::table('rvs')->where('rv_no', $rv_no)->delete();
            //	DB::table('rv_data')->where('rv_no', $rv_no)->delete();
            $slip_no = Input::get('slip_no');
            $rv_date = Input::get('rv_date');
            $description = Input::get('description');
            $cheque_no = Input::get('cheque_no');
            $cheque_date = Input::get('cheque_date');

            $data1['rv_date'] = $rv_date;
            $data1['rv_no'] = $rv_no;
            $data1['slip_no'] = $slip_no;
            $data1['cheque_no'] = $cheque_no;
            $data1['cheque_date'] = $cheque_date;
            $data1['voucherType'] = 2;
            $data1['description'] = $description;
            $data1['username'] = Auth::user()->name;
            $data1['rv_status'] = 1;
            $data1['date'] = date('Y-m-d');
            $data1['time'] = date('H:i:s');

            // DB::table('rvs')->insert($data1);
            DB::table('rvs')->where('id', $id)->update($data1);
          DB::table('rv_data')->where('master_id', $id)->delete();
            DB::table('transactions')->where('master_id', $id)->where('voucher_type',3)->delete();
            $rvsDataSection = Input::get('rvsDataSection_1');
            foreach ($rvsDataSection as $row1) {
                $d_amount = Input::get('d_amount_1_' . $row1 . '');
                $c_amount = Input::get('c_amount_1_' . $row1 . '');
                $account = Input::get('account_id_1_' . $row1 . '');
                if ($d_amount != "")
                {
                    $data2['debit_credit'] = 1;
                    $data2['amount'] = $d_amount;

                    $data['debit_credit'] = 1;
                    $data['amount'] = $d_amount;
                }
                else if ($c_amount != "")
                {
                    $data2['debit_credit'] = 0;
                    $data2['amount'] = $c_amount;

                    $data['debit_credit'] = 0;
                    $data['amount'] = $c_amount;
                }

                $data2['rv_no'] = $rv_no;
                $data2['rv_date'] = $rv_date;
                $data2['acc_id'] = $account;
                $data2['description'] = $description;

                $data2['username'] = Auth::user()->name;
                $data2['status'] = 1;
                $data2['date'] = date('Y-m-d');
                $data2['time'] = date('H:i:s');
                $data2['master_id'] = $id;


                DB::table('rv_data')->insert($data2);


                $data['acc_id'] = $account;
                $data['acc_code'] = FinanceHelper::getAccountCodeByAccId($account,'');
                $data['particulars'] =$description;
                $data['opening_bal'] = '0';
                $data['voucher_no'] = $rv_no;
                $data['voucher_type'] = 3;
                $data['v_date'] = $rv_date;
                $data['date'] = date("Y-m-d");
                $data['time'] = date("H:i:s");
                $data['master_id'] = $id;
                $data['username'] = Auth::user()->name;
                DB::table('transactions')->insert($data);
            }
            echo 'Done';
            DB::commit();

        }
        catch(Exception $e)
        {
            DB::rollback();
        }
        FinanceHelper::reconnectMasterDatabase();
        Session::flash('dataEdit','successfully edit.');
    }

    function editBankReceiptApproveVoucherDetail(){
        FinanceHelper::companyDatabaseConnection($_GET['m']);

        $rv_no = Input::get('rv_no');

        DB::table('rvs')->where('rv_no', $rv_no)->delete();
        DB::table('rv_data')->where('rv_no', $rv_no)->delete();
        DB::table('transactions')->where('voucher_no', $rv_no)->delete();



        $slip_no = Input::get('slip_no');
        $rv_date = Input::get('rv_date');
        $description = Input::get('description');
        $cheque_no = Input::get('cheque_no');
        $cheque_date = Input::get('cheque_date');

        $data1['rv_date']   	= $rv_date;
        $data1['rv_no']   		= $rv_no;
        $data1['slip_no']   	= $slip_no;
        $data1['cheque_no']   	= $cheque_no;
        $data1['cheque_date']   = $cheque_date;
        $data1['voucherType'] 	= 2;
        $data1['description']   = $description;
        $data1['username'] 		= Auth::user()->name;
        $data1['rv_status']  	= 2;
        $data1['date'] 			= date('Y-m-d');
        $data1['time'] 			= date('H:i:s');

        DB::table('rvs')->insert($data1);

        $rvsDataSection = Input::get('rvsDataSection_1');
        foreach($rvsDataSection as $row1){
            $d_amount =  Input::get('d_amount_1_'.$row1.'');
            $c_amount =  Input::get('c_amount_1_'.$row1.'');
            $account  =  Input::get('account_id_1_'.$row1.'');
            if($d_amount !=""){
                $data2['debit_credit'] = 1;
                $data2['amount'] = $d_amount;
            }else if($c_amount !=""){
                $data2['debit_credit'] = 0;
                $data2['amount'] = $c_amount;
            }

            $data2['rv_no']   		= $rv_no;
            $data2['rv_date']   	= $rv_date;
            $data2['acc_id'] 		= $account;
            $data2['description']   = $description;
            $data2['rv_status']   	= 2;
            $data2['username'] 		= Auth::user()->name;
            $data2['status']  		= 1;
            $data2['date'] 			= date('Y-m-d');
            $data2['time'] 			= date('H:i:s');

            DB::table('rv_data')->insert($data2);
        }


        $tableTwoDetail = DB::table('rv_data')
            ->where('rv_no', $rv_no)
            ->where('rv_status', '2')->get();
        FinanceHelper::reconnectMasterDatabase();
        foreach ($tableTwoDetail as $row2) {
            $vouceherType = 2;
            $voucherNo = $row2->rv_no;
            $voucherDate = $row2->rv_date;

            $data3['acc_id'] = $row2->acc_id;
            $data3['acc_code'] = FinanceHelper::getAccountCodeByAccId($row2->acc_id,$_GET['m']);
            $data3['particulars'] = $row2->description;
            $data3['opening_bal'] = '0';
            $data3['debit_credit'] = $row2->debit_credit;
            $data3['amount'] = $row2->amount;
            $data3['voucher_no'] = $voucherNo;
            $data3['voucher_type'] = $vouceherType;
            $data3['v_date'] = $voucherDate;
            $data3['date'] = date("Y-m-d");
            $data3['time'] = date("H:i:s");
            $data3['username'] = Auth::user()->name;

            DB::table('transactions')->insert($data3);
            FinanceHelper::reconnectMasterDatabase();
        }
        echo 'Done';
        FinanceHelper::reconnectMasterDatabase();
        Session::flash('dataEdit','successfully edit.');
    }
    public function editEmployeeDetail()
    {
        FinanceHelper::companyDatabaseConnection(Input::get('company_id'));

        $employeeSection = Input::get('employeeSection');
        foreach($employeeSection as $row){
            $employee_name = Input::get('employee_name_'.$row.'');
            $father_name = Input::get('father_name_'.$row.'');
            $sub_department_id = Input::get('sub_department_id_'.$row.'');
            $date_of_birth = Input::get('date_of_birth_'.$row.'');
            $joining_date = Input::get('joining_date_'.$row.'');
            $gender = Input::get('gender_'.$row.'');
            $cnic = Input::get('cnic_'.$row.'');
            $contact_no = Input::get('contact_no_'.$row.'');
            $employee_status = Input::get('employee_status_'.$row.'');
            $salary = Input::get('salary_'.$row.'');
            $email = Input::get('email_'.$row.'');
            $marital_status = Input::get('marital_status_'.$row.'');
            //$department_name = Input::get('department_name');

            $str = DB::selectOne("select max(convert(substr(`emp_no`,4,length(substr(`emp_no`,4))-4),signed integer)) reg from `employee` where substr(`emp_no`,-4,2) = ".date('m')." and substr(`emp_no`,-2,2) = ".date('y')."")->reg;
            $employee_no = 'Emp'.($str+1).date('my');

            $data1['emp_no'] 				 = strip_tags($employee_no);
            $data1['emp_name'] 				 = strip_tags($employee_name);
            $data1['emp_father_name'] 		 = strip_tags($father_name);
            $data1['emp_sub_department_id'] 	 = strip_tags($sub_department_id);
            $data1['emp_date_of_birth'] 	 = strip_tags($date_of_birth);
            $data1['emp_joining_date'] 		 = strip_tags($joining_date);
            $data1['emp_gender'] 			 = strip_tags($gender);
            $data1['emp_cnic'] 				 = strip_tags($cnic);
            $data1['emp_contact_no'] 		 = strip_tags($contact_no);
            $data1['emp_employementstatus_id'] = strip_tags($employee_status);
            $data1['emp_salary'] 			 = strip_tags($salary);
            $data1['emp_email'] 			 = strip_tags($email);
            $data1['emp_marital_status'] 	 = strip_tags($marital_status);
            $data1['username'] 		 		 = Auth::user()->name;
            $data1['status'] 		 		 = 1;
            $data1['date']     		  		 = date("Y-m-d");
            $data1['time']     		  		 = date("H:i:s");


            DB::table('employee')->where('id', Input::get('id'))->update($data1);
        }


        FinanceHelper::reconnectMasterDatabase();
        Session::flash('dataInsert','successfully saved.');
        return Redirect::to('hr/viewEmployeeList?pageType=viewlist&&parentCode=20&&m='.Input::get('company_id').'');

    }


}
