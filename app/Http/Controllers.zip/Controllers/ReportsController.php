<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use Illuminate\Http\Request;

class ReportsController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function toDayActivity()
    {
        return view('Reports.toDayActivity');
    }

    public function viewBankDepositSummary(){
        return view('Reports.Finance.BankingReport.viewBankDepositSummary');
    }

    public function viewBranchPerformanceReports(){
        return view('Reports.Finance.PerformanceReports.viewBranchPerformanceReports');
    }

    public function viewBranchExpenseSummaryReports(){
        return view('Reports.Finance.PerformanceReports.viewBranchExpenseSummaryReports');
    }

    public function viewBranchExpenseSummaryDetailReports(){
        return view('Reports.Finance.PerformanceReports.viewBranchExpenseSummaryDetailReports');
    }

    public function viewInventoryPerformanceDetailReports(){
        return view('Reports.Inventory.viewInventoryPerformanceDetailReports');
    }




}
