<?php
namespace App\Http\Controllers;


use App\Http\Requests;
use App\Helpers\CommonHelper;
use App\Models\Cities;
use App\Models\Test;
use App\Models\Deduction;
use App\Models\States;
use Hamcrest\Core\AllOf;
use Illuminate\Http\Request;
use App\Models\Department;
use App\Models\SubDepartment;
use App\Models\Employee;
use App\Models\Allowance;
use App\Models\Attendence;
use App\Models\Designation;
use App\Models\HealthInsurance;
use App\Models\LifeInsurance;
use App\Models\JobType;
use App\Models\Countries;
use App\Models\Institute;
use App\Models\Qualification;
use App\Models\LeaveType;
use App\Models\LoanType;
use App\Models\AdvanceType;
use App\Models\ShiftType;
use App\Models\MaritalStatus;
use App\Models\EmployeeRequisition;
use App\Models\Job;
use App\Models\AdvanceSalary;
use App\Models\LeavesPolicy;
use App\Models\LeavesData;
use App\Models\VehicleType;
use App\Models\CarPolicy;
use App\Models\LoanRequest;
use App\Models\Eobi;
use App\Models\Tax;
use App\Models\Bonus;
use App\Models\LeaveApplication;
use App\Models\DegreeType;
use App\Models\EmployeeSalaryDetail;
use App\Models\EmployeeWorkExperience;
use App\Models\EmployeeReference;
use App\Models\EmployeeQualification;
use App\Models\EmployeeExitClearance;
use App\Models\EmployeeExitInterview;
use App\Models\EmployeeProbationaryPeriod;
use App\Models\Holidays;





use Input;
use Auth;
use DB;
use Config;

use Illuminate\Pagination\LengthAwarePaginator;
class HrController extends Controller
{
	/**
	 * Create a new controller instance.
	 *
	 * @return void
	 */
	public function __construct()
	{
		$this->middleware('auth');
	}

	/**
	 * Show the application dashboard.
	 *
	 * @return \Illuminate\Http\Response
	 */

	public function toDayActivity()
	{
		return view('Hr.toDayActivity');
	}


	public function departmentAddNView()
	{
		return view('Hr.departmentAddNView');
	}

	public function createDepartmentForm()
	{
		return view('Hr.createDepartmentForm');
	}

	public function viewDepartmentList()
	{
		$page = LengthAwarePaginator::resolveCurrentPage();
		$total = DB::table('department')->where('company_id', '=', $_GET['m'])->count('id'); //Count the total record
		$perPage = 10;

		//Set the limit and offset for a given page.
		$results = DB::table('department')->forPage($page, $perPage)->where('company_id', '=', $_GET['m'])->get(['id', 'department_name', 'status', 'username']);
		$departments = new LengthAwarePaginator($results, $total, $perPage, $page, [
			'path' => LengthAwarePaginator::resolveCurrentPath()
		]);
		return view('Hr.viewDepartmentList', ['departments' => $departments]);
	}

	public function editDepartmentForm()
	{
		return view('Hr.editDepartmentForm');
	}

	public function createSubDepartmentForm()
	{

		$departments = Department::where('company_id', '=', $_GET['m'])->where('status', '=', '1')->orderBy('id')->get();
		return view('Hr.createSubDepartmentForm', compact('departments'));
	}

	public function viewSubDepartmentList()
	{
		$page = LengthAwarePaginator::resolveCurrentPage();
		$total = DB::table('sub_department')->where('company_id', '=', $_GET['m'])->count('id'); //Count the total record
		$perPage = 10;

		//Set the limit and offset for a given page.
		$results = DB::table('sub_department')->forPage($page, $perPage)->where('company_id', '=', $_GET['m'])->get(['id', 'department_id', 'sub_department_name', 'status', 'username']);
		$SubDepartments = new LengthAwarePaginator($results, $total, $perPage, $page, [
			'path' => LengthAwarePaginator::resolveCurrentPath()
		]);
		return view('Hr.viewSubDepartmentList', ['SubDepartments' => $SubDepartments]);
	}
	public function viewEmployeeExitInterviewList()
	{

		$employe_exit_interview=new EmployeeExitInterview();
		$employe_exit_interview=$employe_exit_interview->SetConnection('mysql2');
		$employe_exit_interview=$employe_exit_interview->where('status',1)->get(['emp_id','dos','reporting_to']);
		return view('Hr.viewEmployeeExitInterviewList', compact('employe_exit_interview'));
	}


	public function viewEmployeeProbationaryPeriodList()
	{

		$employe_probationary=new EmployeeProbationaryPeriod();
		$employe_probationary=$employe_probationary->SetConnection('mysql2');
		$employe_probationary=$employe_probationary->where('status',1)->get(['emp_id','location','immidaite_supervisor']);
		return view('Hr.viewEmployeeProbationaryPeriodList', compact('employe_probationary'));
	}

	public function editSubDepartmentForm()
	{
		$departments = new Department;
		$departments = $departments::where('company_id', '=', $_GET['m'])->where('status', '=', '1')->orderBy('id')->get();
		return view('Hr.editSubDepartmentForm', compact('departments'));
	}

	public function createDesignationForm()
	{
		return view('Hr.createDesignationForm');
	}

	public function viewDesignationList()
	{

		$designations = Designation::where([['company_id', '=', Input::get('m')]])->get();
		return view('Hr.viewDesignationList', ['designations' => $designations]);

	}

	public function editDesignationForm()
	{
		return view('Hr.editDesignationForm');
	}

	public function createHealthInsuranceForm()
	{
		return view('Hr.createHealthInsuranceForm');
	}

	public function viewHealthInsuranceList()
	{

		$HealthInsurances = HealthInsurance::where([['company_id', '=', Input::get('m')]])->get();
		return view('Hr.viewHealthInsuranceList', ['HealthInsurances' => $HealthInsurances]);
	}

	public function editHealthInsuranceForm()
	{
		return view('Hr.editHealthInsuranceForm');
	}


	public function createLifeInsuranceForm()
	{
		return view('Hr.createLifeInsuranceForm');
	}

	public function viewLifeInsuranceList()
	{
		$page = LengthAwarePaginator::resolveCurrentPage();
		$total = DB::table('life_insurance')->where('status', '=', '1')->where('company_id', '=', $_GET['m'])->count('id'); //Count the total record
		$perPage = 10;

		//Set the limit and offset for a given page.
		$results = DB::table('life_insurance')->forPage($page, $perPage)->where('status', '=', '1')->where('company_id', '=', $_GET['m'])->get(['id', 'life_insurance_name', 'username', 'status']);
		$LifeInsurances = new LengthAwarePaginator($results, $total, $perPage, $page, [
			'path' => LengthAwarePaginator::resolveCurrentPath()
		]);
		return view('Hr.viewLifeInsuranceList', ['LifeInsurances' => $LifeInsurances]);
	}

	public function editLifeInsuranceForm()
	{
		return view('Hr.editLifeInsuranceForm');
	}


	public function createJobTypeForm()
	{
		return view('Hr.createJobTypeForm');
	}

	public function viewJobTypeList()
	{
		$JobTypes = JobType::all();
		return view('Hr.viewJobTypeList', compact('JobTypes'));
	}

	public function editJobTypeForm()
	{
		return view('Hr.editJobTypeForm');
	}

	public function createQualificationForm()
	{

		$countries = Countries::where('status', '=', 1)->get();
		$institutes = Institute::where('status', '=', 1)->get();

		return view('Hr.createQualificationForm', compact('countries', 'institutes'));
	}

	public function viewQualificationList()
	{

		$page = LengthAwarePaginator::resolveCurrentPage();
		$total = DB::table('qualification')->where('company_id', '=', $_GET['m'])->count('id'); //Count the total record
		$perPage = 10;

		//Set the limit and offset for a given page.
		$results = DB::table('qualification')->forPage($page, $perPage)->where('company_id', '=', $_GET['m'])->get(['id', 'status', 'qualification_name', 'institute_id', 'country_id', 'state_id', 'city_id', 'username']);
		$Qualifications = new LengthAwarePaginator($results, $total, $perPage, $page, [
			'path' => LengthAwarePaginator::resolveCurrentPath()
		]);
		return view('Hr.viewQualificationList', ['Qualifications' => $Qualifications]);
	}

	public function editQualificationForm()
	{
		$qualificationDetail = DB::selectOne('select * from `qualification` where `id` = ' . Input::get('id') . '');
		$countries = Countries::where('status', '=', 1)->get();
		$states = States::where([['status', '=', 1], ['country_id', '=', $qualificationDetail->country_id]])->get();
		$cities = Cities::where([['status', '=', 1], ['state_id', '=', $qualificationDetail->state_id]])->get();
		$institutes = Institute::where('status', '=', 1)->get();
		return view('Hr.editQualificationForm', compact('states', 'cities', 'qualificationDetail', 'countries', 'institutes'));
	}

	public function createLeaveTypeForm()
	{
		return view('Hr.createLeaveTypeForm');
	}

	public function viewLeaveTypeList()
	{

		$LeaveTypes = LeaveType::all();
		return view('Hr.viewLeaveTypeList', ['LeaveTypes' => $LeaveTypes]);
	}

	public function editLeaveTypeForm()
	{
		return view('Hr.editLeaveTypeForm');
	}

	public function createLoanTypeForm()
	{
		return view('Hr.createLoanTypeForm');
	}

	public function viewLoanTypeList()
	{

		$page = LengthAwarePaginator::resolveCurrentPage();
		$total = DB::table('loan_type')->where('status', '=', '1')->where('company_id', '=', $_GET['m'])->count('id'); //Count the total record
		$perPage = 10;

		//Set the limit and offset for a given page.
		$results = DB::table('loan_type')->forPage($page, $perPage)->where('status', '=', '1')->where('company_id', '=', $_GET['m'])->get(['id', 'loan_type_name', 'username', 'status']);
		$LoanTypes = new LengthAwarePaginator($results, $total, $perPage, $page, [
			'path' => LengthAwarePaginator::resolveCurrentPath()
		]);
		return view('Hr.viewLoanTypeList', ['LoanTypes' => $LoanTypes]);
	}

	public function editLoanTypeForm()
	{
		return view('Hr.editLoanTypeForm');
	}

	public function createAdvanceTypeForm()
	{
		return view('Hr.createAdvanceTypeForm');
	}

	public function viewAdvanceTypeList()
	{

		$page = LengthAwarePaginator::resolveCurrentPage();
		$total = DB::table('advance_type')->where('status', '=', '1')->where('company_id', '=', $_GET['m'])->count('id'); //Count the total record
		$perPage = 10;

		//Set the limit and offset for a given page.
		$results = DB::table('advance_type')->forPage($page, $perPage)->where('status', '=', '1')->where('company_id', '=', $_GET['m'])->get(['id', 'advance_type_name', 'username', 'status']);
		$AdvanceTypes = new LengthAwarePaginator($results, $total, $perPage, $page, [
			'path' => LengthAwarePaginator::resolveCurrentPath()
		]);
		return view('Hr.viewAdvanceTypeList', ['AdvanceTypes' => $AdvanceTypes]);
	}

	public function editAdvanceTypeForm()
	{
		return view('Hr.editAdvanceTypeForm');
	}

	public function createShiftTypeForm()
	{
		return view('Hr.createShiftTypeForm');
	}

	public function viewShiftTypeList()
	{

		$page = LengthAwarePaginator::resolveCurrentPage();
		$total = DB::table('shift_type')->where('status', '=', '1')->where('company_id', '=', $_GET['m'])->count('id'); //Count the total record
		$perPage = 10;

		//Set the limit and offset for a given page.
		$results = DB::table('shift_type')->forPage($page, $perPage)->where('company_id', '=', $_GET['m'])->get(['id', 'shift_type_name', 'username', 'status']);
		$ShiftTypes = new LengthAwarePaginator($results, $total, $perPage, $page, [
			'path' => LengthAwarePaginator::resolveCurrentPath()
		]);
		return view('Hr.viewShiftTypeList', ['ShiftTypes' => $ShiftTypes]);
	}

	public function editShiftTypeForm()
	{
		return view('Hr.editShiftTypeForm');
	}


	public function createEmployeeRequisitionForm()
	{

		$departments = Department::where('status', '=', '1')->where('company_id', '=', $_GET['m'])->orderBy('id')->get();
		$JobTypes = JobType::where('status', '=', '1')->where('company_id', '=', $_GET['m'])->orderBy('id')->get();
		$Designations = Designation::where('status', '=', '1')->where('company_id', '=', $_GET['m'])->orderBy('id')->get();
		$Qualifications = Qualification::where('status', '=', '1')->where('company_id', '=', $_GET['m'])->orderBy('id')->get();
		return view('Hr.createEmployeeRequisitionForm', compact('departments', 'JobTypes', 'Designations', 'Qualifications', 'ShiftTypes'));
	}

	public function viewEmployeeRequisitionList()
	{
		$m = Input::get('m');

		CommonHelper::companyDatabaseConnection($m);
		$EmployeeRequisition = EmployeeRequisition::all()->toArray();
		CommonHelper::reconnectMasterDatabase();
		return view('Hr.viewEmployeeRequisitionList', ['EmployeeRequisition' => $EmployeeRequisition]);


	}

	public function editEmployeeRequisitionForm()
	{

		CommonHelper::companyDatabaseConnection(Input::get('m'));
		$EmployeeRequisitiontDetail = EmployeeRequisition::where([['id', '=', Input::get('id')]])->first();
		CommonHelper::reconnectMasterDatabase();
		$departments = Department::where([['status', '=', '1'], ['company_id', '=', Input::get('m')]])->orderBy('id')->get();
		$JobTypes = JobType::where([['status', '=', '1'], ['company_id', '=', Input::get('m')]])->orderBy('id')->get();
		$Designations = Designation::where([['status', '=', '1'], ['company_id', '=', Input::get('m')]])->orderBy('id')->get();
		$Qualifications = Qualification::where([['status', '=', '1'], ['company_id', '=', Input::get('m')]])->orderBy('id')->get();
		$ShiftTypes = ShiftType::where([['status', '=', '1'], ['company_id', '=', Input::get('m')]])->orderBy('id')->get();

		return view('Hr.editEmployeeRequisitionForm', compact('EmployeeRequisitiontDetail', 'departments', 'JobTypes', 'Designations', 'Qualifications', 'ShiftTypes'));
	}

	public function createEmployeeForm()
	{

		$subdepartments = new SubDepartment;
		CommonHelper::companyDatabaseConnection(Input::get('m'));
		$leaves_policy = LeavesPolicy::where([['status', '=', '1']])->get();
		CommonHelper::reconnectMasterDatabase();
		$jobtype = JobType::where([['company_id', '=', Input::get('m')], ['status', '=', '1']])->orderBy('id')->get();
		$DegreeType = DegreeType::where([['company_id', '=', Input::get('m')], ['status', '=', '1']])->orderBy('id')->get();
		$departments = Department::where([['company_id', '=', Input::get('m')], ['status', '=', '1']])->orderBy('id')->get();
		$marital_status = MaritalStatus::where([['company_id', '=', Input::get('m')], ['status', '=', '1']])->orderBy('id')->get();
		$designation = Designation::where([['company_id', '=', Input::get('m')], ['status', '=', '1']])->orderBy('id')->get();
		$qualification = Qualification::where([['company_id', '=', Input::get('m')], ['status', '=', '1']])->orderBy('id')->get();
		$eobi = Eobi::where([['company_id', '=', Input::get('m')], ['status', '=', '1']])->orderBy('id')->get();
		$tax = Tax::select('id', 'tax_name')->where([['company_id', '=', Input::get('m')], ['status', '=', '1']])->orderBy('id')->get();

		return view('Hr.createEmployeeForm', compact('DegreeType', 'tax', 'eobi', 'designation', 'qualification', 'leaves_policy', 'departments', 'subdepartments', 'jobtype', 'marital_status'));
	}


	public function editEmployeeDetailForm($RecordId, $CompanyId)
	{
		$login_credentials = '';
		$subdepartments = new SubDepartment;
		$marital_status = MaritalStatus::where([['company_id', '=', $CompanyId], ['status', '=', '1'],])->orderBy('id')->get();;
		$departments = Department::where([['company_id', '=', $CompanyId], ['status', '=', '1'],])->orderBy('id')->get();
		$jobtype = JobType::where([['company_id', '=', $CompanyId], ['status', '=', '1'],])->orderBy('id')->get();
		$DegreeType = DegreeType::where([['company_id', '=', Input::get('m')], ['status', '=', '1']])->orderBy('id')->get();
		$designation = Designation::where([['company_id', '=', $CompanyId], ['status', '=', '1'],])->orderBy('id')->get();
		$eobi = Eobi::where([['company_id', '=', $CompanyId]])->orderBy('id')->get();
		$tax = Tax::select('id', 'tax_name')->where([['company_id', '=', $CompanyId], ['status', '=', '1']])->orderBy('id')->get();

		CommonHelper::companyDatabaseConnection($CompanyId);
		$leaves_policy = LeavesPolicy::where([['status', '=', '1']])->get();
		$employee_detail = DB::selectOne('select * from `employee` where `id` = ' . $RecordId . '');
		$salary_detail = EmployeeSalaryDetail::where([['emp_id', '=', $RecordId]])->first();
		$employeeWorkExperience = EmployeeWorkExperience::where([['emp_id', '=', $RecordId]])->get();
		$EmployeeQualification = EmployeeQualification::where([['emp_id', '=', $RecordId]])->get();
		$EmployeeReference = EmployeeReference::where([['emp_id', '=', $RecordId]])->get();

		CommonHelper::reconnectMasterDatabase();
		if ($employee_detail->can_login == 'yes'):

			$login_credentials = DB::Table('users')->select('acc_type')->where([['company_id', '=', $CompanyId], ['emp_id', '=', $employee_detail->id]])->first();
		endif;

		$data['DegreeType'] = $DegreeType;
		$data['login_credentials'] = $login_credentials;
		$data['designation'] = $designation;
		$data['tax'] = $tax;
		$data['eobi'] = $eobi;
		$data['leaves_policy'] = $leaves_policy;
		$data['employee_detail'] = $employee_detail;
		$data['departments'] = $departments;
		$data['subdepartments'] = $subdepartments;
		$data['jobtype'] = $jobtype;
		$data['marital_status'] = $marital_status;
		$data['employeeWorkExperience'] = $employeeWorkExperience;
		$data['EmployeeQualification'] = $EmployeeQualification;
		$data['EmployeeReference'] = $EmployeeReference;
		$data['salary_detail'] = $salary_detail;


		return view('Hr.editEmployeeDetailForm', $data);


	}

	public function viewEmployeeDetail($id,$comany_id)
    {
        $subdepartments = new SubDepartment;
        $currentuser = DB::selectOne('select acc_type,username,password from `users` where `id` = '.Auth::id().'');
        $jobtype = JobType::where([['company_id', '=', $comany_id], ['status', '=', '1'], ])->orderBy('id')->get();;
        $departments = Department::where([['company_id', '=', $comany_id], ['status', '=', '1'], ])->orderBy('id')->get();
        $marital_status = MaritalStatus::where([['company_id', '=',$comany_id], ['status', '=', '1'], ])->orderBy('id')->get();

        CommonHelper::companyDatabaseConnection($comany_id);
        $employee_detail = DB::selectOne('select * from `employee` where `id` = '.$id.'');
        $leavesPolicy = LeavesPolicy::where([['id','=',$employee_detail->leaves_policy_id]])->first();
        $leavesData =   LeavesData::where([['leaves_policy_id','=',$employee_detail->leaves_policy_id]])->get();
        $salary_detail = EmployeeSalaryDetail::where([['emp_id', '=', $id]])->first();
        $employeeWorkExperience = EmployeeWorkExperience::where([['emp_id', '=', $id]])->get();
        $EmployeeQualification = EmployeeQualification::where([['emp_id', '=', $id]])->get();
        $EmployeeReference = EmployeeReference::where([['emp_id', '=', $id]])->get();

        CommonHelper::reconnectMasterDatabase();
        $tax = Tax::where([['id','=',$employee_detail->tax_id]])->first();
        $eobi = Eobi::where([['id','=',$employee_detail->eobi_id]])->first();
        $department_details = DB::selectOne('select sub_department.sub_department_name,department.department_name from 
		`sub_department` inner join department on sub_department.department_id=department.id where sub_department.id = '.$employee_detail->emp_sub_department_id.'');

        $data['department_details'] = $department_details;
        $data['currentuser'] = $currentuser;
        $data['tax'] = $tax;
        $data['eobi'] = $eobi;
        $data['leavesPolicy'] = $leavesPolicy;
        $data['leavesData'] = $leavesData;
        $data['jobtype'] = $jobtype;
        $data['departments'] = $departments;
        $data['subdepartments'] = $subdepartments;
        $data['marital_status'] = $marital_status;
        $data['employee_detail'] = $employee_detail;
        $data['employeeWorkExperience'] = $employeeWorkExperience;
        $data['EmployeeQualification'] = $EmployeeQualification;
        $data['EmployeeReference'] = $EmployeeReference;
        $data['salary_detail'] = $salary_detail;
        return view('Hr.viewEmployeeDetail',$data);
    }

	public function viewEmployeeList()
	{

		CommonHelper::companyDatabaseConnection($_GET['m']);
		$employees = Employee::select('id','emp_code','emp_name', 'emp_email', 'emp_cnic','cnic_expiry_date', 'can_login', 'status')->where([['status','=',1]])->orderBy('id','desc')->get();
		CommonHelper::reconnectMasterDatabase();


		return view('Hr.viewEmployeeList', compact('employees'));
	}


	public function viewEmployeeExitClearanceList()
	{

		$exploye_exit=new EmployeeExitClearance();
		$exploye_exit=$exploye_exit->SetConnection('mysql2');
		$exploye_exit=$exploye_exit->where('status',1)->get(['emp_id','issue_date','dos','leaving_type']);
		return view('Hr.viewEmployeeExitClearanceList', compact('exploye_exit'));
	}


	public function createEmployeeFamilyStatus()
	{

		$employee = new Employee();
		$employee = $employee->SetConnection('mysql2');
		$employee = $employee->where('status', 1)->get(['emp_name', 'id']);
		return view('Hr.createEmployeeFamilyStatus', compact('employee'));
	}



	public function createEmployeeExitInterviewForm()
	{

		$employee = new Employee();
		$employee = $employee->SetConnection('mysql2');
		$employee = $employee->where('status', 1)->get(['emp_name', 'id']);
		return view('Hr.createEmployeeExitInterviewForm', compact('employee'));
	}


	public function createEmployeeProbationaryPeriod()
	{

		$employee = new Employee();
		$employee = $employee->SetConnection('mysql2');
		$employee = $employee->where('status', 1)->get(['emp_name', 'id']);
		return view('Hr.createEmployeeProbationaryPeriod', compact('employee'));
	}


	

	public function createEmployeeHistoryVerification()
	{

		$employee = new Employee();
		$employee = $employee->SetConnection('mysql2');
		$employee = $employee->where('status', 1)->get(['emp_name', 'id']);
		return view('Hr.createEmployeeHistoryVerification', compact('employee'));
	}


	public function createEmployeeExitClearanceForm()
	{

		$employee = new Employee();
		$employee = $employee->SetConnection('mysql2');
		$employee = $employee->where('status', 1)->get(['emp_name', 'id']);
		return view('Hr.createEmployeeExitClearanceForm', compact('employee'));
	}

	public function createManageAttendanceForm()
	{
		$departments = new Department;
		$subdepartments = new SubDepartment;
		$departments = $departments::where([['company_id', '=', $_GET['m']], ['status', '=', '1'],])->orderBy('id')->get();

		// $departments = new Department;
		//$departments = $departments::where('company_id','=',$_GET['m'])->orderBy('id')->get();
		CommonHelper::reconnectMasterDatabase();
		return view('Hr.createManageAttendanceForm', compact('departments', 'subdepartments'));

	}

	public function viewEmployeeAttendanceList()
	{
		$departments = Department::where([['company_id', '=', Input::get('m')], ['status', '=', '1'],])->orderBy('id')->get();
		return view('Hr.viewEmployeeAttendanceList', compact('departments'));
	}

	public function ImportEmployeeAttendanceForm()
    {

     return view('Hr.ImportEmployeeAttendanceForm');
    }

    public function ViewAttendanceProgress()
    {

        $departments = Department::where([['company_id', '=', Input::get('m')], ['status', '=', '1'],])->orderBy('id')->get();
        return view('Hr.ViewAttendanceProgress', compact('departments'));

    }

	public function createPayslipForm()
	{

		$subdepartments = new SubDepartment;
		$departments = Department::where('company_id', '=', $_GET['m'])->orderBy('id')->get();
		return view('Hr.createPayslipForm', compact('departments', 'subdepartments'));


	}

	public function viewPayslipList()
	{
		CommonHelper::reconnectMasterDatabase();
		$departments = Department::where('company_id', '=', $_GET['m'])->orderBy('id')->get();

		return view('Hr.viewPayslipList', compact('departments'));

	}

	public function viewPayrollReport()
    {
        $departments = Department::where('company_id', '=', $_GET['m'])->orderBy('id')->get();
        return view('Hr.viewPayrollReport', compact('departments'));

    }

	public function createMaritalStatusForm()
	{
		return view('Hr.createMaritalStatusForm');

	}

	public function editMaritalStatusForm()
	{
		return view('Hr.editMaritalStatusForm');
	}

	public function viewMaritalStatuslist()
	{
		$page = LengthAwarePaginator::resolveCurrentPage();
		$total = DB::table('marital_status')->where('company_id', '=', $_GET['m'])->count('id'); //Count the total record
		$perPage = 10;

		//Set the limit and offset for a given page.
		$results = DB::table('marital_status')->forPage($page, $perPage)->where('company_id', '=', $_GET['m'])->get(['id', 'marital_status_name', 'username', 'status']);
		$maritalStatus = new LengthAwarePaginator($results, $total, $perPage, $page, [
			'path' => LengthAwarePaginator::resolveCurrentPath()
		]);

		return view('Hr.viewMaritalStatuslist', ['maritalStatus' => $maritalStatus]);

	}


	public function createAllowanceForm()
	{

		$subdepartments = new SubDepartment;
		$departments = Department::where('company_id', '=', Input::get('m'))->orderBy('id')->get();
		return view('Hr.createAllowanceForm', compact('departments', 'subdepartments'));
	}

	public function viewAllowanceList()
	{
		CommonHelper::companyDatabaseConnection(Input::get('m'));
		$allowance = Allowance::select('*')->orderBy('id')->get();
		CommonHelper::reconnectMasterDatabase();
		return view('Hr.viewAllowanceList', compact('allowance'));
	}

	public function editAllowanceDetailForm()
	{

		$subdepartments = new SubDepartment;
		$departments = Department::where('company_id', '=', Input::get('m'))->orderBy('id')->get();
		CommonHelper::companyDatabaseConnection(Input::get('m'));
		$allowance = Allowance::where([['id', '=', Input::get('id')]])->orderBy('id')->first();
		$employees = Employee::where('status', '=', 1)
			->where('emp_sub_department_id', '=', $allowance->emp_sub_department_id)->get();
		CommonHelper::reconnectMasterDatabase();
		return view('Hr.editAllowanceDetailForm', compact('employees', 'allowance', 'departments', 'subdepartments'));
	}


	public function createDeductionForm()
	{

		$subdepartments = new SubDepartment;
		$departments = Department::where('company_id', '=', Input::get('m'))->orderBy('id')->get();
		return view('Hr.createDeductionForm', compact('departments', 'subdepartments'));
	}

	public function viewDeductionList()
	{
		CommonHelper::companyDatabaseConnection(Input::get('m'));
		$deduction = Deduction::select('*')->orderBy('id')->get();
		CommonHelper::reconnectMasterDatabase();
		return view('Hr.viewDeductionList', compact('deduction'));

	}

	public function editDeductionDetailForm()
	{

		$subdepartments = new SubDepartment;
		$departments = Department::where('company_id', '=', Input::get('m'))->orderBy('id')->get();
		CommonHelper::companyDatabaseConnection(Input::get('m'));
		$deduction = Deduction::where([['id', '=', Input::get('id')]])->orderBy('id')->first();
		$employees = Employee::where('status', '=', 1)
			->where('emp_sub_department_id', '=', $deduction->emp_sub_department_id)->get();
		CommonHelper::reconnectMasterDatabase();
		return view('Hr.editDeductionDetailForm', compact('employees', 'deduction', 'departments', 'subdepartments'));
	}


	public function createAdvanceSalaryForm()
	{
		return view('Hr.createAdvanceSalaryForm');
	}

	public function viewAdvanceSalaryList()
	{
		CommonHelper::companyDatabaseConnection(Input::get('m'));
		if (Auth::user()->acc_type == 'user'):
			$advance_salary = AdvanceSalary::select('*')->where([['status', '=', 1], ['emp_id', '=', 1]])->orderBy('id')->get();
		else:
			$advance_salary = AdvanceSalary::select('*')->where([['status', '=', 1]])->orderBy('id')->get();
		endif;
        CommonHelper::reconnectMasterDatabase();

		return view('Hr.viewAdvanceSalaryList', compact('advance_salary'));
	}

	public function editAdvanceSalaryDetailForm()
	{
		CommonHelper::companyDatabaseConnection(Input::get('m'));
		$advance_salary = AdvanceSalary::select('*')->where([['id', '=', Input::get('id')]])->orderBy('id')->first();
        CommonHelper::reconnectMasterDatabase();
		return view('Hr.editAdvanceSalaryDetailForm', compact('advance_salary'));
	}


	public function createLeavesPolicyForm()
	{
		$leaves_types = LeaveType::select('id', 'leave_type_name')->where([['company_id', '=', Input::get('m')],['status', '=', 1]])->orderBy('id')->get();
		return view('Hr.createLeavesPolicyForm', compact('leaves_types'));
	}

	public function viewLeavesPolicyList()
	{
		CommonHelper::companyDatabaseConnection(Input::get('m'));
		$leavesPolicy = LeavesPolicy::all()->sortByDesc("id");
		CommonHelper::reconnectMasterDatabase();
		return view('Hr.viewLeavesPolicyList', compact('leavesPolicy'));
	}

	public function editLeavesPolicyDetailForm()
	{
		$leavesType = LeaveType::where([['company_id', '=', Input::get('m')],['status', '=', 1]])->get();
		CommonHelper::companyDatabaseConnection(Input::get('m'));
		$leavesPolicy = LeavesPolicy::where([['id', '=', Input::get('id')]])->first();
		$leavesData = LeavesData::where([['leaves_policy_id', '=', Input::get('id')],['status', '=', 1]])->get();

		return view('Hr.editLeavesPolicyDetailForm', compact('leavesPolicy', 'leavesData', 'leavesType'));
	}


	public function createVehicleTypeForm()
	{
		return view('Hr.createVehicleTypeForm');
	}

	public function viewVehicleTypeList()
	{
		$vehicleType = VehicleType::where([['company_id', '=', Input::get('m')]])->get();
		return view('Hr.viewVehicleTypeList', compact('vehicleType'));

	}

	public function editVehicleTypeDetailForm()
	{
		$vehicleType = VehicleType::where([['id', '=', Input::get('id')]])->get(['vehicle_type_name', 'vehicle_type_cc'])->first();
		return view('Hr.editVehicleTypeDetailForm', compact('vehicleType'));
	}


	public function createCarPolicyForm()
	{
		$vehicleType = VehicleType::where([['company_id', '=', Input::get('m')]])->get();
		$designation = Designation::where([['company_id', '=', Input::get('m')]])->get();
		return view('Hr.createCarPolicyForm', compact('vehicleType', 'designation'));
	}


	public function viewCarPolicyList()
	{
		CommonHelper::companyDatabaseConnection(Input::get('m'));
		$carPolicy = CarPolicy::all()->toArray();
		CommonHelper::reconnectMasterDatabase();
		return view('Hr.viewCarPolicyList', compact('carPolicy'));
	}

	public function viewCarPolicyCriteria()
	{
		CommonHelper::companyDatabaseConnection(Input::get('m'));
		$carPolicy = CarPolicy::all()->toArray();
		CommonHelper::reconnectMasterDatabase();
		$departments = Department::where('company_id', '=', $_GET['m'])->where('status', '=', '1')->orderBy('id')->get();
		return view('Hr.viewCarPolicyCriteria', compact('departments', 'carPolicy'));
	}

	public function editCarPolicyDetailForm()
	{
		$vehicleType = VehicleType::where([['company_id', '=', Input::get('m')]])->get();
		$designation = Designation::where([['company_id', '=', Input::get('m')]])->get();
		CommonHelper::companyDatabaseConnection(Input::get('m'));
		$carPolicy = CarPolicy::where([['id', '=', Input::get('id')]])->first();
		return view('Hr.editCarPolicyDetailForm', compact('carPolicy', 'vehicleType', 'designation'));
	}


	public function createLoanRequestForm()
	{
		$subdepartments = new SubDepartment;
		$departments = Department::where('company_id', '=', $_GET['m'])->orderBy('id')->get();
		CommonHelper::reconnectMasterDatabase();
		return view('Hr.createLoanRequestForm', compact('departments', 'subdepartments'));
	}

	public function viewLoanRequestList()
	{
		CommonHelper::companyDatabaseConnection(Input::get('m'));
		$loanRequest = LoanRequest::all();
		CommonHelper::reconnectMasterDatabase();
		return view('Hr.viewLoanRequestList', compact('loanRequest'));
	}

	public function editLoanRequestDetailForm()

	{
		CommonHelper::companyDatabaseConnection(Input::get('m'));
		$loanRequest = LoanRequest::where([['id', '=', Input::get('id')]])->first();
		$employee = Employee::select('emp_name', 'emp_sub_department_id')->where([['id', '=', $loanRequest->emp_id]])->first();
		$employee_list = Employee::select('id', 'emp_name')->where([['status', '=', '1']])->get();
		CommonHelper::reconnectMasterDatabase();
		$subdepartments = new SubDepartment;
		$departments = Department::where('company_id', '=', $_GET['m'])->orderBy('id')->get();

		return view('Hr.editLoanRequestDetailForm', compact('loanRequest', 'employee_list', 'carPolicy', 'vehicleType', 'designation', 'departments', 'employee'));
	}


	public function createEOBIForm()
	{
		return view('Hr.createEOBIForm');

	}

	public function viewEOBIList()
	{
		$eobi = Eobi::where([['company_id', '=', Input::get('m')]])->get();
		return view('Hr.viewEOBIList', compact('eobi'));
	}

	public function editEOBIDetailForm()
	{
		$eobi = Eobi::select('id', 'EOBI_name', 'EOBI_amount', 'month_year')->where([['id', '=', Input::get('id')], ['company_id', '=', Input::get('m')]])->first();
		return view('Hr.editEOBIDetailForm', compact('eobi'));
	}


	public function createDegreeTypeForm()
	{
		return view('Hr.createDegreeTypeForm');

	}

	public function viewDegreeTypeList()
	{
		$degree_type = DegreeType::all();
		return view('Hr.viewDegreeTypeList', compact('degree_type'));
	}

	public function editDegreeTypeDetailForm()
	{
		$degree_type = DegreeType::select('id', 'degree_type_name')->where([['id', '=', Input::get('id')], ['company_id', '=', Input::get('m')]])->first();
		return view('Hr.editDegreeTypeDetailForm', compact('degree_type'));
	}


	public function createTaxesForm()
	{
		return view('Hr.createTaxesForm');
	}

	public function viewTaxesList()
	{
		$tax = Tax::where([['company_id', '=', Input::get('m')]])->get();
		return view('Hr.viewTaxesList', compact('tax'));

	}

	public function editTaxesDetailForm()
	{
		$tax = Tax::where([['id', '=', Input::get('id')], ['company_id', '=', Input::get('m')]])->first();
		return view('Hr.editTaxesDetailForm', compact('tax'));
	}

	public function viewTaxCriteria()
	{
		$departments = Department::where('company_id', '=', $_GET['m'])->where('status', '=', '1')->orderBy('id')->get();
		$taxes = Tax::where('company_id', '=', $_GET['m'])->where('status', '=', '1')->orderBy('id')->get();
		return view('Hr.viewTaxCriteria', compact('departments', 'taxes'));

	}

	public function createBonusForm()
	{
		return view('Hr.createBonusForm');
	}

	public function viewBonusList()
	{
		CommonHelper::companyDatabaseConnection(Input::get('m'));
		$bonus = Bonus::all();
		CommonHelper::reconnectMasterDatabase();
		return view('Hr.viewBonusList', compact('bonus'));
	}

	public function editBonusDetailForm()
	{
		CommonHelper::companyDatabaseConnection(Input::get('m'));
		$bonus = Bonus::where([['id', '=', Input::get('id')]])->first();
		CommonHelper::reconnectMasterDatabase();
		return view('Hr.editBonusDetailForm', compact('bonus'));
	}

	public function IssueBonusDetailForm()
	{
		$subdepartments = new SubDepartment;
		$departments = Department::where('company_id', '=', Input::get('m'))->orderBy('id')->get();
		CommonHelper::companyDatabaseConnection(Input::get('m'));
		$bonus_list = Bonus::where([['status', '=', '1']])->orderBy('id')->get();
		CommonHelper::reconnectMasterDatabase();
		return view('Hr.IssueBonusDetailForm', compact('bonus_list', 'departments', 'subdepartments'));
	}


	public function createLeaveApplicationForm()
	{

    	CommonHelper::companyDatabaseConnection(Input::get('m'));
        $attendance_machine_id = Employee::select('attendance_machine_id')->where([['id','=',Auth::user()->emp_id]])->value('attendance_machine_id');

        $leaves_policy = DB::table('employee')
			->join('leaves_policy', 'leaves_policy.id', '=', 'employee.leaves_policy_id')
			->join('leaves_data', 'leaves_data.leaves_policy_id', '=', 'leaves_policy.id')
			->select('leaves_policy.*', 'leaves_data.*')
			->where([['employee.id', '=', Auth::user()->emp_id]])
			->get();

        $leaves_policy_validatity = DB::table('employee')
            ->join('leaves_policy', 'leaves_policy.id', '=', 'employee.leaves_policy_id')
            ->join('leaves_data', 'leaves_data.leaves_policy_id', '=', 'leaves_policy.id')
            ->select('leaves_policy.id', 'leaves_data.id')
            ->where([['employee.id', '=', Auth::user()->emp_id],['leaves_policy.policy_date_till','>',date("Y-m-d")]])
            ->count();


		$total_leaves = DB::table("leaves_data")
			->select(DB::raw("SUM(no_of_leaves) as total_leaves"))
			->where([['leaves_policy_id', '=', $leaves_policy[0]->leaves_policy_id]])
			->first();
		$taken_leaves = DB::table("leave_application_data")
			->select(DB::raw("SUM(no_of_days) as taken_leaves"))
			->join('leave_application', 'leave_application.id', '=', 'leave_application_data.leave_application_id')
			->where([['leave_application.emp_id', '=', Auth::user()->emp_id],['leave_application.status', '=', '1'],
                ['leave_application.approval_status', '=', '2']])
			->first();

		$emp_data = Employee::select('emp_name','emp_code','emp_department_id', 'designation_id')->where([['id', '=', Auth::user()->emp_id]])->orderBy('id')->first();

		CommonHelper::reconnectMasterDatabase();
		return view('Hr.createLeaveApplicationForm', compact('attendance_machine_id','leaves_policy_validatity','leaves_policy', 'emp_data', 'total_leaves', 'taken_leaves'));
	}


	public function viewLeaveApplicationRequestList()
	{
		CommonHelper::companyDatabaseConnection(Input::get('m'));
		$leave_application_request_list = DB::table('leave_application')
			->join('leave_application_data', 'leave_application_data.leave_application_id', '=', 'leave_application.id')
			->join('employee', 'employee.id', '=', 'leave_application.emp_id')
			->select('leave_application.*', 'employee.emp_name')
			->get();

		CommonHelper::reconnectMasterDatabase();
		return view('Hr.viewLeaveApplicationRequestList', compact('leave_application_request_list'));


	}

	public function viewLeaveApplicationList()
	{

		CommonHelper::companyDatabaseConnection(Input::get('m'));

		$leave_application_list = DB::table('leave_application')
			->join('leave_application_data', 'leave_application_data.leave_application_id', '=', 'leave_application.id')
			->select('leave_application.*')
			->where([['leave_application.emp_id', '=', Auth::user()->emp_id]])
			->get();
	
		CommonHelper::reconnectMasterDatabase();

		return view('Hr.viewLeaveApplicationList', compact('leave_application_list'));
	}

	public function editLeaveApplicationDetailForm()
	{

		$id_and_type = explode('|', Input::get('id'));
		CommonHelper::companyDatabaseConnection(Input::get('m'));
		$leaves_policy = DB::table('employee')
			->join('leaves_policy', 'leaves_policy.id', '=', 'employee.leaves_policy_id')
			->join('leaves_data', 'leaves_data.leaves_policy_id', '=', 'leaves_policy.id')
			->select('leaves_policy.*', 'leaves_data.*')
			->where([['employee.id', '=', Auth::user()->emp_id]])
			->get();

		$total_leaves = DB::table("leaves_data")
			->select(DB::raw("SUM(no_of_leaves) as total_leaves"))
			->where([['leaves_policy_id', '=', $leaves_policy[0]->leaves_policy_id]])
			->first();
		$taken_leaves = DB::table("leave_application_data")
			->select(DB::raw("SUM(no_of_days) as taken_leaves"))
			->join('leave_application', 'leave_application.id', '=', 'leave_application_data.leave_application_id')
			->where([['leave_application.emp_id', '=', Auth::user()->emp_id]])
			->first();

		$emp_data = Employee::select('emp_name', 'designation_id')->where([['id', '=', Auth::user()->emp_id]])->orderBy('id')->first();

		if ($id_and_type[1] == 1):

			$leave_application_data = DB::table('leave_application')
				->join('leave_application_data', 'leave_application.id', '=', 'leave_application_data.leave_application_id')
				->select('leave_application.approval_status', 'leave_application.reason', 'leave_application_data.no_of_days', 'leave_application_data.date', 'leave_application_data.from_date', 'leave_application_data.to_date')
				->where([['leave_application_data.leave_application_id', '=', $id_and_type[0]], ['leave_application_data.leave_day_type', '=', $id_and_type[1]]])
				->first();

		elseif ($id_and_type[1] == 2):

			$leave_application_data = DB::table('leave_application')
				->join('leave_application_data', 'leave_app');
		endif;
	}





	public function createHolidaysForm()
    {
        return view('Hr.createHolidaysForm');
    }


    public function viewHolidaysList()
    {
        CommonHelper::companyDatabaseConnection(Input::get('m'));
        $holidays = Holidays::orderBy('holiday_date')->get();
        CommonHelper::reconnectMasterDatabase();
        return view('Hr.viewHolidaysList',compact('holidays'));
    }


    public function editHolidaysDetailForm()
    {
        CommonHelper::companyDatabaseConnection(Input::get('m'));
        $holidaysDetail = Holidays::find(Input::get('id'))->toArray();
        CommonHelper::reconnectMasterDatabase();
        return view('Hr.editHolidaysDetailForm',compact('holidaysDetail'));

    }
}

