<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use Illuminate\Http\Request;
use Auth;
use DB;
use Config;
use Input;
use Session;
use App\Helpers\FinanceHelper;
use App\Helpers\CommonHelper;
use App\Helpers\HrHelper;
use App\Models\Department;
use App\Models\Employee;
use App\Models\Attendence;
use App\Models\Payslip;
use App\Models\Allowance;
use App\Models\Deduction;
use App\Models\JobType;
use App\Models\SubDepartment;
use App\Models\MaritalStatus;
use App\Models\LeavesPolicy;
use App\Models\LeavesData;
use App\Models\CarPolicy;



class HrEditDetailByAjaxController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */


    public function EditEmployeeCarPolicyDetail()
    {

          CommonHelper::companyDatabaseConnection(Input::get('m'));
          DB::table('employee')->where('id', Input::get('id'))->update(['car_policy_id'=>Input::get('policy_id')]);

            $policy = Employee::select('id')->where([['id','=',Input::get('id')],['car_policy_id','>','0']])->count();

            if($policy == '0'):
                $label ='';
                $cancel_assign_btn  = ' <li role="presentation text-center">
                       <a style="cursor:pointer;" class="edit-modal" onclick="assignCarPolicy('.Input::get('id').','.Input::get('assign_id').')">Assign</a>
                       </li>';

            else:
                $label = 'Policy Status: <span class="label label-success">Assigned</span>';
                $cancel_assign_btn  = ' <li role="presentation text-center">
                       <a style="cursor:pointer;" class="edit-modal" onclick="cancelCarPolicy('.Input::get('id').','.Input::get('policy_id').')">Cancel</a>
                       </li>';

            endif;



            $object = ['label'=>$label,'cancel_assign_btn'=>$cancel_assign_btn];
          echo json_encode(['data'=>$object]);
    }


    public function EditEmployeeTaxDetail()
    {


        CommonHelper::companyDatabaseConnection(Input::get('m'));
        DB::table('employee')->where('id', Input::get('id'))->update(['tax_id'=>Input::get('tax_id')]);

        $policy = Employee::select('id')->where([['id','=',Input::get('id')],['tax_id','>','0']])->count();

        if($policy == '0'):
            $label ='';
            $cancel_assign_btn  = ' <li role="presentation text-center">
                       <a style="cursor:pointer;" class="edit-modal" onclick="assignTax('.Input::get('id').','.Input::get('assign_id').')">Assign</a>
                       </li>';

        else:
            $label = 'Policy Status: <span class="label label-success">Assigned</span>';
            $cancel_assign_btn  = ' <li role="presentation text-center">
                       <a style="cursor:pointer;" class="edit-modal" onclick="cancelTax('.Input::get('id').','.Input::get('tax_id').')">Cancel</a>
                       </li>';

        endif;



        $object = ['label'=>$label,'cancel_assign_btn'=>$cancel_assign_btn];
        echo json_encode(['data'=>$object]);

    }

    public function editLeaveApplicationDetail()
    {
        echo Input::get('leave_application_id');
        CommonHelper::companyDatabaseConnection(Input::get('company_id'));

        $data['emp_id']          = Input::get('emp_id');
        $data['leave_day_type']  = Input::get('leave_day_type');
        $data['reason']          = Input::get('reason');
        $data['approval_status'] = 1;
        $data['status']          = 1;
        $data['date']            = date("Y-m-d");
        $data['time']            = date("H:i:s");

        DB::table('leave_application')->where([['id','=',Input::get('leave_application_id')],['emp_id','=',Input::get('emp_id')]])->update($data);


        if(Input::get('leave_day_type') == 1):

            $data1['leave_day_type']       = Input::get('leave_day_type');
            $data1['no_of_days']           = Input::get('no_of_days');
            $data1['from_date']            = Input::get('from_date');
            $data1['to_date']              = Input::get('to_date');
            $data1['status']               = 1;
            $data1['date']                 = date("Y-m-d");
            $data1['time']                 = date("H:i:s");

            DB::table('leave_application_data')->where([['leave_application_id','=',Input::get('leave_application_id')]])->update($data1);


        elseif(Input::get('leave_day_type') == 2):

            $data2['leave_day_type']           = Input::get('leave_day_type');
            $data2['no_of_days']               = Input::get('no_of_days');
            $data2['first_second_half']        = Input::get('first_second_half');
            $data2['first_second_half_date']   = Input::get('first_second_half_date');
            $data2['status']                   = 1;
            $data2['date']                     = date("Y-m-d");
            $data2['time']                     = date("H:i:s");
            DB::table('leave_application_data')->where([['leave_application_id','=',Input::get('leave_application_id')]])->update($data2);


        else:

            $data3['leave_day_type']       = Input::get('leave_day_type');
            $data3['no_of_days']           = Input::get('no_of_days');
            $data3['short_leave_time_from']= Input::get('short_leave_time_from');
            $data3['short_leave_time_to']=   Input::get('short_leave_time_to');
            $data3['short_leave_date']=      Input::get('short_leave_date');
            $data3['status']                =1;
            $data3['date']                  =date("Y-m-d");
            $data3['time']                  =date("H:i:s");

            DB::table('leave_application_data')->where([['leave_application_id','=',Input::get('leave_application_id')]])->update($data3);


        endif;

        Session::flash('dataInsert','successfully saved.');

        CommonHelper::reconnectMasterDatabase();

    }
}
?>