<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use App\Models\Designation;
use Illuminate\Http\Request;
use Auth;
use DB;
use Config;
use Input;
use App\Helpers\FinanceHelper;
use App\Helpers\CommonHelper;
use App\Helpers\HrHelper;
use App\Models\Department;
use App\Models\Employee;
use App\Models\Attendance;
use App\Models\Payslip;
use App\Models\Allowance;
use App\Models\Deduction;
use App\Models\JobType;
use App\Models\SubDepartment;
use App\Models\MaritalStatus;
use App\Models\LeavesPolicy;
use App\Models\LeavesData;
use App\Models\CarPolicy;
use App\Models\LoanRequest;
use App\Models\Tax;
use App\Models\Eobi;
use App\Models\DegreeType;
use App\Models\User;
use App\Models\EmployeeRequisition;
use App\Models\Qualification;
use App\Models\ShiftType;
use App\Models\FamilyStatus;
use App\Models\EmployeeWorkExperience;
use App\Models\HistoryVarification;
use App\Models\EmployeeSalaryDetail;
use App\Models\EmployeeReference;
use App\Models\EmployeeQualification;
use App\Models\EmployeeHistoryVerification;
use App\Models\EmployeeExitClearance;
use App\Models\LeaveApplicationData;





class HrDataCallController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function viewDepartmentList(){
        Config::set(['database.connections.tenant.database' => Auth::user()->dbName]);
        Config::set(['database.connections.tenant.username' => 'root']);
        Config::set('database.default', 'tenant');
        DB::reconnect('tenant');
        $departments = new Department;
        $departments = $departments::where('status', '=', '1')->get();
        $counter = 1;
        foreach($departments as $row){
            ?>
            <tr>
                <td class="text-center"><?php echo $counter++;?></td>
                <td><?php echo $row['department_name'];?></td>
                <td></td>
            </tr>
            <?php
        }
    }
    public function viewEmployeeListManageAttendence(){

        CommonHelper::companyDatabaseConnection(Input::get('m'));
        $employees = Employee::where('emp_department_id','=', Input::get('department_id'))->get();
        //FinanceHelper::reconnectMasterDatabase();

        ?>
        <div class="row">
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <input type="hidden" name="emp_department_id[]" id="emp_department_id" value="<?php echo Input::get('department_id');?>" />
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <div class="table-responsive">
                    <table class="table table-bordered sf-table-list">
                        <thead>
                        <th class="text-center">S.No</th>
                        <th class="text-center">Emp.No</th>
                        <th class="text-center">Emp. Name</th>
                        <th class="text-center">Attendence Status</th>
                        <th class="text-center">Status</th>
                        <th class="text-center">Reason Of Absence/Leave</th>
                        </thead>
                        <tbody>
                        <?php
                        $counter = 1;

                        foreach($employees as $row){

                            $attendance = Attendence::where([['attendence_date', '=', Input::get('attendence_date')],['emp_id', '=', $row['id']]]);

                            if($attendance->count() > 0 ):
                                $attendacenData = $attendance->first();
                                $attendanceStatusMessage = '<span class="label label-success">Submitted</span>';
                                $attendanceRemarks = $attendacenData->remarks;
                                $attendanceType = $attendacenData->attendence_type;

                            else:
                                $attendanceStatusMessage = '<span class="label label-warning">Pending</span>';
                                $attendanceRemarks = '';
                                $attendanceType = '';

                            endif;
                            ?>
                            <tr>
                                <td class="text-center"><?php echo $counter++;?></td>
                                <td class="text-center"><?php echo $row['emp_code'];?></td>
                                <td><?php echo $row['emp_name'];?></td>
                                <input type="hidden" name="emp_id_[]" id="emp_id_<?php echo Input::get('department_id');?>" value="<?php echo $row['id'];?>" />
                                <td>
                                    <select required name="attendence_status_<?php echo $row['id'];?>" id="attendence_status_<?php echo Input::get('department_id');?>_<?php echo $row['id'];?>" class="form-control">

                                        <option value="">Select</option>
                                        <option <?php if($attendanceType == 1) echo "selected";?> value="1">Present</option>
                                        <option <?php if($attendanceType == 2) echo "selected";?> value="2">Absent</option>
                                        <option <?php if($attendanceType == 3) echo "selected";?> value="3">Leave</option>
                                    </select>
                                </td>
                                <td><?php echo $attendanceStatusMessage; ?> </td>
                                <td>
                                    <input type="text" name="attendence_remarks_<?php echo $row['id'];?>" id="attendence_remarks_<?php echo Input::get('sub_department_id_1');?>_<?php echo $row['id'];?>" class="form-control" value="<?=$attendanceRemarks; ?>" />
                                </td>
                            </tr>
                            <?php
                        }
                        ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <?php
    }

    public function viewAttendanceReport(){



        //$department_id = Input::get('department_id');
         $explodeMonthYear = explode("-",Input::get('month_year'));
         $employee_id = Input::get('employee_id');
         CommonHelper::companyDatabaseConnection(Input::get('m'));
        if($employee_id == 'All'):
            $attendance = Attendance::where([['month','=',$explodeMonthYear[1]],['year','=',$explodeMonthYear[0]]])->orderBy('attendance_date')->get();

        else:
            $attendance = Attendance::where([['emp_id','=',$employee_id],['month','=',$explodeMonthYear[1]],['year','=',$explodeMonthYear[0]]])->orderBy('attendance_date')->get();

        endif;
        CommonHelper::reconnectMasterDatabase();

        return view('Hr.AjaxPages.viewAttendanceReport',compact('attendance'));

    }


    public function viewAttendanceProgress()
    {

        $month_year   = explode("-",Input::get('month_year'));
        $employee_id = Input::get('employee_id');
        CommonHelper::companyDatabaseConnection(Input::get('m'));
        if($employee_id == 'All'):


         //   $attendance = Attendance::select('emp_id')->whereBetween('attendance_date', [$from_date,$to_date])->groupBy('emp_id')->get();

            $attendance = DB::table('attendance')
                ->join('employee', 'employee.attendance_machine_id', '=', 'attendance.emp_id')
                ->select('employee.emp_name', 'employee.attendance_machine_id','attendance.month','attendance.year')
                ->where([['year','=',$month_year[0]],['month','=',$month_year[1]]])->groupBy('emp_id');
        else:
           // $attendance = Attendance::select('emp_id')->where([['emp_id','=',$employee_id]])->whereBetween('attendance_date', [$from_date,$to_date]) ->groupBy('emp_id')->get();

            $attendance = DB::table('attendance')
                ->join('employee', 'employee.attendance_machine_id', '=', 'attendance.emp_id')
                ->select('employee.emp_name', 'employee.attendance_machine_id','attendance.month','attendance.year')
                ->where([['emp_id','=',$employee_id],['year','=',$month_year[0]],['month','=',$month_year[1]]])->groupBy('emp_id');
        endif;
        CommonHelper::reconnectMasterDatabase();

        return view('Hr.AjaxPages.viewAttendanceProgress',compact('attendance'));

    }
    function  viewEmployeeDataFamilyStatus($id='')
    {
        $id = Input::get('emp_val');
        $employe=new Employee();
        $employe=$employe->SetConnection('mysql2');
        $employe=$employe->where('status',1)->where('id',$id)->first(['designation_id','emp_department_id','emp_code']);
        $designation=new Designation();
        $designation=$designation->where('status',1)->where('id',$employe->designation_id)->select('designation_name')->first();
        $department=new Department();
        $department=$department->where('status',1)->where('id',$employe->emp_department_id)->first(['department_name']);
        echo $employe->emp_code.','.$designation['designation_name'].','.$department['department_name'];

        $family_status=new FamilyStatus();
        $family_status=$family_status->SetConnection('mysql2');
        $family_status=$family_status->where('status',1)->where('emp_id',$id);

        $limit=$family_status->count();
        echo ',';
        echo $family_status->value('marital_status_id');
        $count=1;
        if ($family_status->count()>0):

            if ($family_status->value('marital_status_id')==1):

                echo ',';

                $family_status=$family_status->limit($limit)->get(['name','gender','relation','dob']);

                foreach ($family_status as $row): ?>
                    <tr class="remove<?php echo $count; if ($count>1):echo ' ';echo  'all_remove';endif; ?>">

                        <td class="text-center"><span class="badge badge-pill badge-secondary"><?php echo $count++; ?></span></td>
                        <td class="text-center"><input value="<?php echo $row['name'] ?>" class="form-control amir" type="text" name="name[]" id="name1"></td>
                        <td class="text-center">
                            <select name="gender[]" class="form-control requiredField">
                                <option <?php if ($row['gender']==1): ?> selected<?php endif; ?> value="1">Male</option>
                                <option <?php if ($row['gender']==2): ?> selected<?php endif; ?> value="2">Female</option>
                            </select>
                        </td>
                        <td class="text-center">
                            <select name="relation[]" class="form-control requiredField">
                                <option <?php if ($row['relation']==1): ?> selected<?php endif; ?> value="1">Spouse</option>
                                <option <?php if ($row['relation']==2):?> selected<?php endif; ?> value="2">Chidren</option>
                            </select>
                        </td>
                        <td class="text-center"><input type="date" value="<?php echo $row['dob'] ?>" name="dob[]" class="form-control amir" id="dob1"></td>
                        <td class="text-center">
                            <?php if ($count >2): ?>
                                <button type="button" onclick="remove('<?php echo $count-1 ?>')"  class="btn btn-xs btn-danger">Remove</button>
                            <?php else:echo '----'; endif; ?>
                        </td>
                    </tr>
                <?php endforeach;
                echo ',';echo $count-1;
                ?>
                <?php
            else:	endif;
        else:	endif;
    }




    function  viewEmployeeDataExitClearance($id='')
    {
        $id = Input::get('emp_val');
        $employe=new Employee();
        $employe=$employe->SetConnection('mysql2');
        $employe=$employe->where('status',1)->where('id',$id)->first(['designation_id','emp_department_id','emp_code','emp_joining_date']);
        $designation=new Designation();
        $designation=$designation->where('status',1)->where('id',$employe->designation_id)->select('designation_name')->first();
        $department=new Department();
        $department=$department->where('status',1)->where('id',$employe->emp_department_id)->first(['department_name']);
        echo $employe->emp_code.'*'.$designation['designation_name'].'*'.$department['department_name'].'*'.$employe->emp_joining_date;
        echo '*';
        $employe_exit=new EmployeeExitClearance();
        $employe_exit=$employe_exit->SetConnection('mysql2');
        $exit_data=$employe_exit->where('status',1)->where('emp_id',$id);
        $count=$exit_data->count();
        $exit_employe_data=$exit_data->first();

        echo $count;echo '*';


        $employee = $employe->where('status', 1)->get(['emp_name', 'id']);
        return view('Hr.AjaxPages.viewEmployeeExitClearance', compact('employee','count','exit_employe_data'));



    }

    function  viewEmployeeDataForHistoryVerification($id='')
    {
        $id = Input::get('emp_val');
        $employe=new Employee();
        $employe=$employe->SetConnection('mysql2');
        $employe=$employe->where('status',1)->where('id',$id)->first(['designation_id','emp_department_id','emp_code']);
        print_r($employe);

        $designation=new Designation();
        $designation=$designation->where('status',1)->where('id',$employe['designation_id'])->select('designation_name')->first();
        $work_expe=new EmployeeWorkExperience();
        $work_expe=$work_expe->SetConnection('mysql2');
        $work_expe=$work_expe->where('status',1)->where('emp_id',$id)->select('started','ended')->first();
        echo $designation['designation_name'].','.$work_expe['started'].','.$work_expe['ended'];
        $history_varification=new EmployeeHistoryVerification();
        $history_varification=$history_varification->SetConnection('mysql2');
        $history_varification=$history_varification->where([['status','=','1'],['emp_id','=',$id]]);
        if ($history_varification->count()>0):
            echo ','.$history_varification->count();
            $history_varification=$history_varification->first();
            echo ','.$history_varification['quality_work'].','.$history_varification['quantity_work'].','.$history_varification['attendance'];
            echo ','.$history_varification['behavior'].','.$history_varification['leave_reson'].','.$history_varification['eligible'];
            echo ','.$history_varification['eligible_reason'].','.$history_varification['additional_comments'].','.$history_varification['inform_from'];
            echo ','.$history_varification['position_titke'];
        else:echo ','.$history_varification->count();		endif;
    }





    public function viewEmployeePaysilpForm(){
        $department_id = Input::get('department_id');
        $getPayslipMonth = Input::get('payslip_month');
        $explodeMonthYear = explode('-',$getPayslipMonth);
        $getEmployee = Input::get('employee');
        $startDate = Input::get('payslip_month').'-1';
        $endDate = date("Y-m-t", strtotime($startDate));;
        $departments = Department::where('status', '=', '1')->where('id','=',$department_id)->get();
        return view('Hr.AjaxPages.viewEmployeePayslipForm',compact('explodeMonthYear','departments',
            'department_id','getPayslipMonth','getEmployee','startDate','endDate'));
    }

    public function viewEmployeePaysilpList(){
        $department_id = Input::get('department_id');
        $getPayslipMonth = Input::get('payslip_month');
        $explodeMonthYear = explode('-',$getPayslipMonth);
        $getEmployee = $_GET['employee'];
        $explodePaysilpMonth = explode('-',$getPayslipMonth);
        $departments = Department::where('status', '=', '1')->where('id','=',$department_id)->get();

        return view('Hr.AjaxPages.viewEmployeePayslipList',compact('explodeMonthYear','departments','department_id','getPayslipMonth','getEmployee','explodePaysilpMonth'));
    }


    public function viewPayrollReport()
    {
        $department_id = Input::get('department_id');
        $month_year = Input::get('month_year');
        $explodeMonthYear = explode('-',$month_year);
        $departments = Department::where('status', '=', '1')->where('id','=',$department_id)->get();

        CommonHelper::companyDatabaseConnection(Input::get('m'));
        if($department_id == 'All'){
            $departments = Employee::select('emp_department_id')->groupBy('emp_department_id')->get()->toArray();
        }else{
            $departments= Employee::select('emp_department_id')->where('emp_department_id', '=', $department_id)->groupBy('emp_department_id')->get()->toArray();

        }
        CommonHelper::reconnectMasterDatabase();


        return view('Hr.AjaxPages.viewPayrollReport',compact('departments','explodeMonthYear'));
    }

    public function viewEmployeeDetail(){
        $id = Input::get('id');
        $m 	= Input::get('m');

        $subdepartments = new SubDepartment;

        $currentuser = DB::selectOne('select acc_type,username,password from `users` where `id` = '.Auth::id().'');
        $jobtype = JobType::where([['company_id', '=', $_GET['m']], ['status', '=', '1'], ])->orderBy('id')->get();;
        $departments = Department::where([['company_id', '=', $_GET['m']], ['status', '=', '1'], ])->orderBy('id')->get();
        $marital_status = MaritalStatus::where([['company_id', '=',$_GET['m']], ['status', '=', '1'], ])->orderBy('id')->get();
        $DegreeType = DegreeType::where([['company_id', '=', Input::get('m')], ['status', '=', '1']])->orderBy('id')->get();

        CommonHelper::companyDatabaseConnection($m);
        $employee_detail = DB::selectOne('select * from `employee` where `id` = '.$id.'');
        $leavesPolicy = LeavesPolicy::where([['id','=',$employee_detail->leaves_policy_id]])->first();
        $leavesData =   LeavesData::where([['leaves_policy_id','=',$employee_detail->leaves_policy_id]])->get();
        $salary_detail = EmployeeSalaryDetail::where([['emp_id', '=', $id]])->first();
        $employeeWorkExperience = EmployeeWorkExperience::where([['emp_id', '=', $id]])->get();
        $EmployeeQualification = EmployeeQualification::where([['emp_id', '=', $id]])->get();
        $EmployeeReference = EmployeeReference::where([['emp_id', '=', $id]])->get();

        CommonHelper::reconnectMasterDatabase();
        $tax = Tax::where([['id','=',$employee_detail->tax_id]])->first();
        $eobi = Eobi::where([['id','=',$employee_detail->eobi_id]])->first();
        $department_details = DB::selectOne('select sub_department.sub_department_name,department.department_name from 
		`sub_department` inner join department on sub_department.department_id=department.id where sub_department.id = '.$employee_detail->emp_sub_department_id.'');

        $data['department_details'] = $department_details;
        $data['currentuser'] = $currentuser;
        $data['DegreeType'] = $DegreeType;
        $data['tax'] = $tax;
        $data['eobi'] = $eobi;
        $data['leavesPolicy'] = $leavesPolicy;
        $data['leavesData'] = $leavesData;
        $data['jobtype'] = $jobtype;
        $data['departments'] = $departments;
        $data['subdepartments'] = $subdepartments;
        $data['marital_status'] = $marital_status;
        $data['employee_detail'] = $employee_detail;
        $data['employeeWorkExperience'] = $employeeWorkExperience;
        $data['EmployeeQualification'] = $EmployeeQualification;
        $data['EmployeeReference'] = $EmployeeReference;
        $data['salary_detail'] = $salary_detail;
        return view('Hr.AjaxPages.viewEmployeeDetail',$data);
    }

    public function viewEmployeeRequisitionDetail(){

        $array[1] ='<span class="label label-warning">Pending</span>';
        $array[2] ='<span class="label label-success">Approved</span>';
        $array[3] ='<span class="label label-danger">Rejected</span>';
        $array1[1] ="<span class='label label-success'>Active</span>";
        $array1[2] ="<span class='label label-danger'>Deleted</span>";

        CommonHelper::companyDatabaseConnection(Input::get('m'));
        $EmployeeRequisitionDetail = EmployeeRequisition::where([['id','=',Input::get('id')]])->first();
        CommonHelper::reconnectMasterDatabase();
        $data['EmployeeRequisitionDetail'] = $EmployeeRequisitionDetail;
        $data['status'] 		 = $array1[$EmployeeRequisitionDetail->status];
        $data['approval_status'] = $array[$EmployeeRequisitionDetail->approval_status];
        return view('Hr.AjaxPages.viewEmployeeRequisitionDetail',$data);

        /*<a href="https://www.facebook.com/sharer/sharer.php?u=http://www.innovative-net.com/&display=popup" target="_blank"> share this facebook </a>*/

    }

    public function viewLeavePolicyDetail()
    {

        CommonHelper::companyDatabaseConnection(Input::get('m'));
        $leavesPolicy = LeavesPolicy::where([['id','=',Input::get('id')]])->first();
        $leavesData =   LeavesData::where([['leaves_policy_id','=',Input::get('id')]])->get();

        return view('Hr.AjaxPages.viewLeavePolicyDetail',compact('leavesPolicy','leavesData'));

    }


    public function viewCarPolicyCriteria()
    {
        if(Input::get('sub_department_id') == 'all'):

            $allsubDeparments = SubDepartment::select('id','sub_department_name','department_id')->where([['status','=','1'],['company_id','=',Input::get('m')]])->get();
        else:
            $allsubDeparments = SubDepartment::select('id','sub_department_name','department_id')->where([['id','=',Input::get('sub_department_id')],['status','=','1'],['company_id','=',Input::get('m')]])->get();
        endif;

        return view('Hr.AjaxPages.viewCarPolicyCriteria',compact('allsubDeparments'));
    }


    public function  viewCarPolicy()
    {
        CommonHelper::companyDatabaseConnection(Input::get('m'));
        $carPolicyData = CarPolicy::where([['id','=',Input::get('id')],['status','=','1']])->first();
        return view('Hr.AjaxPages.viewCarPolicy',compact('carPolicyData'));
    }

    public function viewLoanRequestDetail()
    {
        CommonHelper::companyDatabaseConnection(Input::get('m'));
        $loanRequest =LoanRequest::where([['id','=',Input::get('id')]])->first();
        $employee    =Employee::select('emp_name','emp_department_id')->where([['id','=',$loanRequest->emp_id]])->first();
        CommonHelper::reconnectMasterDatabase();
        $dept_name  =Department::select('department_name')->where([['id','=',$employee->emp_department_id]])->first();

        return view('Hr.AjaxPages.viewLoanRequestDetail',compact('loanRequest','sub_dept','employee','dept_name'));
    }


    public function viewTaxCriteria()
    {
        if(Input::get('department_id') == 'all'):

            $allDepartments = Department::select('id','department_name')->where([['status','=','1'],['company_id','=',Input::get('m')]])->get();
        else:
            $allDepartments = Department::select('id','department_name')->where([['id','=',Input::get('department_id')],['status','=','1'],['company_id','=',Input::get('m')]])->get();
        endif;
        
        return view('Hr.AjaxPages.viewTaxCriteria',compact('allDepartments'));


    }

    public function viewTax()
    {

        $tax = Tax::where([['id','=',Input::get('id')],['company_id','=',Input::get('m')]])->first();
        return view('Hr.AjaxPages.viewTax',compact('tax'));

    }

    public function viewEmployeesBonus()
    {
        CommonHelper::companyDatabaseConnection(Input::get('m'));
        $all_employees = Employee::select('id','emp_name','emp_salary')->where([['emp_sub_department_id','=',Input::get('sub_department_id')],['status','=',1]])->get();
        CommonHelper::reconnectMasterDatabase();
        return view('Hr.AjaxPages.viewEmployeesBonus',compact('all_employees'));

    }

    public function viewLeaveApplicationRequestDetail()
    {
        CommonHelper::companyDatabaseConnection(Input::get('m'));
        $leave_day_type = Input::get('leave_day_type');

        if(Input::get('leave_day_type') == 1):

            $leave_application_data = DB::table('leave_application')
                ->join('leave_application_data', 'leave_application.id', '=', 'leave_application_data.leave_application_id')
                ->join('employee', 'leave_application.emp_id', '=', 'employee.id')
                ->select('employee.emp_name','employee.designation_id','leave_application.leave_address','leave_application.approval_status','leave_application.reason','leave_application.status','leave_application_data.no_of_days','leave_application_data.date','leave_application_data.from_date','leave_application_data.to_date')
                ->where([['leave_application_data.leave_application_id','=',Input::get('id')],['leave_application_data.leave_day_type','=',Input::get('leave_day_type')]])
                ->first();


            $leave_day_type_arr = [1 => 'full Day Leave',2 => 'Half Day Leave',3 => 'Short Leave'];
            $leave_day_type_label = $leave_day_type_arr[Input::get('leave_day_type')];



        elseif(Input::get('leave_day_type') == 2):


            $leave_application_data = DB::table('leave_application')
                ->join('leave_application_data', 'leave_application.id', '=', 'leave_application_data.leave_application_id')
                ->join('employee', 'leave_application.emp_id', '=', 'employee.id')
                ->select('employee.emp_name','employee.designation_id','leave_application.leave_address','leave_application.approval_status','leave_application.reason','leave_application.status','leave_application_data.first_second_half','leave_application_data.date','leave_application_data.first_second_half_date')
                ->where([['leave_application_data.leave_application_id','=',Input::get('id')],['leave_application_data.leave_day_type','=',Input::get('leave_day_type')]])
                ->first();


            $leave_day_type_arr = [1 => 'full Day Leave',2 => 'Half Day Leave',3 => 'Short Leave'];
            $leave_day_type_label = $leave_day_type_arr[Input::get('leave_day_type')];


        else:
            $leave_application_data = DB::table('leave_application')
                ->join('leave_application_data', 'leave_application.id', '=', 'leave_application_data.leave_application_id')
                ->join('employee', 'leave_application.emp_id', '=', 'employee.id')
                ->select('employee.emp_name','employee.designation_id','leave_application.approval_status','leave_application.leave_address','leave_application.reason',
                    'leave_application.status','leave_application_data.short_leave_time_from','leave_application_data.short_leave_time_to',
                    'leave_application_data.date','leave_application_data.short_leave_date')
                ->where([['leave_application_data.leave_application_id','=',Input::get('id')],['leave_application_data.leave_day_type','=',Input::get('leave_day_type')]])
                ->first();


            $leave_day_type_arr = [1 => 'full Day Leave',2 => 'Half Day Leave',3 => 'Short Leave'];
            $leave_day_type_label = $leave_day_type_arr[Input::get('leave_day_type')];

        endif;

        $approval_array[1] = '<span class="label label-warning">Pending</span>';
        $approval_array[2] = '<span class="label label-success">Approved</span>';
        $approval_array[3] = '<span class="label label-danger">Rejected</span>';

        $approval_status = $approval_array[$leave_application_data->approval_status];

        $leaves_policy = DB::table('employee')
            ->join('leaves_policy', 'leaves_policy.id', '=', 'employee.leaves_policy_id')
            ->join('leaves_data', 'leaves_data.leaves_policy_id', '=', 'leaves_policy.id')
            ->select('leaves_policy.*','leaves_data.*')
            ->where([['employee.id','=',Input::get('user_id')]])
            ->get();


        $total_leaves = DB::table("leaves_data")
            ->select(DB::raw("SUM(no_of_leaves) as total_leaves"))
            ->where([['leaves_policy_id' ,'=', $leaves_policy[0]->leaves_policy_id]])
            ->first();
        $taken_leaves = DB::table("leave_application_data")
            ->select(DB::raw("SUM(no_of_days) as taken_leaves"))
            ->join('leave_application', 'leave_application.id', '=', 'leave_application_data.leave_application_id')
            ->where([['leave_application.emp_id', '=', Auth::user()->emp_id],['leave_application.status', '=', '1'],
                ['leave_application.approval_status', '=', '2']])
            ->first();


        CommonHelper::reconnectMasterDatabase();
        $designation_name = Designation::where([['id','=',$leave_application_data->designation_id]])->value('designation_name');

        $data['total_leaves']=   		$total_leaves;
        $data['taken_leaves']= 		    $taken_leaves;
        $data['designation_name']=		$designation_name;
        $data['leave_day_type']=	    $leave_day_type;
        $data['leave_application_data']=$leave_application_data;
        $data['approval_status'] = 		$approval_status;

        $data['leave_type_name']        = Input::get('leave_type_name');
        $data['leave_day_type_label'] = $leave_day_type_label;
        $data['leaves_policy'] =        $leaves_policy;
        return view('Hr.AjaxPages.viewLeaveApplicationRequestDetail')->with($data);
    }

    public function viewLeaveApplicationDetail()
    {
        CommonHelper::companyDatabaseConnection(Input::get('m'));
        // echo $leave_type = Input::get('leave_type');
        $leave_day_type = Input::get('leave_day_type');

        if(Input::get('leave_day_type') == 1):

            $leave_application_data = DB::table('leave_application')
                ->join('leave_application_data', 'leave_application.id', '=', 'leave_application_data.leave_application_id')
                ->select('leave_application.approval_status','leave_application.leave_address','leave_application.reason','leave_application_data.no_of_days','leave_application_data.date','leave_application_data.from_date','leave_application_data.to_date')
                ->where([['leave_application_data.leave_application_id','=',Input::get('id')],['leave_application_data.leave_day_type','=',Input::get('leave_day_type')]])
                ->first();


            $leave_day_type_arr = [1 => 'full Day Leave',2 => 'Half Day Leave',3 => 'Short Leave'];
            $leave_day_type_label = $leave_day_type_arr[Input::get('leave_day_type')];


        elseif(Input::get('leave_day_type') == 2):


            $leave_application_data = DB::table('leave_application')
                ->join('leave_application_data', 'leave_application.id', '=', 'leave_application_data.leave_application_id')
                ->select('leave_application.approval_status','leave_application.leave_address','leave_application.reason','leave_application_data.first_second_half','leave_application_data.date','leave_application_data.first_second_half_date')
                ->where([['leave_application_data.leave_application_id','=',Input::get('id')],['leave_application_data.leave_day_type','=',Input::get('leave_day_type')]])
                ->first();


            $leave_day_type_arr = [1 => 'full Day Leave',2 => 'Half Day Leave',3 => 'Short Leave'];
            $leave_day_type_label = $leave_day_type_arr[Input::get('leave_day_type')];

        else:
            $leave_application_data = DB::table('leave_application')
                ->join('leave_application_data', 'leave_application.id', '=', 'leave_application_data.leave_application_id')
                ->select('leave_application.approval_status','leave_application.leave_address','leave_application.reason','leave_application_data.short_leave_time_from','leave_application_data.short_leave_time_to','leave_application_data.date','leave_application_data.short_leave_date')
                ->where([['leave_application_data.leave_application_id','=',Input::get('id')],['leave_application_data.leave_day_type','=',Input::get('leave_day_type')]])
                ->first();


            $leave_day_type_arr = [1 => 'full Day Leave',2 => 'Half Day Leave',3 => 'Short Leave'];
            $leave_day_type_label = $leave_day_type_arr[Input::get('leave_day_type')];

        endif;

        $approval_array[1] = '<span class="label label-warning">Pending</span>';
        $approval_array[2] = '<span class="label label-success">Approved</span>';
        $approval_array[3] = '<span class="label label-danger">Rejected</span>';

        $approval_status = $approval_array[$leave_application_data->approval_status];
        CommonHelper::reconnectMasterDatabase();
        return view('Hr.AjaxPages.viewLeaveApplicationDetail',compact('leave_day_type','leave_application_data','approval_status','leave_day_type_label'));
    }

    public function viewEmployeeLeaveDetail()
    {
        return view('Hr.AjaxPages.viewEmployeeLeaveDetail');

    }

}

