<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use Illuminate\Http\Request;
use Auth;
use DB;
use Config;
use App\Helpers\CommonHelper;
use App\Models\Account;
use App\Models\Category;
use App\Models\Customer;
use App\Models\Countries;
use App\Models\Subitem;
class SalesController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function toDayActivity()
    {
        return view('Sales.toDayActivity');
    }
	
	public function createCashCustomerForm()
	{
		$countries = new Countries;
		$countries = $countries::where('status', '=', 1)->get();
        CommonHelper::companyDatabaseConnection($_GET['m']);
		$accounts = new Account;
		$accounts = $accounts::orderBy('level1', 'ASC')
    				->orderBy('level2', 'ASC')
					->orderBy('level3', 'ASC')
					->orderBy('level4', 'ASC')
					->orderBy('level5', 'ASC')
					->orderBy('level6', 'ASC')
					->orderBy('level7', 'ASC')
					->where('name','=','Cash Customers')
    				->get();
        CommonHelper::reconnectMasterDatabase();
		return view('Sales.createCashCustomerForm',compact('accounts','countries'));
	}

	public function viewCashCustomerList(){
        return view('Sales.viewCashCustomerList');
    }
	
	public function createCreditCustomerForm(){
		$countries = new Countries;
		$countries = $countries::where('status', '=', 1)->get();
        CommonHelper::companyDatabaseConnection($_GET['m']);
		$accounts = new Account;
		$accounts = $accounts::orderBy('level1', 'ASC')
    				->orderBy('level2', 'ASC')
					->orderBy('level3', 'ASC')
					->orderBy('level4', 'ASC')
					->orderBy('level5', 'ASC')
					->orderBy('level6', 'ASC')
					->orderBy('level7', 'ASC')
					->where('name','=','Credit Customers')
    				->get();
        CommonHelper::reconnectMasterDatabase();
		return view('Sales.createCreditCustomerForm',compact('accounts','countries'));
	}

    public function viewCreditCustomerList(){
        return view('Sales.viewCreditCustomerList');
    }

    public function createCreditSaleVoucherForm(){
        CommonHelper::companyDatabaseConnection($_GET['m']);
        $accounts = new Account;
        $accounts = $accounts::orderBy('level1', 'ASC')
            ->orderBy('level2', 'ASC')
            ->orderBy('level3', 'ASC')
            ->orderBy('level4', 'ASC')
            ->orderBy('level5', 'ASC')
            ->orderBy('level6', 'ASC')
            ->orderBy('level7', 'ASC')
            ->where('code','like','5%')
            ->get();
        $categories = new Category;
        $categories = $categories::where('status','=','1')->get();
        $Customers = new Customer;
        $Customers = $Customers::where('status','=','1')->where('customer_type','=','3')->get();
        CommonHelper::reconnectMasterDatabase();
        return view('Sales.createCreditSaleVoucherForm',compact('accounts','categories','Customers'));
    }

    public function createCashSaleVoucherForm(){
        CommonHelper::companyDatabaseConnection($_GET['m']);
        $creditAccounts = new Account;
        $creditAccounts = $creditAccounts::orderBy('level1', 'ASC')
            ->orderBy('level2', 'ASC')
            ->orderBy('level3', 'ASC')
            ->orderBy('level4', 'ASC')
            ->orderBy('level5', 'ASC')
            ->orderBy('level6', 'ASC')
            ->orderBy('level7', 'ASC')
            ->where('code','like','5%')
            ->get();

        $debitAccounts = new Account;
        $debitAccounts = $debitAccounts::orderBy('level1', 'ASC')
            ->orderBy('level2', 'ASC')
            ->orderBy('level3', 'ASC')
            ->orderBy('level4', 'ASC')
            ->orderBy('level5', 'ASC')
            ->orderBy('level6', 'ASC')
            ->orderBy('level7', 'ASC')
            ->where('code','like','1-3')
            ->get();
        $categories = new Category;
        $categories = $categories::where('status','=','1')->get();
        $Customers = new Customer;
        $Customers = $Customers::where('status','=','1')->where('customer_type','=','2')->get();
        CommonHelper::reconnectMasterDatabase();
        return view('Sales.createCashSaleVoucherForm',compact('creditAccounts','debitAccounts','categories','Customers'));
    }

    public function viewCashSaleVouchersList(){
        return view('Sales.viewCashSaleVouchersList');
    }

    public function viewCreditSaleVouchersList(){
        return view('Sales.viewCreditSaleVouchersList');
    }
}
