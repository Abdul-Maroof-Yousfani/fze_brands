<?php

namespace App\Http\Controllers;
use Illuminate\Database\DatabaseManager;
use App\Http\Requests;
use Illuminate\Http\Request;
use App\Helpers\FinanceHelper;
use App\Helpers\CommonHelper;
use App\Models\Employee;
use App\Models\FinanceDepartment;
use App\Models\CostCenter;
use Input;
use Auth;
use DB;
use Config;
use Redirect;
use Session;
class FinanceAddDetailControler extends Controller
{
	/**
	 * Create a new controller instance.
	 *
	 * @return void
	 */
	public function __construct()
	{
		$this->middleware('auth');

	}

	/**
	 * Show the application dashboard.
	 *
	 * @return \Illuminate\Http\Response
	 */

	public function addAccountDetail(){

		FinanceHelper::companyDatabaseConnection($_GET['m']);
		$parent_code = Input::get('account_id');

		$acc_name = Input::get('acc_name');
		$o_blnc = Input::get('o_blnc');
		$o_blnc_trans = Input::get('o_blnc_trans');
		$operational = Input::get('operational');
		$sent_code = $parent_code;


		$max_id = DB::selectOne('SELECT max(`id`) as id  FROM `accounts` WHERE `parent_code` LIKE \''.$parent_code.'\'')->id;
		if($max_id == '')
		{
			$code = $sent_code.'-1';
		}
		else
		{
			$max_code2 = DB::selectOne('SELECT `code`  FROM `accounts` WHERE `id` LIKE \''.$max_id.'\'')->code;
			$max_code2;
			$max = explode('-',$max_code2);
			$code = $sent_code.'-'.(end($max)+1);
		}

		$level_array = explode('-',$code);
		$counter = 1;
		foreach($level_array as $level):
			$data1['level'.$counter] = $level;
			$counter++;
		endforeach;
		$data1['code'] = $code;
		$data1['name'] = $acc_name;
		$data1['parent_code'] = $parent_code;
		$data1['username'] 		 	= Auth::user()->name;

		$data1['date']     		  = date("Y-m-d");
		$data1['time']     		  = date("H:i:s");
		$data1['action']     		  = 'create';
		$data1['operational']		= $operational;


		$acc_id = DB::table('accounts')->insertGetId($data1);


		//$acc_id = $data1->id;

		$data2['acc_id'] =	$acc_id;
		$data2['acc_code']=	$code;
		$data2['debit_credit']=	$o_blnc_trans;
		$data2['amount'] 	  = 	$o_blnc;
		$data2['opening_bal'] 	  = 	1;
		$data2['username'] 		 	= Auth::user()->name;

		$data2['date']     		  = date("Y-m-d");
		$data2['v_date']     		= date("Y-m-d");
		$data2['time']     		  = date("H:i:s");
		$data2['action']     		  = 'create';
		DB::table('transactions')->insert($data2);

		FinanceHelper::reconnectMasterDatabase();
		return Redirect::to('finance/createAccountForm?pageType='.Input::get('pageType').'&&parentCode='.Input::get('parentCode').'&&m='.$_GET['m'].'#SFR');
	}

	function addJournalVoucherDetail(){


		FinanceHelper::companyDatabaseConnection($_GET['m']);
		$jvsSection = Input::get('jvsSection');
		foreach($jvsSection as $row){


			//   $str = DB::selectOne("select max(convert(substr(`jv_no`,3,length(substr(`jv_no`,3))-4),signed integer)) reg from `jvs` where substr(`jv_no`,-4,2) = ".date('m')." and substr(`jv_no`,-2,2) = ".date('y')."")->reg;
			$str = DB::selectOne("select count(id)id from jvs where status=1 and jv_date='".Input::get('jv_date_'.$row)."'")->id;

			$jv_no = 'jv'.($str+1);
			$slip_no = Input::get('slip_no_'.$row);
			$jv_date = Input::get('jv_date_'.$row);
			$description = Input::get('description_'.$row);

			$data1['jv_date']   	= $jv_date;
			$data1['jv_no']   		= $jv_no;
			$data1['slip_no']   	= $slip_no;
			$data1['voucherType'] 	= 1;
			$data1['description']   = $description;
			$data1['jv_status']  	= 1;
			$data1['username'] 		= Auth::user()->name;
			$data1['date'] 			= date('Y-m-d');
			$data1['time'] 			= date('H:i:s');
			//DB::table('jvs')->insert($data1);

			$master_id = DB::table('jvs')->insertGetId($data1);
			$jvsDataSection = Input::get('jvsDataSection_'.$row);
			foreach($jvsDataSection as $row1)

			{
				$d_amount =  Input::get('d_amount_'.$row.'_'.$row1.'');
				$c_amount =  Input::get('c_amount_'.$row.'_'.$row1.'');
				$account  =  Input::get('account_id_'.$row.'_'.$row1.'');
				if($d_amount !="")
				{
					$data2['debit_credit'] = 1;
					$data2['amount'] = $d_amount;
					$data['debit_credit'] = 1;
					$data['amount'] = $d_amount;
				}
				else if($c_amount !="")

				{
					$data2['debit_credit'] = 0;
					$data2['amount'] = $c_amount;
					$data['amount'] = $c_amount;
					$data['debit_credit'] =0;
				}

				$data2['jv_no']   		= $jv_no;
				$data2['jv_date']   	= $jv_date;
				$data2['acc_id'] 		= $account;
				$data2['description']   = $description;
				$data2['jv_status']   	= 1;
				$data2['username'] 		= Auth::user()->name;
				$data2['status']  		= 1;
				$data2['date'] 			= date('Y-m-d');
				$data2['time'] 			= date('H:i:s');
				$data2['master_id'] 			= $master_id;

				DB::table('jv_data')->insert($data2);


					$data['acc_id'] = $account;
					$data['acc_code'] = FinanceHelper::getAccountCodeByAccId($account,'');
					$data['particulars'] =$description;
					$data['opening_bal'] = '0';
					$data['voucher_no'] = $jv_no;
					$data['voucher_type'] = 1;
					$data['v_date'] = $jv_date;
					$data['date'] = date("Y-m-d");
					$data['time'] = date("H:i:s");
			     	$data['master_id'] = $master_id;
					$data['username'] = Auth::user()->name;
				DB::table('transactions')->insert($data);

			}


		}

		FinanceHelper::reconnectMasterDatabase();
		Session::flash('dataInsert','successfully saved.');

			return Redirect::to('finance/viewJournalVoucherList?pageType='.Input::get('pageType').'&&parentCode='.Input::get('parentCode').'&&m='.$_GET['m'].'#SFR');


	}

	function addCashPaymentVoucherDetail(){
		FinanceHelper::companyDatabaseConnection($_GET['m']);

		$pvsSection = Input::get('pvsSection');
		foreach($pvsSection as $row){
			//$str = DB::selectOne("select max(convert(substr(`pv_no`,4,length(substr(`pv_no`,4))-4),signed integer)) reg from `pvs` where substr(`pv_no`,-4,2) = ".date('m')." and substr(`pv_no`,-2,2) = ".date('y')."")->reg;
			$str = DB::selectOne("select count(id)id from pvs where status=1 and pv_date='".Input::get('pv_date_'.$row)."'
			and voucherType=1")->id;
			$pv_no = 'cpv'.($str+1);
			$slip_no = Input::get('slip_no_'.$row);
			$pv_date = Input::get('pv_date_'.$row);
			$description = Input::get('description_'.$row);

			$data1['pv_date']   	= $pv_date;
			$data1['pv_no']   		= $pv_no;
			$data1['slip_no']   	= $slip_no;
			$data1['voucherType'] 	= 1;
			$data1['description']   = $description;
			$data1['pv_status']  	= 1;
			$data1['username'] 		= Auth::user()->name;
			$data1['date'] 			= date('Y-m-d');
			$data1['time'] 			= date('H:i:s');
			$master_id = DB::table('pvs')->insertGetId($data1);
			$pvsDataSection = Input::get('pvsDataSection_'.$row);
			foreach($pvsDataSection as $row1)

			{
				$d_amount =  str_replace(',','',Input::get('d_amount_'.$row.'_'.$row1.''));
				$c_amount =  str_replace(',','',Input::get('c_amount_'.$row.'_'.$row1.''));
				$account  =  Input::get('account_id_'.$row.'_'.$row1.'');
				if($d_amount !="")
				{
					$data2['debit_credit'] = 1;
					$data2['amount'] = $d_amount;
					$data['amount'] = $d_amount;
					$data['debit_credit'] =1;
				}
				else if($c_amount !=""){
					$data2['debit_credit'] = 0;
					$data2['amount'] = $c_amount;
					$data['amount'] = $c_amount;
					$data['debit_credit'] =0;
				}

				$data2['pv_no']   		= $pv_no;
				$data2['pv_date']   	= $pv_date;
				$data2['acc_id'] 		= $account;
				$data2['description']   = $description;
				$data2['pv_status']   	= 1;
				$data2['username'] 		= Auth::user()->name;
				$data2['status']  		= 1;
				$data2['date'] 			= date('Y-m-d');
				$data2['time'] 			= date('H:i:s');
				$data2['master_id']=$master_id;

				DB::table('pv_data')->insert($data2);


				$data['acc_id'] = $account;
				$data['acc_code'] = FinanceHelper::getAccountCodeByAccId($account,'');
				$data['particulars'] =$description;
				$data['opening_bal'] = '0';
				$data['voucher_no'] = $pv_no;
				$data['voucher_type'] = 2;
				$data['v_date'] = $pv_date;
				$data['date'] = date("Y-m-d");
				$data['time'] = date("H:i:s");
				$data['master_id'] = $master_id;
				$data['username'] = Auth::user()->name;
				DB::table('transactions')->insert($data);

			}
		}
		FinanceHelper::reconnectMasterDatabase();
		Session::flash('dataInsert','successfully saved.');

		return Redirect::to('finance/viewCashPaymentVoucherList?pageType='.Input::get('pageType').'&&parentCode='.Input::get('parentCode').'&&m='.$_GET['m'].'#SFR');
	}

	function addBankPaymentVoucherDetail(){
		FinanceHelper::companyDatabaseConnection($_GET['m']);

		$pvsSection = Input::get('pvsSection');
		foreach($pvsSection as $row){
		//
		//$str = DB::selectOne("select max(convert(substr(`pv_no`,4,length(substr(`pv_no`,4))-4),signed integer)) reg from `pvs` where substr(`pv_no`,-4,2) = ".date('m')." and substr(`pv_no`,-2,2) = ".date('y')."")->reg;
			$str = DB::selectOne("select count(id)id from pvs where status=1 and pv_date='".Input::get('pv_date_'.$row)."'
			and voucherType=2
			")->id;
			$pv_no = 'bpv'.($str+1);
			$slip_no = Input::get('slip_no_'.$row);
			$pv_date = Input::get('pv_date_'.$row);
			$cheque_no = Input::get('cheque_no_'.$row);
			$cheque_date = Input::get('cheque_date_'.$row);
			$description = Input::get('description_'.$row);

			$data1['pv_date']   	= $pv_date;
			$data1['pv_no']   		= $pv_no;
			$data1['slip_no']   	= $slip_no;
			$data1['cheque_no']   		= $cheque_no;
			$data1['cheque_date']   	= $cheque_date;
			$data1['voucherType'] 	= 2;
			$data1['description']   = $description;
			$data1['username'] 		= Auth::user()->name;
			$data1['pv_status']  	= 1;
			$data1['date'] 			= date('Y-m-d');
			$data1['time'] 			= date('H:i:s');
			$master_id = DB::table('pvs')->insertGetId($data1);
			$pvsDataSection = Input::get('pvsDataSection_'.$row);
			foreach($pvsDataSection as $row1){
				$d_amount =  str_replace(',','',Input::get('d_amount_'.$row.'_'.$row1.''));
				$c_amount =   str_replace(',','',Input::get('c_amount_'.$row.'_'.$row1.''));
				$account  = Input::get('account_id_'.$row.'_'.$row1.'');
				if($d_amount !=""){
					$data2['debit_credit'] = 1;
					$data2['amount'] = $d_amount;
					$data['debit_credit'] = 1;
					$data['amount'] = $d_amount;
				}else if($c_amount !=""){
					$data2['debit_credit'] = 0;
					$data2['amount'] = $c_amount;
					$data['debit_credit'] = 0;
					$data['amount'] = $c_amount;
				}

				$data2['pv_no']   		= $pv_no;
				$data2['pv_date']   	= $pv_date;
				$data2['acc_id'] 		= $account;
				$data2['description']   = $description;
				$data2['pv_status']   	= 1;
				$data2['username'] 		= Auth::user()->name;
				$data2['status']  		= 1;
				$data2['date'] 			= date('Y-m-d');
				$data2['time'] 			= date('H:i:s');
				$data2['master_id']=$master_id;
				DB::table('pv_data')->insert($data2);



				$data['acc_id'] = $account;
				$data['acc_code'] = FinanceHelper::getAccountCodeByAccId($account,'');
				$data['particulars'] =$description;
				$data['opening_bal'] = '0';
				$data['voucher_no'] = $pv_no;
				$data['voucher_type'] = 2;
				$data['v_date'] = $pv_date;
				$data['date'] = date("Y-m-d");
				$data['time'] = date("H:i:s");
				$data['master_id'] = $master_id;
				$data['username'] = Auth::user()->name;
				DB::table('transactions')->insert($data);
			}
		}
		$type = Input::get('type');

		Session::flash('dataInsert','successfully saved.');

		if ($type==1):
			$id= Input::get('purchase_id');
			$data3['pv_status']=2;
			DB::table('purchase_voucher')->where('id', array($id))->update($data3);
			FinanceHelper::reconnectMasterDatabase();
			return Redirect::to('finance/viewPurchaseVoucherList?pageType='.Input::get('pageType').'&&parentCode='.Input::get('parentCode').'&&m='.$_GET['m'].'#SFR');
		else:
		return Redirect::to('finance/viewBankPaymentVoucherList?pageType='.Input::get('pageType').'&&parentCode='.Input::get('parentCode').'&&m='.$_GET['m'].'#SFR');
			endif;
	}

	function addCashReceiptVoucherDetail(){
		FinanceHelper::companyDatabaseConnection($_GET['m']);

		$rvsSection = Input::get('rvsSection');
		foreach($rvsSection as $row){
			//$str = DB::selectOne("select max(convert(substr(`rv_no`,4,length(substr(`rv_no`,4))-4),signed integer)) reg from `rvs` where substr(`rv_no`,-4,2) = ".date('m')." and substr(`rv_no`,-2,2) = ".date('y')."")->reg;
			$str = DB::selectOne("select count(id)id from rvs where status=1 and rv_date='".Input::get('rv_date_'.$row)."'
			and voucherType=1
			")->id;
			$rv_no = 'crv'.($str+1);
			$slip_no = Input::get('slip_no_'.$row);
			$rv_date = Input::get('rv_date_'.$row);
			$description = Input::get('description_'.$row);

			$data1['rv_date']   	= $rv_date;
			$data1['rv_no']   		= $rv_no;
			$data1['slip_no']   	= $slip_no;
			$data1['voucherType'] 	= 1;
			$data1['description']   = $description;
			$data1['rv_status']  	= 1;
			$data1['username'] 		= Auth::user()->name;
			$data1['date'] 			= date('Y-m-d');
			$data1['time'] 			= date('H:i:s');
			$master_id=DB::table('rvs')->insertGetId($data1);
			$rvsDataSection = Input::get('rvsDataSection_'.$row);
			foreach($rvsDataSection as $row1){
				$d_amount =  Input::get('d_amount_'.$row.'_'.$row1.'');
				$c_amount =  Input::get('c_amount_'.$row.'_'.$row1.'');
				$account  =  Input::get('account_id_'.$row.'_'.$row1.'');
				if($d_amount !=""){
					$data2['debit_credit'] = 1;
					$data2['amount'] = $d_amount;
					$data['debit_credit'] = 1;
					$data['amount'] = $d_amount;
				}else if($c_amount !=""){
					$data2['debit_credit'] = 0;
					$data2['amount'] = $c_amount;

					$data['debit_credit'] = 0;
					$data['amount'] = $c_amount;
				}

				$data2['rv_no']   		= $rv_no;
				$data2['rv_date']   	= $rv_date;
				$data2['acc_id'] 		= $account;
				$data2['description']   = $description;
				$data2['rv_status']   	= 1;
				$data2['status']  		= 1;
				$data2['username'] 		= Auth::user()->name;
				$data2['date'] 			= date('Y-m-d');
				$data2['time'] 			= date('H:i:s');
				$data2['master_id'] 			= $master_id;

				DB::table('rv_data')->insert($data2);



				$data['acc_id'] = $account;
				$data['acc_code'] = FinanceHelper::getAccountCodeByAccId($account,'');
				$data['particulars'] =$description;
				$data['opening_bal'] = '0';
				$data['voucher_no'] = $rv_no;
				$data['voucher_type'] = 3;
				$data['v_date'] = $rv_date;
				$data['date'] = date("Y-m-d");
				$data['time'] = date("H:i:s");
				$data['master_id'] = $master_id;
				$data['username'] = Auth::user()->name;
				DB::table('transactions')->insert($data);
			}
		}
		FinanceHelper::reconnectMasterDatabase();
		Session::flash('dataInsert','successfully saved.');
		return Redirect::to('finance/viewCashReceiptVoucherList?pageType='.Input::get('pageType').'&&parentCode='.Input::get('parentCode').'&&m='.$_GET['m'].'#SFR');
	}


	function addBankReceiptVoucherDetail(){
		FinanceHelper::companyDatabaseConnection($_GET['m']);

		$rvsSection = Input::get('rvsSection');
		foreach($rvsSection as $row){
			//$str = DB::selectOne("select max(convert(substr(`rv_no`,4,length(substr(`rv_no`,4))-4),signed integer)) reg from `rvs` where substr(`rv_no`,-4,2) = ".date('m')." and substr(`rv_no`,-2,2) = ".date('y')."")->reg;
			$str = DB::selectOne("select count(id)id from rvs where status=1 and rv_date='".Input::get('rv_date_'.$row)."'
			and voucherType=2
			")->id;
			$rv_no = 'brv'.($str+1);
			$slip_no = Input::get('slip_no_'.$row);
			$rv_date = Input::get('rv_date_'.$row);
			$cheque_no = Input::get('cheque_no_'.$row);
			$cheque_date = Input::get('cheque_date_'.$row);
			$description = Input::get('description_'.$row);

			$data1['rv_date']   	= $rv_date;
			$data1['rv_no']   		= $rv_no;
			$data1['slip_no']   	= $slip_no;
			$data1['cheque_no']   		= $cheque_no;
			$data1['cheque_date']   	= $cheque_date;
			$data1['voucherType'] 	= 2;
			$data1['description']   = $description;
			$data1['rv_status']  	= 1;
			$data1['username'] 		= Auth::user()->name;
			$data1['date'] 			= date('Y-m-d');
			$data1['time'] 			= date('H:i:s');
			$master_id=DB::table('rvs')->insertGetId($data1);
			$data2['master_id'] 			= $master_id;
			$rvsDataSection = Input::get('rvsDataSection_'.$row);
			foreach($rvsDataSection as $row1){
				$d_amount =  Input::get('d_amount_'.$row.'_'.$row1.'');
				$c_amount =  Input::get('c_amount_'.$row.'_'.$row1.'');
				$account  =  Input::get('account_id_'.$row.'_'.$row1.'');
				if($d_amount !=""){
					$data2['debit_credit'] = 1;
					$data2['amount'] = $d_amount;

					$data['debit_credit'] = 1;
					$data['amount'] = $d_amount;
				}else if($c_amount !=""){
					$data2['debit_credit'] = 0;
					$data2['amount'] = $c_amount;

					$data['debit_credit'] = 0;
					$data['amount'] = $c_amount;
				}

				$data2['rv_no']   		= $rv_no;
				$data2['rv_date']   	= $rv_date;
				$data2['acc_id'] 		= $account;
				$data2['description']   = $description;
				$data2['rv_status']   	= 1;
				$data2['status']  		= 1;
				$data2['username'] 		= Auth::user()->name;
				$data2['date'] 			= date('Y-m-d');
				$data2['time'] 			= date('H:i:s');
				$data2['master_id'] 			= $master_id;

				DB::table('rv_data')->insert($data2);


				$data['acc_id'] = $account;
				$data['acc_code'] = FinanceHelper::getAccountCodeByAccId($account,'');
				$data['particulars'] =$description;
				$data['opening_bal'] = '0';
				$data['voucher_no'] = $rv_no;
				$data['voucher_type'] = 3;
				$data['v_date'] = $rv_date;
				$data['date'] = date("Y-m-d");
				$data['time'] = date("H:i:s");
				$data['master_id'] = $master_id;
				$data['username'] = Auth::user()->name;
				DB::table('transactions')->insert($data);
			}
		}
		FinanceHelper::reconnectMasterDatabase();
		Session::flash('dataInsert','successfully saved.');
		return Redirect::to('finance/viewBankReceiptVoucherList?pageType='.Input::get('pageType').'&&parentCode='.Input::get('parentCode').'&&m='.$_GET['m'].'#SFR');
	}

	function addPurchaseCashPaymentVoucherDetail(){
		FinanceHelper::companyDatabaseConnection($_GET['m']);
		$str = DB::selectOne("select max(convert(substr(`pv_no`,4,length(substr(`pv_no`,4))-4),signed integer)) reg from `pvs` where substr(`pv_no`,-4,2) = ".date('m')." and substr(`pv_no`,-2,2) = ".date('y')."")->reg;
		$pv_no = 'cpv'.($str+1).date('my');
		$slip_no = Input::get('slip_no');
		$pv_date = Input::get('pv_date');
		$debitAccId = Input::get('supplierAccId');
		$mainDescription = Input::get('main_description');

		$data1['pv_date']   	= $pv_date;
		$data1['pv_no']   		= $pv_no;
		$data1['grn_date']   	= Input::get('grnDate');
		$data1['grn_no']   		= Input::get('grnNo');
		$data1['slip_no']   	= $slip_no;
		$data1['voucherType'] 	= 3;
		$data1['description']   = $mainDescription;
		$data1['username'] 		= Auth::user()->name;
		$data1['approve_username'] 		= Auth::user()->name;
		$data1['pv_status']  	= 2;
		$data1['date'] 			= date('Y-m-d');
		$data1['time'] 			= date('H:i:s');
		DB::table('pvs')->insert($data1);
		$pvsDataSection = Input::get('seletedGoodsReceiptNoteRow');
		$totalDebitAmount = 0;
		foreach($pvsDataSection as $row){
			$c_amount               =  Input::get('credit_'.$row.'');
			$totalDebitAmount       += $c_amount;
			$account                =  Input::get('account_id_'.$row.'');
			$data2['debit_credit']  = 0;
			$data2['amount']        = $c_amount;
			$description            = $mainDescription;

			$data2['pv_no']   		= $pv_no;
			$data2['pv_date']   	= $pv_date;
			$data2['acc_id'] 		= $account;
			$data2['description']   = $description;
			$data2['pv_status']   	= 2;
			$data2['username'] 		= Auth::user()->name;
			$data2['approve_username'] 		= Auth::user()->name;
			$data2['status']  		= 1;
			$data2['date'] 			= date('Y-m-d');
			$data2['time'] 			= date('H:i:s');

			DB::table('pv_data')->insert($data2);
		}

		$d_amount =  Input::get('debit_amount');
		$description = $mainDescription;

		$data3['debit_credit']  = 1;
		$data3['amount']        = $totalDebitAmount;
		$data3['pv_no']   		= $pv_no;
		$data3['pv_date']   	= $pv_date;
		$data3['acc_id'] 		= $debitAccId;
		$data3['description']   = $description;
		$data3['pv_status']   	= 2;
		$data3['username'] 		= Auth::user()->name;
		$data3['approve_username'] 		= Auth::user()->name;
		$data3['status']  		= 1;
		$data3['date'] 			= date('Y-m-d');
		$data3['time'] 			= date('H:i:s');

		DB::table('pv_data')->insert($data3);

		$tableTwoDetail = DB::table('pv_data')
			->where('pv_no', $pv_no)
			->where('status', '1')
			->where('pv_status', '2')->get();
		FinanceHelper::reconnectMasterDatabase();
		foreach ($tableTwoDetail as $row2) {

			$acc_code = FinanceHelper::getAccountCodeByAccId($row2->acc_id,$_GET['m']);

			$vouceherType = 4;
			$voucherNo = $row2->pv_no;
			$voucherDate = $row2->pv_date;

			$data4['acc_id'] = $row2->acc_id;
			$data4['acc_code'] = $acc_code;
			$data4['particulars'] = $row2->description;
			$data4['opening_bal'] = '0';
			$data4['debit_credit'] = $row2->debit_credit;
			$data4['amount'] = $row2->amount;
			$data4['voucher_no'] = $voucherNo;
			$data4['voucher_type'] = $vouceherType;
			$data4['v_date'] = $voucherDate;
			$data4['date'] = date("Y-m-d");
			$data4['time'] = date("H:i:s");
			$data4['username'] = Auth::user()->name;
			FinanceHelper::companyDatabaseConnection($_GET['m']);
			DB::table('transactions')->insert($data4);
			FinanceHelper::reconnectMasterDatabase();
		}


		FinanceHelper::reconnectMasterDatabase();
		Session::flash('dataInsert','successfully saved.');
		return Redirect::to('finance/viewPurchaseCashPaymentVoucherList?pageType='.Input::get('pageType').'&&parentCode='.Input::get('parentCode').'&&m='.$_GET['m'].'#SFR');
	}


	function addPurchaseBankPaymentVoucherDetail(){
		FinanceHelper::companyDatabaseConnection($_GET['m']);
		$str = DB::selectOne("select max(convert(substr(`pv_no`,4,length(substr(`pv_no`,4))-4),signed integer)) reg from `pvs` where substr(`pv_no`,-4,2) = ".date('m')." and substr(`pv_no`,-2,2) = ".date('y')."")->reg;
		$pv_no = 'bpv'.($str+1).date('my');
		$slip_no = Input::get('slip_no');
		$pv_date = Input::get('pv_date');
		$cheque_no = Input::get('cheque_no');
		$cheque_date = Input::get('cheque_date');
		$debitAccId = Input::get('supplierAccId');
		$mainDescription = Input::get('main_description');

		$data1['pv_date']   	= $pv_date;
		$data1['pv_no']   		= $pv_no;
		$data1['grn_date']   	= Input::get('grnDate');
		$data1['grn_no']   		= Input::get('grnNo');
		$data1['slip_no']   	= $slip_no;
		$data1['cheque_no']   	= $cheque_no;
		$data1['cheque_date']   	= $cheque_date;
		$data1['voucherType'] 	= 4;
		$data1['description']   = $mainDescription;
		$data1['username'] 		= Auth::user()->name;
		$data1['approve_username'] 		= Auth::user()->name;
		$data1['pv_status']  	= 2;
		$data1['date'] 			= date('Y-m-d');
		$data1['time'] 			= date('H:i:s');
	//	DB::table('pvs')->insert($data1);
		$master_id=DB::table('pvs')->insertGetId($data1);
		$pvsDataSection = Input::get('seletedGoodsReceiptNoteRow');
		$totalDebitAmount = 0;
		foreach($pvsDataSection as $row){
			$c_amount               =  Input::get('credit_'.$row.'');
			$totalDebitAmount       += $c_amount;
			$account                =  Input::get('account_id_'.$row.'');
			$data2['debit_credit']  = 0;
			$data2['amount']        = $c_amount;
			$description            = $mainDescription;

			$data2['pv_no']   		= $pv_no;
			$data2['pv_date']   	= $pv_date;
			$data2['acc_id'] 		= $account;
			$data2['description']   = $description;
			$data2['pv_status']   	= 2;
			$data2['username'] 		= Auth::user()->name;
			$data2['approve_username'] 		= Auth::user()->name;
			$data2['status']  		= 1;
			$data2['date'] 			= date('Y-m-d');
			$data2['time'] 			= date('H:i:s');
			$data2['master_id'] 			=$master_id;

			DB::table('pv_data')->insert($data2);
		}

		$d_amount =  Input::get('debit_amount');
		$description = $mainDescription;

		$data3['debit_credit']  = 1;
		$data3['amount']        = $totalDebitAmount;
		$data3['pv_no']   		= $pv_no;
		$data3['pv_date']   	= $pv_date;
		$data3['acc_id'] 		= $debitAccId;
		$data3['description']   = $description;
		$data3['pv_status']   	= 2;
		$data3['username'] 		= Auth::user()->name;
		$data3['approve_username'] 		= Auth::user()->name;
		$data3['status']  		= 1;
		$data3['date'] 			= date('Y-m-d');
		$data3['time'] 			= date('H:i:s');
		$data3['master_id'] 			=$master_id;

		DB::table('pv_data')->insert($data3);

		$tableTwoDetail = DB::table('pv_data')
			->where('pv_no', $pv_no)
			->where('status', '1')
			->where('pv_status', '2')->get();
		FinanceHelper::reconnectMasterDatabase();
		foreach ($tableTwoDetail as $row2) {

			$acc_code = FinanceHelper::getAccountCodeByAccId($row2->acc_id,$_GET['m']);

			$vouceherType = 4;
			$voucherNo = $row2->pv_no;
			$voucherDate = $row2->pv_date;

			$data4['acc_id'] = $row2->acc_id;
			$data4['acc_code'] = $acc_code;
			$data4['particulars'] = $row2->description;
			$data4['opening_bal'] = '0';
			$data4['debit_credit'] = $row2->debit_credit;
			$data4['amount'] = $row2->amount;
			$data4['voucher_no'] = $voucherNo;
			$data4['voucher_type'] = $vouceherType;
			$data4['v_date'] = $voucherDate;
			$data4['date'] = date("Y-m-d");
			$data4['master_id'] = $master_id;
			$data4['username'] = Auth::user()->name;
			FinanceHelper::companyDatabaseConnection($_GET['m']);
			DB::table('transactions')->insert($data4);
			FinanceHelper::reconnectMasterDatabase();
		}


		FinanceHelper::reconnectMasterDatabase();
		Session::flash('dataInsert','successfully saved.');
		return Redirect::to('finance/viewPurchaseBankPaymentVoucherList?pageType='.Input::get('pageType').'&&parentCode='.Input::get('parentCode').'&&m='.$_GET['m'].'#SFR');
	}

	function addSaleCashReceiptVoucherDetail(){
		FinanceHelper::companyDatabaseConnection($_GET['m']);
		$str = DB::selectOne("select max(convert(substr(`rv_no`,4,length(substr(`rv_no`,4))-4),signed integer)) reg from `rvs` where substr(`rv_no`,-4,2) = ".date('m')." and substr(`rv_no`,-2,2) = ".date('y')."")->reg;
		$rv_no = 'crv'.($str+1).date('my');
		$slip_no = Input::get('slip_no');
		$rv_date = Input::get('rv_date');
		$creditAccId = Input::get('customerAccId');
		$mainDescription = Input::get('main_description');

		$data1['rv_date']   	= $rv_date;
		$data1['rv_no']   		= $rv_no;
		$data1['inv_date']   	= Input::get('invoiceDate');
		$data1['inv_no']   		= Input::get('invoiceNo');
		$data1['slip_no']   	= $slip_no;
		$data1['voucherType'] 	= 4;
		$data1['sale_receipt_type'] 	= 1;
		$data1['description']   = $mainDescription;
		$data1['username'] 		= Auth::user()->name;
		$data1['approve_username'] 		= Auth::user()->name;
		$data1['rv_status']  	= 2;
		$data1['date'] 			= date('Y-m-d');
		$data1['time'] 			= date('H:i:s');
		DB::table('rvs')->insert($data1);
		$rvsDataSection = Input::get('seletedInvoiceRow');
		$totalCreditAmount = 0;
		foreach($rvsDataSection as $row){
			$d_amount               =  Input::get('debit_'.$row.'');
			$totalCreditAmount       += $d_amount;
			$account                =  Input::get('account_id_'.$row.'');
			$data2['debit_credit']  = 1;
			$data2['amount']        = $d_amount;
			$description            = $mainDescription;

			$data2['rv_no']   		= $rv_no;
			$data2['rv_date']   	= $rv_date;
			$data2['acc_id'] 		= $account;
			$data2['description']   = $description;
			$data2['rv_status']   	= 2;
			$data2['username'] 		= Auth::user()->name;
			$data2['approve_username'] 		= Auth::user()->name;
			$data2['status']  		= 1;
			$data2['date'] 			= date('Y-m-d');
			$data2['time'] 			= date('H:i:s');

			DB::table('rv_data')->insert($data2);
		}

		$d_amount =  Input::get('debit_amount');
		$description = $mainDescription;

		$data3['debit_credit']  = 0;
		$data3['amount']        = $totalCreditAmount;
		$data3['rv_no']   		= $rv_no;
		$data3['rv_date']   	= $rv_date;
		$data3['acc_id'] 		= $creditAccId;
		$data3['description']   = $description;
		$data3['rv_status']   	= 2;
		$data3['username'] 		= Auth::user()->name;
		$data3['approve_username'] 		= Auth::user()->name;
		$data3['status']  		= 1;
		$data3['date'] 			= date('Y-m-d');
		$data3['time'] 			= date('H:i:s');

		DB::table('rv_data')->insert($data3);

		$tableTwoDetail = DB::table('rv_data')
			->where('rv_no', $rv_no)
			->where('status', '1')
			->where('rv_status', '2')->get();
		FinanceHelper::reconnectMasterDatabase();
		foreach ($tableTwoDetail as $row2) {

			$acc_code = FinanceHelper::getAccountCodeByAccId($row2->acc_id,$_GET['m']);

			$vouceherType = 4;
			$voucherNo = $row2->rv_no;
			$voucherDate = $row2->rv_date;

			$data4['acc_id'] = $row2->acc_id;
			$data4['acc_code'] = $acc_code;
			$data4['particulars'] = $row2->description;
			$data4['opening_bal'] = '0';
			$data4['debit_credit'] = $row2->debit_credit;
			$data4['amount'] = $row2->amount;
			$data4['voucher_no'] = $voucherNo;
			$data4['voucher_type'] = $vouceherType;
			$data4['v_date'] = $voucherDate;
			$data4['date'] = date("Y-m-d");
			$data4['time'] = date("H:i:s");
			$data4['username'] = Auth::user()->name;
			FinanceHelper::companyDatabaseConnection($_GET['m']);
			DB::table('transactions')->insert($data4);
			FinanceHelper::reconnectMasterDatabase();
		}


		FinanceHelper::reconnectMasterDatabase();
		Session::flash('dataInsert','successfully saved.');
		return Redirect::to('finance/viewSaleCashReceiptVoucherList?pageType='.Input::get('pageType').'&&parentCode='.Input::get('parentCode').'&&m='.$_GET['m'].'#SFR');
	}

	function addSaleBankReceiptVoucherDetail(){
		FinanceHelper::companyDatabaseConnection($_GET['m']);
		$str = DB::selectOne("select max(convert(substr(`rv_no`,4,length(substr(`rv_no`,4))-4),signed integer)) reg from `rvs` where substr(`rv_no`,-4,2) = ".date('m')." and substr(`rv_no`,-2,2) = ".date('y')."")->reg;
		$rv_no = 'brv'.($str+1).date('my');
		$slip_no = Input::get('slip_no');
		$rv_date = Input::get('rv_date');
		$cheque_no = Input::get('cheque_no');
		$cheque_date = Input::get('cheque_date');
		$creditAccId = Input::get('customerAccId');
		$mainDescription = Input::get('main_description');

		$data1['rv_date']   	= $rv_date;
		$data1['rv_no']   		= $rv_no;
		$data1['inv_date']   	= Input::get('invoiceDate');
		$data1['inv_no']   		= Input::get('invoiceNo');
		$data1['slip_no']   	= $slip_no;
		$data1['cheque_no']   	= $cheque_no;
		$data1['cheque_date']   	= $cheque_date;
		$data1['voucherType'] 	= 4;
		$data1['sale_receipt_type'] 	= 2;
		$data1['description']   = $mainDescription;
		$data1['username'] 		= Auth::user()->name;
		$data1['approve_username'] 		= Auth::user()->name;
		$data1['rv_status']  	= 2;
		$data1['date'] 			= date('Y-m-d');
		$data1['time'] 			= date('H:i:s');
		DB::table('rvs')->insert($data1);
		$rvsDataSection = Input::get('seletedInvoiceRow');
		$totalCreditAmount = 0;
		foreach($rvsDataSection as $row){
			$d_amount               =  Input::get('debit_'.$row.'');
			$totalCreditAmount       += $d_amount;
			$account                =  Input::get('account_id_'.$row.'');
			$data2['debit_credit']  = 1;
			$data2['amount']        = $d_amount;
			$description            = $mainDescription;

			$data2['rv_no']   		= $rv_no;
			$data2['rv_date']   	= $rv_date;
			$data2['acc_id'] 		= $account;
			$data2['description']   = $description;
			$data2['rv_status']   	= 2;
			$data2['username'] 		= Auth::user()->name;
			$data2['approve_username'] 		= Auth::user()->name;
			$data2['status']  		= 1;
			$data2['date'] 			= date('Y-m-d');
			$data2['time'] 			= date('H:i:s');

			DB::table('rv_data')->insert($data2);
		}

		$d_amount =  Input::get('debit_amount');
		$description = $mainDescription;

		$data3['debit_credit']  = 0;
		$data3['amount']        = $totalCreditAmount;
		$data3['rv_no']   		= $rv_no;
		$data3['rv_date']   	= $rv_date;
		$data3['acc_id'] 		= $creditAccId;
		$data3['description']   = $description;
		$data3['rv_status']   	= 2;
		$data3['username'] 		= Auth::user()->name;
		$data3['approve_username'] 		= Auth::user()->name;
		$data3['status']  		= 1;
		$data3['date'] 			= date('Y-m-d');
		$data3['time'] 			= date('H:i:s');

		DB::table('rv_data')->insert($data3);

		$tableTwoDetail = DB::table('rv_data')
			->where('rv_no', $rv_no)
			->where('status', '1')
			->where('rv_status', '2')->get();
		FinanceHelper::reconnectMasterDatabase();
		foreach ($tableTwoDetail as $row2) {

			$acc_code = FinanceHelper::getAccountCodeByAccId($row2->acc_id,$_GET['m']);

			$vouceherType = 4;
			$voucherNo = $row2->rv_no;
			$voucherDate = $row2->rv_date;

			$data4['acc_id'] = $row2->acc_id;
			$data4['acc_code'] = $acc_code;
			$data4['particulars'] = $row2->description;
			$data4['opening_bal'] = '0';
			$data4['debit_credit'] = $row2->debit_credit;
			$data4['amount'] = $row2->amount;
			$data4['voucher_no'] = $voucherNo;
			$data4['voucher_type'] = $vouceherType;
			$data4['v_date'] = $voucherDate;
			$data4['date'] = date("Y-m-d");
			$data4['time'] = date("H:i:s");
			$data4['username'] = Auth::user()->name;
			FinanceHelper::companyDatabaseConnection($_GET['m']);
			DB::table('transactions')->insert($data4);
			FinanceHelper::reconnectMasterDatabase();
		}


		FinanceHelper::reconnectMasterDatabase();
		Session::flash('dataInsert','successfully saved.');
		return Redirect::to('finance/viewSaleBankReceiptVoucherList?pageType='.Input::get('pageType').'&&parentCode='.Input::get('parentCode').'&&m='.$_GET['m'].'#SFR');
	}

	public function addEmployeeTaxDetail(Request $request)
	{
		CommonHelper::companyDatabaseConnection(Input::get('m'));
		$Employee = Employee::find(Input::get('employee_id'));
		$Employee->tax_id = $request->tax_id;
		$Employee->save();
		CommonHelper::reconnectMasterDatabase();

		Session::flash('dataInsert','successfully saved.');
		return Redirect::to('finance/viewEmployeeTaxList?pageType=viewlist&&parentCode=20&&m='.Input::get('m').'');

	}

	public function addEmployeeEOBIDetail(Request $request)
	{
		CommonHelper::companyDatabaseConnection(Input::get('m'));
		$Employee = Employee::find(Input::get('employee_id'));
		$Employee->eobi_id = $request->eobi_id;
		$Employee->save();
		CommonHelper::reconnectMasterDatabase();

		Session::flash('dataInsert','successfully saved.');
		return Redirect::to('finance/viewEmployeeEOBIList?pageType=viewlist&&parentCode=20&&m='.Input::get('m').'');

	}

	public function addDepartmentForm(Request $request)
	{
		$name=$request->dept_name;
		$department=new FinanceDepartment();
		$department=$department->SetConnection('mysql2');
	    $department_count=$department->where('status',1)->where('name',$name)->count();
		if ($department_count >0):
			Session::flash('dataDelete',$name.' '.'Already Exists.');
			return Redirect::to('finance/createDepartmentForm?pageType=add&&parentCode=82&&m=1#SFR');
			else:
				$parent_code = $request->account_id;
				$sent_code = $parent_code;


				if ($request->first_level==1):
					$max_id = DB::connection('mysql2')->selectOne('SELECT max(`id`) as id  FROM `finance_department` WHERE `first_level`=1')->id;
					$code=$max_id+1;
					$level=$code;
				$department->level1=$level;

					else:


				$max_id = DB::connection('mysql2')->selectOne('SELECT max(`id`) as id  FROM `finance_department` WHERE `parent_code` LIKE \''.$parent_code.'\'')->id;
				if($max_id == '')
				{
					$code = $sent_code.'-1';
				}
				else
				{
					$max_code2 = DB::connection('mysql2')->selectOne('SELECT `code`  FROM `finance_department` WHERE `id` LIKE \''.$max_id.'\'')->code;
					$max_code2;
					$max = explode('-',$max_code2);
					$code = $sent_code.'-'.(end($max)+1);
				}



				$level_array = explode('-',$code);
				$counter = 1;
				foreach($level_array as $level):
				 	$levell='level'.$counter.'';
					$department->$levell=$level;
				
					$counter++;
				endforeach;


							endif;
				$department->code = $code;
				$department->parent_code = $parent_code;
				$department->first_level = $request->first_level;
				$department->name=$name;
				$department->username=Auth::user()->name;
	 			$department->date=date('Y-m-d');
				$department->save();
				Session::flash('dataInsert','successfully saved.');
		       return Redirect::to('finance/createDepartmentForm?pageType=add&&parentCode=82&&m=1#SFR');
				endif;

	}

	public function addCostCenterForm(Request $request)
	{
		$name=$request->cost_center;
		$cost_center=new CostCenter();
		$cost_center=$cost_center->SetConnection('mysql2');
		$cost_center_count=$cost_center->where('status',1)->where('name',$name)->count();
		if ($cost_center_count >0):
			Session::flash('dataDelete',$name.' '.'Already Exists.');
			return Redirect::to('finance/createCostCenterForm?pageType=add&&parentCode=82&&m=1#SFR');
		else:
			$parent_code = $request->parent_cost_center;
			$sent_code = $parent_code;
			if ($request->first_level==1):
				$max_id = DB::connection('mysql2')->selectOne('SELECT max(`id`) as id  FROM `cost_center` WHERE `first_level`=1')->id;
				$code=$max_id+1;
				$level=$code;
				$cost_center->level1=$level;
			else:
				$max_id = DB::connection('mysql2')->selectOne('SELECT max(`id`) as id  FROM `cost_center` WHERE `parent_code` LIKE \''.$parent_code.'\'')->id;
				if($max_id == '')
				{
					$code = $sent_code.'-1';
				}
				else
				{
					$max_code2 = DB::connection('mysql2')->selectOne('SELECT `code`  FROM `cost_center` WHERE `id` LIKE \''.$max_id.'\'')->code;
					$max_code2;
					$max = explode('-',$max_code2);
					$code = $sent_code.'-'.(end($max)+1);
				}
				$level_array = explode('-',$code);
				$counter = 1;
				foreach($level_array as $level):
					$levell='level'.$counter.'';
					$cost_center->$levell=$level;
					$counter++;
				endforeach;
			endif;
			$cost_center->code = $code;
			$cost_center->parent_code = $parent_code;
			$cost_center->first_level = $request->first_level;
			$cost_center->name=$name;
			$cost_center->username=Auth::user()->name;
			$cost_center->date=date('Y-m-d');
			$cost_center->save();
			Session::flash('dataInsert','successfully saved.');
			return Redirect::to('finance/createCostCenterForm?pageType=add&&parentCode=82&&m=1#SFR');
		endif;

	}

}
