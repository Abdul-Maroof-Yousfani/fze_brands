<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use Illuminate\Http\Request;
use App\Helpers\StoreHelper;
use App\Helpers\CommonHelper;
use Auth;
use DB;
use Config;
use Session;
use App\Models\Supplier;
use App\Models\Category;
use App\Models\Subitem;
use App\Models\UOM;
use App\Models\Demand;
use App\Models\DemandData;
use App\Models\StoreChallan;
use App\Models\StoreChallanData;
use App\Models\PurchaseRequest;
use App\Models\PurchaseRequestData;
use App\Models\StoreChallanReturn;
use App\Models\StoreChallanReturnData;
class StoreDataCallController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */

    public function filterDemandVoucherList(){
        $fromDate = $_GET['fromDate'];
        $toDate = $_GET['toDate'];
        $m = $_GET['m'];
        $counter = 1;
        $selectVoucherStatus = $_GET['selectVoucherStatus'];
        $selectSubDepartment = $_GET['selectSubDepartment'];
        $selectSubDepartmentId = $_GET['selectSubDepartmentId'];

        CommonHelper::companyDatabaseConnection($m);
        if($selectVoucherStatus == '0' && empty($selectSubDepartmentId)){
            $demandDetail = Demand::whereBetween('demand_date',[$fromDate,$toDate])->get();
        }else if($selectVoucherStatus == '0' && !empty($selectSubDepartmentId)){
            $demandDetail = Demand::whereBetween('demand_date',[$fromDate,$toDate])->whereIn('status', array(1, 2))->where('sub_department_id','=',$selectSubDepartmentId)->get();
        }else if($selectVoucherStatus == '1' && !empty($selectSubDepartmentId)){
            $demandDetail = Demand::whereBetween('demand_date',[$fromDate,$toDate])->where('status','=','1')->where('demand_status','=','1')->where('sub_department_id','=',$selectSubDepartmentId)->get();
        }else if($selectVoucherStatus == '2' && !empty($selectSubDepartmentId)){
            $demandDetail = Demand::whereBetween('demand_date',[$fromDate,$toDate])->where('status','=','1')->where('demand_status','=','2')->where('sub_department_id','=',$selectSubDepartmentId)->get();
        }else if($selectVoucherStatus == '3' && !empty($selectSubDepartmentId)){
            $demandDetail = Demand::whereBetween('demand_date',[$fromDate,$toDate])->where('status','=','2')->where('sub_department_id','=',$selectSubDepartmentId)->get();
        }else if($selectVoucherStatus == '1' && empty($selectSubDepartmentId)){
            $demandDetail = Demand::whereBetween('demand_date',[$fromDate,$toDate])->where('status','=','1')->where('demand_status','=','1')->get();
        }else if($selectVoucherStatus == '2' && empty($selectSubDepartmentId)){
            $demandDetail = Demand::whereBetween('demand_date',[$fromDate,$toDate])->where('status','=','1')->where('demand_status','=','2')->get();
        }else if($selectVoucherStatus == '3' && empty($selectSubDepartmentId)){
            $demandDetail = Demand::whereBetween('demand_date',[$fromDate,$toDate])->where('status','=','2')->get();
        }


        //CommonHelper::companyDatabaseConnection($m);
        //$demandDetail = Demand::whereBetween('demand_date',[$fromDate,$toDate])->where('demand_status','=','2')->get();
        CommonHelper::reconnectMasterDatabase();
        return view('Store.AjaxPages.filterDemandVoucherList',compact('demandDetail'));
    }

    public function viewDemandVoucherDetail(){
        return view('Purchase.AjaxPages.viewDemandVoucherDetail');
    }

    public function filterApproveDemandListandCreateStoreChallan(){
        return view('Store.AjaxPages.filterApproveDemandListandCreateStoreChallan');
    }

    public function createStoreChallanDetailForm(Request $request){
        return view('Store.createStoreChallanDetailForm',compact('request'));
    }

    public function filterStoreChallanVoucherList(){
        $fromDate = $_GET['fromDate'];
        $toDate = $_GET['toDate'];
        $m = $_GET['m'];
        $selectVoucherStatus = $_GET['selectVoucherStatus'];
        $selectSubDepartment = $_GET['selectSubDepartment'];
        $selectSubDepartmentId = $_GET['selectSubDepartmentId'];

        CommonHelper::companyDatabaseConnection($m);
        if($selectVoucherStatus == '0' && empty($selectSubDepartmentId)){
            $storeChallanDetail = StoreChallan::whereBetween('store_challan_date',[$fromDate,$toDate])->get();
        }else if($selectVoucherStatus == '0' && !empty($selectSubDepartmentId)){
            $storeChallanDetail = StoreChallan::whereBetween('store_challan_date',[$fromDate,$toDate])->whereIn('status', array(1, 2))->where('sub_department_id','=',$selectSubDepartmentId)->get();
        }else if($selectVoucherStatus == '1' && !empty($selectSubDepartmentId)){
            $storeChallanDetail = StoreChallan::whereBetween('store_challan_date',[$fromDate,$toDate])->where('status','=','1')->where('store_challan_status','=','1')->where('sub_department_id','=',$selectSubDepartmentId)->get();
        }else if($selectVoucherStatus == '2' && !empty($selectSubDepartmentId)){
            $storeChallanDetail = StoreChallan::whereBetween('store_challan_date',[$fromDate,$toDate])->where('status','=','1')->where('store_challan_status','=','2')->where('sub_department_id','=',$selectSubDepartmentId)->get();
        }else if($selectVoucherStatus == '3' && !empty($selectSubDepartmentId)){
            $storeChallanDetail = StoreChallan::whereBetween('store_challan_date',[$fromDate,$toDate])->where('status','=','2')->where('sub_department_id','=',$selectSubDepartmentId)->get();
        }else if($selectVoucherStatus == '1' && empty($selectSubDepartmentId)){
            $storeChallanDetail = StoreChallan::whereBetween('store_challan_date',[$fromDate,$toDate])->where('status','=','1')->where('store_challan_status','=','1')->get();
        }else if($selectVoucherStatus == '2' && empty($selectSubDepartmentId)){
            $storeChallanDetail = StoreChallan::whereBetween('store_challan_date',[$fromDate,$toDate])->where('status','=','1')->where('store_challan_status','=','2')->get();
        }else if($selectVoucherStatus == '3' && empty($selectSubDepartmentId)){
            $storeChallanDetail = StoreChallan::whereBetween('store_challan_date',[$fromDate,$toDate])->where('status','=','2')->get();
        }

        //$storeChallanDetail = StoreChallan::whereBetween('store_challan_date',[$fromDate,$toDate])->where('status','=','1')->get();
        CommonHelper::reconnectMasterDatabase();

        return view('Store.AjaxPages.filterStoreChallanVoucherList',compact('storeChallanDetail'));
    }

    public function viewStoreChallanVoucherDetail(){
        return view('Store.AjaxPages.viewStoreChallanVoucherDetail');
    }

    public function filterApproveDemandListandCreatePurchaseRequest(){
        return view('Store.AjaxPages.filterApproveDemandListandCreatePurchaseRequest');
    }

    public function filterApproveDemandListandCreatePurchaseRequestSale(){
        return view('Store.AjaxPages.filterApproveDemandListandCreatePurchaseRequestSale');
    }

    public function createPurchaseRequestDetailForm(Request $request){
        $m = $_GET['m'];
        CommonHelper::companyDatabaseConnection($m);
        $supplierList = Supplier::select('name','id','acc_id','ntn')->where('status','=','1')->get();
        CommonHelper::reconnectMasterDatabase();
        return view('Store.createPurchaseRequestDetailForm',compact('request','supplierList'));
    }

    public function createPurchaseRequestSaleDetailForm(Request $request){
        $m = $_GET['m'];
        CommonHelper::companyDatabaseConnection($m);
        $supplierList = Supplier::select('name','id','acc_id')->where('status','=','1')->get();
        CommonHelper::reconnectMasterDatabase();
        return view('Store.createPurchaseRequestSaleDetailForm',compact('request','supplierList'));
    }

    public function filterPurchaseRequestVoucherList(){

        $fromDate = $_GET['fromDate'];
        $toDate = $_GET['toDate'];
        $m = $_GET['m'];
        $selectVoucherStatus = $_GET['selectVoucherStatus'];
        $selectSubDepartment = $_GET['selectSubDepartment'];
        $selectSubDepartmentId = $_GET['selectSubDepartmentId'];
        $selectSupplier = $_GET['selectSupplier'];
        $selectSupplierId = $_GET['selectSupplierId'];
        CommonHelper::companyDatabaseConnection($m);
         $selectVoucherStatus;

        if($selectVoucherStatus == '0' && empty($selectSubDepartmentId) && empty($selectSupplierId)){


            //return 'One';
            $purchaseRequestDetail = PurchaseRequest::whereBetween('purchase_request_date',[$fromDate,$toDate])->where('demand_type','=','1')->get();
        }else if($selectVoucherStatus == '0' && !empty($selectSubDepartmentId) && empty($selectSupplierId)){
            //return 'Two';
            $purchaseRequestDetail = PurchaseRequest::whereBetween('purchase_request_date',[$fromDate,$toDate])->whereIn('status', array(1, 2))->where('demand_type','=','1')->where('sub_department_id','=',$selectSubDepartmentId)->get();
        }else if($selectVoucherStatus == '0' && empty($selectSubDepartmentId) && !empty($selectSupplierId)){
            //return 'Three';
            $purchaseRequestDetail = PurchaseRequest::whereBetween('purchase_request_date',[$fromDate,$toDate])->whereIn('status', array(1, 2))->where('demand_type','=','1')->where('supplier_id','=',$selectSupplierId)->get();
        }else if($selectVoucherStatus == '1' && !empty($selectSubDepartmentId) && empty($selectSupplierId)){
            //return 'Four';
            $purchaseRequestDetail = PurchaseRequest::whereBetween('purchase_request_date',[$fromDate,$toDate])->where('status','=','1')->where('demand_type','=','1')->where('purchase_request_status','=','1')->where('sub_department_id','=',$selectSubDepartmentId)->get();
        }else if($selectVoucherStatus == '2' && !empty($selectSubDepartmentId) && empty($selectSupplierId)){
            //return 'Five';
            $purchaseRequestDetail = PurchaseRequest::whereBetween('purchase_request_date',[$fromDate,$toDate])->where('status','=','1')->where('demand_type','=','1')->where('purchase_request_status','=','2')->where('sub_department_id','=',$selectSubDepartmentId)->get();
        }else if($selectVoucherStatus == '3' && !empty($selectSubDepartmentId) && empty($selectSupplierId)){
            //return 'Six';
            $purchaseRequestDetail = PurchaseRequest::whereBetween('purchase_request_date',[$fromDate,$toDate])->where('status','=','2')->where('demand_type','=','1')->where('sub_department_id','=',$selectSubDepartmentId)->get();
        }else if($selectVoucherStatus == '1' && empty($selectSubDepartmentId) && empty($selectSupplierId)){
            //return 'Seven';
            $purchaseRequestDetail = PurchaseRequest::whereBetween('purchase_request_date',[$fromDate,$toDate])->where('status','=','1')->where('demand_type','=','1')->where('purchase_request_status','=','1')->get();
        }else if($selectVoucherStatus == '2' && empty($selectSubDepartmentId) && empty($selectSupplierId)){
            //return 'Eight';
            $purchaseRequestDetail = PurchaseRequest::whereBetween('purchase_request_date',[$fromDate,$toDate])->where('status','=','1')->where('demand_type','=','1')->where('purchase_request_status','=','2')->get();
        }else if($selectVoucherStatus == '3' && empty($selectSubDepartmentId) && empty($selectSupplierId)){
            //return 'Nine';
            $purchaseRequestDetail = PurchaseRequest::whereBetween('purchase_request_date',[$fromDate,$toDate])->where('status','=','2')->where('demand_type','=','1')->get();
        }
        else if($selectVoucherStatus == '1' && empty($selectSubDepartmentId) && !empty($selectSupplierId)){
            //return 'Ten';
            $purchaseRequestDetail = PurchaseRequest::whereBetween('purchase_request_date',[$fromDate,$toDate])->where('status','=','1')->where('demand_type','=','1')->where('purchase_request_status','=','1')->where('supplier_id','=',$selectSupplierId)->get();
        }else if($selectVoucherStatus == '2' && empty($selectSubDepartmentId) && !empty($selectSupplierId)){
            //return 'Eleven';
            $purchaseRequestDetail = PurchaseRequest::whereBetween('purchase_request_date',[$fromDate,$toDate])->where('status','=','1')->where('demand_type','=','1')->where('purchase_request_status','=','2')->where('supplier_id','=',$selectSupplierId)->get();
        }else if($selectVoucherStatus == '3' && empty($selectSubDepartmentId) && !empty($selectSupplierId)){
            //return 'Twelve';
            $purchaseRequestDetail = PurchaseRequest::whereBetween('purchase_request_date',[$fromDate,$toDate])->where('status','=','2')->where('demand_type','=','1')->where('supplier_id','=',$selectSupplierId)->get();
        }else if($selectVoucherStatus == '0' && !empty($selectSubDepartmentId) && !empty($selectSupplierId)){
            //return 'Thirteen';
            $purchaseRequestDetail = PurchaseRequest::whereBetween('purchase_request_date',[$fromDate,$toDate])->where('supplier_id','=',$selectSupplierId)->where('demand_type','=','1')->where('sub_department_id','=',$selectSubDepartmentId)->get();
        }else if($selectVoucherStatus == '1' && !empty($selectSubDepartmentId) && !empty($selectSupplierId)){
            //return 'Fourteen';
            $purchaseRequestDetail = PurchaseRequest::whereBetween('purchase_request_date',[$fromDate,$toDate])->where('status','=','1')->where('demand_type','=','1')->where('purchase_request_status','=','1')->where('supplier_id','=',$selectSupplierId)->where('sub_department_id','=',$selectSubDepartmentId)->get();
        }else if($selectVoucherStatus == '2' && !empty($selectSubDepartmentId) && !empty($selectSupplierId)){
            //return 'Fifteen';
            $purchaseRequestDetail = PurchaseRequest::whereBetween('purchase_request_date',[$fromDate,$toDate])->where('status','=','1')->where('demand_type','=','1')->where('purchase_request_status','=','2')->where('supplier_id','=',$selectSupplierId)->where('sub_department_id','=',$selectSubDepartmentId)->get();
        }else if($selectVoucherStatus == '3' && !empty($selectSubDepartmentId) && !empty($selectSupplierId)){
            //return 'Sixteen';
            $purchaseRequestDetail = PurchaseRequest::whereBetween('purchase_request_date',[$fromDate,$toDate])->where('status','=','2')->where('demand_type','=','1')->where('supplier_id','=',$selectSupplierId)->where('sub_department_id','=',$selectSubDepartmentId)->get();
        }
        CommonHelper::reconnectMasterDatabase();
        return view('Store.AjaxPages.filterPurchaseRequestVoucherList',compact('purchaseRequestDetail'));
    }


    public function filterPurchaseRequestSaleVoucherList(){

        $fromDate = $_GET['fromDate'];
        $toDate = $_GET['toDate'];
        $m = $_GET['m'];
        $selectVoucherStatus = $_GET['selectVoucherStatus'];
        $selectSubDepartment = $_GET['selectSubDepartment'];
        $selectSubDepartmentId = $_GET['selectSubDepartmentId'];
        $selectSupplier = $_GET['selectSupplier'];
        $selectSupplierId = $_GET['selectSupplierId'];
        CommonHelper::companyDatabaseConnection($m);
        if($selectVoucherStatus == '0' && empty($selectSubDepartmentId) && empty($selectSupplierId)){
            //return 'One';
            $purchaseRequestSaleDetail = PurchaseRequest::whereBetween('purchase_request_date',[$fromDate,$toDate])->where('demand_type','=','2')->get();
        }else if($selectVoucherStatus == '0' && !empty($selectSubDepartmentId) && empty($selectSupplierId)){
            //return 'Two';
            $purchaseRequestSaleDetail = PurchaseRequest::whereBetween('purchase_request_date',[$fromDate,$toDate])->where('demand_type','=','2')->whereIn('status', array(1, 2))->where('sub_department_id','=',$selectSubDepartmentId)->get();
        }else if($selectVoucherStatus == '0' && empty($selectSubDepartmentId) && !empty($selectSupplierId)){
            //return 'Three';
            $purchaseRequestSaleDetail = PurchaseRequest::whereBetween('purchase_request_date',[$fromDate,$toDate])->where('demand_type','=','2')->whereIn('status', array(1, 2))->where('supplier_id','=',$selectSupplierId)->get();
        }else if($selectVoucherStatus == '1' && !empty($selectSubDepartmentId) && empty($selectSupplierId)){
            //return 'Four';
            $purchaseRequestSaleDetail = PurchaseRequest::whereBetween('purchase_request_date',[$fromDate,$toDate])->where('demand_type','=','2')->where('status','=','1')->where('purchase_request_status','=','1')->where('sub_department_id','=',$selectSubDepartmentId)->get();
        }else if($selectVoucherStatus == '2' && !empty($selectSubDepartmentId) && empty($selectSupplierId)){
            //return 'Five';
            $purchaseRequestSaleDetail = PurchaseRequest::whereBetween('purchase_request_date',[$fromDate,$toDate])->where('demand_type','=','2')->where('status','=','1')->where('purchase_request_status','=','2')->where('sub_department_id','=',$selectSubDepartmentId)->get();
        }else if($selectVoucherStatus == '3' && !empty($selectSubDepartmentId) && empty($selectSupplierId)){
            //return 'Six';
            $purchaseRequestSaleDetail = PurchaseRequest::whereBetween('purchase_request_date',[$fromDate,$toDate])->where('demand_type','=','2')->where('status','=','2')->where('sub_department_id','=',$selectSubDepartmentId)->get();
        }else if($selectVoucherStatus == '1' && empty($selectSubDepartmentId) && empty($selectSupplierId)){
            //return 'Seven';
            $purchaseRequestSaleDetail = PurchaseRequest::whereBetween('purchase_request_date',[$fromDate,$toDate])->where('demand_type','=','2')->where('status','=','1')->where('purchase_request_status','=','1')->get();
        }else if($selectVoucherStatus == '2' && empty($selectSubDepartmentId) && empty($selectSupplierId)){
            //return 'Eight';
            $purchaseRequestSaleDetail = PurchaseRequest::whereBetween('purchase_request_date',[$fromDate,$toDate])->where('demand_type','=','2')->where('status','=','1')->where('purchase_request_status','=','2')->get();
        }else if($selectVoucherStatus == '3' && empty($selectSubDepartmentId) && empty($selectSupplierId)){
            //return 'Nine';
            $purchaseRequestSaleDetail = PurchaseRequest::whereBetween('purchase_request_date',[$fromDate,$toDate])->where('demand_type','=','2')->where('status','=','2')->get();
        }else if($selectVoucherStatus == '1' && empty($selectSubDepartmentId) && !empty($selectSupplierId)){
            //return 'Ten';
            $purchaseRequestSaleDetail = PurchaseRequest::whereBetween('purchase_request_date',[$fromDate,$toDate])->where('demand_type','=','2')->where('status','=','1')->where('purchase_request_status','=','1')->where('supplier_id','=',$selectSupplierId)->get();
        }else if($selectVoucherStatus == '2' && empty($selectSubDepartmentId) && !empty($selectSupplierId)){
            //return 'Eleven';
            $purchaseRequestSaleDetail = PurchaseRequest::whereBetween('purchase_request_date',[$fromDate,$toDate])->where('demand_type','=','2')->where('status','=','1')->where('purchase_request_status','=','2')->where('supplier_id','=',$selectSupplierId)->get();
        }else if($selectVoucherStatus == '3' && empty($selectSubDepartmentId) && !empty($selectSupplierId)){
            //return 'Twelve';
            $purchaseRequestSaleDetail = PurchaseRequest::whereBetween('purchase_request_date',[$fromDate,$toDate])->where('demand_type','=','2')->where('status','=','2')->where('supplier_id','=',$selectSupplierId)->get();
        }else if($selectVoucherStatus == '0' && !empty($selectSubDepartmentId) && !empty($selectSupplierId)){
            //return 'Thirteen';
            $purchaseRequestSaleDetail = PurchaseRequest::whereBetween('purchase_request_date',[$fromDate,$toDate])->where('demand_type','=','2')->where('supplier_id','=',$selectSupplierId)->where('sub_department_id','=',$selectSubDepartmentId)->get();
        }else if($selectVoucherStatus == '1' && !empty($selectSubDepartmentId) && !empty($selectSupplierId)){
            //return 'Fourteen';
            $purchaseRequestSaleDetail = PurchaseRequest::whereBetween('purchase_request_date',[$fromDate,$toDate])->where('demand_type','=','2')->where('status','=','1')->where('purchase_request_status','=','1')->where('supplier_id','=',$selectSupplierId)->where('sub_department_id','=',$selectSubDepartmentId)->get();
        }else if($selectVoucherStatus == '2' && !empty($selectSubDepartmentId) && !empty($selectSupplierId)){
            //return 'Fifteen';
            $purchaseRequestSaleDetail = PurchaseRequest::whereBetween('purchase_request_date',[$fromDate,$toDate])->where('demand_type','=','2')->where('status','=','1')->where('purchase_request_status','=','2')->where('supplier_id','=',$selectSupplierId)->where('sub_department_id','=',$selectSubDepartmentId)->get();
        }else if($selectVoucherStatus == '3' && !empty($selectSubDepartmentId) && !empty($selectSupplierId)){
            //return 'Sixteen';
            $purchaseRequestSaleDetail = PurchaseRequest::whereBetween('purchase_request_date',[$fromDate,$toDate])->where('demand_type','=','2')->where('status','=','2')->where('supplier_id','=',$selectSupplierId)->where('sub_department_id','=',$selectSubDepartmentId)->get();
        }
        CommonHelper::reconnectMasterDatabase();
        return view('Store.AjaxPages.filterPurchaseRequestSaleVoucherList',compact('purchaseRequestSaleDetail'));
    }

    public function viewPurchaseRequestVoucherDetail(){
        return view('Store.AjaxPages.viewPurchaseRequestVoucherDetail');
    }

    public function viewPurchaseRequestSaleVoucherDetail(){
        return view('Store.AjaxPages.viewPurchaseRequestSaleVoucherDetail');
    }

    public function filterApproveStoreChallanandCreateStoreChallanReturn(){
        return view('Store.AjaxPages.filterApproveStoreChallanandCreateStoreChallanReturn');
    }

    public function createStoreChallanReturnDetailForm(Request $request){
        return view('Store.createStoreChallanReturnDetailForm',compact('request'));
    }

    public function filterStoreChallanReturnList(){
        $fromDate = $_GET['fromDate'];
        $toDate = $_GET['toDate'];
        $m = $_GET['m'];
        $selectVoucherStatus = $_GET['selectVoucherStatus'];
        $selectSubDepartment = $_GET['selectSubDepartment'];
        $selectSubDepartmentId = $_GET['selectSubDepartmentId'];

        CommonHelper::companyDatabaseConnection($m);
        if($selectVoucherStatus == '0' && empty($selectSubDepartmentId)){
            $storeChallanReturnDetail = StoreChallanReturn::whereBetween('store_challan_return_date',[$fromDate,$toDate])->get();
        }else if($selectVoucherStatus == '0' && !empty($selectSubDepartmentId)){
            $storeChallanReturnDetail = StoreChallanReturn::whereBetween('store_challan_return_date',[$fromDate,$toDate])->whereIn('status', array(1, 2))->where('sub_department_id','=',$selectSubDepartmentId)->get();
        }else if($selectVoucherStatus == '1' && !empty($selectSubDepartmentId)){
            $storeChallanReturnDetail = StoreChallanReturn::whereBetween('store_challan_return_date',[$fromDate,$toDate])->where('status','=','1')->where('store_challan_return_status','=','1')->where('sub_department_id','=',$selectSubDepartmentId)->get();
        }else if($selectVoucherStatus == '2' && !empty($selectSubDepartmentId)){
            $storeChallanReturnDetail = StoreChallanReturn::whereBetween('store_challan_return_date',[$fromDate,$toDate])->where('status','=','1')->where('store_challan_return_status','=','2')->where('sub_department_id','=',$selectSubDepartmentId)->get();
        }else if($selectVoucherStatus == '3' && !empty($selectSubDepartmentId)){
            $storeChallanReturnDetail = StoreChallanReturn::whereBetween('store_challan_return_date',[$fromDate,$toDate])->where('status','=','2')->where('sub_department_id','=',$selectSubDepartmentId)->get();
        }else if($selectVoucherStatus == '1' && empty($selectSubDepartmentId)){
            $storeChallanReturnDetail = StoreChallanReturn::whereBetween('store_challan_return_date',[$fromDate,$toDate])->where('status','=','1')->where('store_challan_return_status','=','1')->get();
        }else if($selectVoucherStatus == '2' && empty($selectSubDepartmentId)){
            $storeChallanReturnDetail = StoreChallanReturn::whereBetween('store_challan_return_date',[$fromDate,$toDate])->where('status','=','1')->where('store_challan_return_status','=','2')->get();
        }else if($selectVoucherStatus == '3' && empty($selectSubDepartmentId)){
            $storeChallanReturnDetail = StoreChallanReturn::whereBetween('store_challan_return_date',[$fromDate,$toDate])->where('status','=','2')->get();
        }
        //$storeChallanReturnDetail = StoreChallanReturn::whereBetween('store_challan_return_date',[$fromDate,$toDate])->get();
        CommonHelper::reconnectMasterDatabase();
        //echo json_encode(array('data' => $storeChallanReturnDetail));
        return view('Store.AjaxPages.filterStoreChallanReturnList',compact('storeChallanReturnDetail'));
    }
    public function viewStoreChallanReturnDetail(){
        return view('Store.AjaxPages.viewStoreChallanReturnDetail');
    }

    public function filterViewDateWiseStockInventoryReport(){
        return view('Store.AjaxPages.filterViewDateWiseStockInventoryReport');
    }

    public function viewStockInventorySummaryDetail(){
        $m = $_GET['m'];
        $categoryIcId = $_GET['pOne'];
        $subIcId = $_GET['pTwo'];
        $filterDate = $_GET['pFour'];
        CommonHelper::companyDatabaseConnection($m);
        $itemOpeningQty = DB::table('fara')->where('main_ic_id','=',$categoryIcId)->where('sub_ic_id','=',$subIcId)->where('date','<=',$filterDate)->where('action','=',1)->first();
        $itemPurchaseData = DB::table('fara')->where('main_ic_id','=',$categoryIcId)->where('sub_ic_id','=',$subIcId)->where('date','<=',$filterDate)->where('action','=',3)->get();
        $itemStoreChallanData = DB::table('fara')->where('main_ic_id','=',$categoryIcId)->where('sub_ic_id','=',$subIcId)->where('date','<=',$filterDate)->where('action','=',2)->get();
        $itemStoreChallanReturnData = DB::table('fara')->where('main_ic_id','=',$categoryIcId)->where('sub_ic_id','=',$subIcId)->where('date','<=',$filterDate)->where('action','=',4)->get();
        $itemCashSaleData = DB::table('fara')->where('main_ic_id','=',$categoryIcId)->where('sub_ic_id','=',$subIcId)->where('date','<=',$filterDate)->where('action','=',5)->get();
        $itemCreditSaleData = DB::table('fara')->where('main_ic_id','=',$categoryIcId)->where('sub_ic_id','=',$subIcId)->where('date','<=',$filterDate)->where('action','=',6)->get();
        CommonHelper::reconnectMasterDatabase();
        return view('Store.AjaxPages.viewStockInventorySummaryDetail',compact('itemOpeningQty','itemPurchaseData','itemStoreChallanData','itemStoreChallanReturnData','itemCashSaleData','itemCreditSaleData'));
    }




}