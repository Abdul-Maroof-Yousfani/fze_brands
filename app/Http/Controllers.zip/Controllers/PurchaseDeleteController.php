<?php

namespace App\Http\Controllers;
//namespace App\Http\Controllers\Auth
//use Auth;
//use App\User;
use App\Http\Requests;
use Illuminate\Http\Request;
use DB;
use Config;
use Redirect;
use Session;
use App\Helpers\CommonHelper;
use App\Helpers\PurchaseHelper;
use Auth;
use App\Models\Account;
use App\Models\Transactions;
use App\Models\SubDepartment;

class PurchaseDeleteController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */



    public function approveCompanyPurchaseTwoTableRecords(){

        $m = $_GET['m'];
        CommonHelper::companyDatabaseConnection($m);
        $voucherStatus = $_GET['voucherStatus'];
        $rowStatus = $_GET['rowStatus'];
        $columnValue = $_GET['columnValue'];
        $columnOne = $_GET['columnOne'];
        $columnTwo = $_GET['columnTwo'];
        $columnThree = $_GET['columnThree'];
        $tableOne = $_GET['tableOne'];
        $tableTwo = $_GET['tableTwo'];


        $updateDetails = array(
            $columnTwo => 2,
            'approve_username' => Auth::user()->name
        );

        DB::table($tableOne)
            ->where($columnOne, $columnValue)
            ->update($updateDetails);

        DB::table($tableTwo)
            ->where($columnOne, $columnValue)
            ->update($updateDetails);


        CommonHelper::reconnectMasterDatabase();
        Session::flash('dataApprove','successfully approve.');

    }

    public function deleteCompanyPurchaseTwoTableRecords(){

        $m = $_GET['m'];
        CommonHelper::companyDatabaseConnection($m);
        $voucherStatus = $_GET['voucherStatus'];
        $rowStatus = $_GET['rowStatus'];
        $columnValue = $_GET['columnValue'];
        $columnOne = $_GET['columnOne'];
        $columnTwo = $_GET['columnTwo'];
        $columnThree = $_GET['columnThree'];
        $tableOne = $_GET['tableOne'];
        $tableTwo = $_GET['tableTwo'];


        $updateDetails = array(
            $columnThree => 2,
            'delete_username' => Auth::user()->name
        );

        DB::table($tableOne)
            ->where($columnOne, $columnValue)
            ->update($updateDetails);

        DB::table($tableTwo)
            ->where($columnOne, $columnValue)
            ->update($updateDetails);


        CommonHelper::reconnectMasterDatabase();
        Session::flash('dataDelete','successfully delete.');

    }

    public function repostCompanyPurchaseTwoTableRecords(){
        $m = $_GET['m'];
        CommonHelper::companyDatabaseConnection($m);
        $voucherStatus = $_GET['voucherStatus'];
        $rowStatus = $_GET['rowStatus'];
        $columnValue = $_GET['columnValue'];
        $columnOne = $_GET['columnOne'];
        $columnTwo = $_GET['columnTwo'];
        $columnThree = $_GET['columnThree'];
        $tableOne = $_GET['tableOne'];
        $tableTwo = $_GET['tableTwo'];


        $updateDetails = array(
            $columnThree => 1,
            'delete_username' => ''
        );

        DB::table($tableOne)
            ->where($columnOne, $columnValue)
            ->update($updateDetails);

        DB::table($tableTwo)
            ->where($columnOne, $columnValue)
            ->update($updateDetails);

        Session::flash('dataRepost','successfully repost.');
        CommonHelper::reconnectMasterDatabase();
    }

    public function approveCompanyPurchaseGoodsReceiptNote(){
        $m = $_GET['m'];
        CommonHelper::companyDatabaseConnection($m);
        $voucherStatus = $_GET['voucherStatus'];
        $rowStatus = $_GET['rowStatus'];
        $columnValue = $_GET['columnValue'];
        $columnOne = $_GET['columnOne'];
        $columnTwo = $_GET['columnTwo'];
        $columnThree = $_GET['columnThree'];
        $tableOne = $_GET['tableOne'];
        $tableTwo = $_GET['tableTwo'];


        $updateDetails = array(
            $columnTwo => 2,
            'approve_username' => Auth::user()->name
        );

        DB::table($tableOne)
            ->where($columnOne, $columnValue)
            ->update($updateDetails);

        DB::table($tableTwo)
            ->where($columnOne, $columnValue)
            ->update($updateDetails);

        $firstTableRecord = DB::table($tableOne)->where($columnOne, $columnValue)->where('status','=', '1')->first();
        $secondTableRecord = DB::table($tableTwo)->where($columnOne, $columnValue)->where('status','=', '1')->get();
        //return print($secondTableRecord);
        foreach ($secondTableRecord as $row){
            if($columnOne == 'grn_no'){
                $action = '3';
                $qty = $row->receivedQty;
                $value = $row->subTotal;
                $data['grn_no'] = $row->grn_no;
                $data['grn_date'] = $row->grn_date;
                $data['pr_no'] = $firstTableRecord->pr_no;
                $data['pr_date'] = $firstTableRecord->pr_date;
                $data['supp_id'] = $firstTableRecord->supplier_id;
                $tableThree = 'fara';

            }
            $data['main_ic_id'] = $row->category_id;
            $data['sub_ic_id'] = $row->sub_item_id;
            $data['main_ic_id'] = $row->category_id;
            $data['sub_ic_id'] = $row->sub_item_id;
            $data['demand_type'] = $row->demand_type;
            $data['demand_send_type'] = $row->demand_send_type;
            $data['qty'] = $qty;
            $data['value'] = $value;
            $data['action'] = $action;
            $data['status'] = 1;
            $data['username'] = Auth::user()->name;
            $data['date'] = date("Y-m-d");
            $data['time'] = date("H:i:s");
            $data['company_id'] = $m;
            DB::table($tableThree)->insert($data);
        }

        CommonHelper::reconnectMasterDatabase();
        Session::flash('dataApprove','successfully approve.');
    }

    public function deleteSubItemRecord(){

        /*
        $m = $_GET['companyId'];
        CommonHelper::companyDatabaseConnection($m);
        $id = $_GET['id'];
        $tableName = $_GET['tableName'];
        $accId = $_GET['accId'];

        $updateDetails = array(
            'status' => 2,
            'delete_username' => Auth::user()->name
        );

        DB::table('subitem')
            ->where('status', 1)
            ->where('id', $id)
            ->update($updateDetails);

        DB::table('accounts')
            ->where('id', $accId)
            ->where('status', 1)
            ->update($updateDetails);

        CommonHelper::reconnectMasterDatabase();
        Session::flash('dataDelete','successfully delete.');
        */

        $id= Input::get('id');

        $SubDepartment=new SubDepartment();
        $SubDepartment=$SubDepartment->setConnection('mysql2');
        $acc_id=$SubDepartment->where('id','=',$id)->select('acc_id')->first();
        echo $id;die;

        $SubDepartment->where('id','=',$id) ->delete();


        $accounts=new Account();
        $accounts=$accounts->setConnection('mysql2');
        $accounts->where('id','=',$id) ->delete();
        $transaction=new Transactions();
        $transaction=$transaction->setConnection('mysql2');
        $transaction->where('acc_id','=',$id)->delete();
    }

    public function repostSubItemRecord(){
        $m = $_GET['companyId'];
        CommonHelper::companyDatabaseConnection($m);
        $id = $_GET['id'];
        $tableName = $_GET['tableName'];
        $accId = $_GET['accId'];

        $updateDetails = array(
            'status' => 1,
            'delete_username' => Auth::user()->name
        );

        DB::table('subitem')
            ->where('status', 2)
            ->where('id', $id)
            ->update($updateDetails);

        DB::table('accounts')
            ->where('id', $accId)
            ->where('status', 2)
            ->update($updateDetails);

        CommonHelper::reconnectMasterDatabase();
        Session::flash('dataRepost','successfully repost.');
    }


    public function deleteCategoryRecord(){
        $m = $_GET['companyId'];
        CommonHelper::companyDatabaseConnection($m);
        $id = $_GET['id'];
        $tableName = $_GET['tableName'];
        $accId = $_GET['accId'];

        $updateDetails = array(
            'status' => 2,
            'delete_username' => Auth::user()->name
        );

        DB::table('category')
            ->where('status', 1)
            ->where('id', $id)
            ->update($updateDetails);

        DB::table('accounts')
            ->where('id', $accId)
            ->where('status', 1)
            ->update($updateDetails);

        CommonHelper::reconnectMasterDatabase();
        Session::flash('dataDelete','successfully delete.');
    }

    public function repostCategoryRecord(){
        $m = $_GET['companyId'];
        CommonHelper::companyDatabaseConnection($m);
        $id = $_GET['id'];
        $tableName = $_GET['tableName'];
        $accId = $_GET['accId'];

        $updateDetails = array(
            'status' => 1,
            'delete_username' => Auth::user()->name
        );

        DB::table('category')
            ->where('status', 2)
            ->where('id', $id)
            ->update($updateDetails);

        DB::table('accounts')
            ->where('id', $accId)
            ->where('status', 2)
            ->update($updateDetails);

        CommonHelper::reconnectMasterDatabase();
        Session::flash('dataRepost','successfully repost.');
    }




}
