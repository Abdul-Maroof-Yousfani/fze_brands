<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use App\Models\Employee;
use Illuminate\Http\Request;
use App\Models\MainMenuTitle;
use App\Models\Department;
use App\Models\MenuPrivileges;
use App\Helpers\CommonHelper;
use Input;
use Auth;
use DB;
use Config;

class UsersController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
   
   	public function toDayActivity(){
		return view('Users.toDayActivity');
   	}
	
	public function createUsersForm(){
		return view('Users.createUsersForm');
	}
	
	public function createMainMenuTitleForm(){
		return view('Users.createMainMenuTitleForm');
	}
	
	public function createSubMenuForm(){
		$MainMenuTitles = new MainMenuTitle;
		$MainMenuTitles = $MainMenuTitles::where('status', '=', '1')->get();
		return view('Users.createSubMenuForm',compact('MainMenuTitles'));
	}
	
	public function createRoleForm(){
        $departments = Department::where('company_id', '=', $_GET['m'])->orderBy('id')->get();
		return view('Users.createRoleForm',['departments'=>$departments]);
	}
	
	public function viewRoleList(){
		$MenuPrivileges = MenuPrivileges::all()->toArray(['id','user_id']);

        return view('Users.viewRoleList',['MenuPrivileges'=>$MenuPrivileges]);
	}

	public function viewEmployeePrivileges($id){


		$departments = Department::where('company_id', '=', $_GET['m'])->orderBy('id')->get();
		$MenuPrivileges = MenuPrivileges::find($id)->toArray();
		CommonHelper::companyDatabaseConnection(Input::get('m'));

		$employees =Employee::where('emp_department_id','=',$MenuPrivileges['department_id'])->get();
		CommonHelper::reconnectMasterDatabase();
		return view('Users.viewEmployeePrivileges',['MenuPrivileges'=>$MenuPrivileges,'departments'=>$departments,'employees'=>$employees]);

	}


}
