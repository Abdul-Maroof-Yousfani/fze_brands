<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use Illuminate\Http\Request;
use App\Helpers\CommonHelper;
use Auth;
use DB;
use Config;
use App\Models\Account;
use App\Models\PurchaseVoucher;
use App\Models\Countries;
use App\Models\Category;
use App\Models\Supplier;
use App\Models\Department;
use App\Models\PurchaseRequestData;
use App\Models\SupplierInfo;
use App\Models\FinanceDepartment;
use App\Models\CostCenter;
use App\Models\UOM;
use App\Models\PurchaseVoucherData;
use App\Models\DepartmentAllocation1;
use App\Models\DemandType;
use App\Models\Warehouse;

class PurchaseController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
   	public function toDayActivity(){
   		return view('Purchase.toDayActivity');
    }

    public function createSupplierForm(){
        $countries = new Countries;
        $countries = $countries::where('status', '=', 1)->get();
        CommonHelper::companyDatabaseConnection($_GET['m']);
        $accounts = new Account;
        $accounts = $accounts::orderBy('level1', 'ASC')
            ->orderBy('level2', 'ASC')
            ->orderBy('level3', 'ASC')
            ->orderBy('level4', 'ASC')
            ->orderBy('level5', 'ASC')
            ->orderBy('level6', 'ASC')
            ->orderBy('level7', 'ASC')
            ->where('status',1)
            ->get();
        return view('Purchase.createSupplierForm',compact('accounts','countries'));
    }

    public function viewSupplierList(){
        return view('Purchase.viewSupplierList');
    }
    public function createPurchaseVoucherForm()

    {
        $supplier=new Supplier();
        $supplier=$supplier->SetConnection('mysql2');
        $supplier=$supplier->where('status',1)->select('id','name')->get();
        $department=new FinanceDepartment();
        $department=$department->SetConnection('mysql2');
        $department=$department->where('status',1)->select('id','name','code')
                ->orderBy('level1', 'ASC')
                ->orderBy('level2', 'ASC')
                ->orderBy('level3', 'ASC')
                ->orderBy('level4', 'ASC')
                ->orderBy('level5', 'ASC')
                ->get();


        return view('Purchase.createPurchaseVoucherForm',compact('supplier','department'));
    }
    public function editSupplierForm(){
        $countries = new Countries;
        $countries = $countries::where('status', '=', 1)->get();
        CommonHelper::companyDatabaseConnection($_GET['m']);
       // $accounts = new Account;
      //  $accounts = $accounts::orderBy('level1', 'ASC')
        //    ->orderBy('level2', 'ASC')
        //    ->orderBy('level3', 'ASC')
         //   ->orderBy('level4', 'ASC')
         //   ->orderBy('level5', 'ASC')
         //   ->orderBy('level6', 'ASC')
          //  ->orderBy('level7', 'ASC')
          //  ->where('parent_code','like','2-1%')
          //  ->get();
        return view('Purchase.AjaxPages.editSupplierForm',compact('countries'));
    }

    public function viewSupplierDetail(){
        return view('Purchase.AjaxPages.viewSupplierDetail');
    }

    public function createCategoryForm(){
        CommonHelper::companyDatabaseConnection($_GET['m']);
        $accounts = new Account;
        $accounts = $accounts::orderBy('level1', 'ASC')
            ->orderBy('level2', 'ASC')
            ->orderBy('level3', 'ASC')
            ->orderBy('level4', 'ASC')
            ->orderBy('level5', 'ASC')
            ->orderBy('level6', 'ASC')
            ->orderBy('level7', 'ASC')
            
            ->get();
        return view('Purchase.createCategoryForm',compact('accounts'));
    }

    public function viewCategoryList(){
        return view('Purchase.viewCategoryList');
    }

    public function viewCategoryDetail(){
        return view('Purchase.AjaxPages.viewCategoryDetail');
    }

    public function editCategoryForm(){
        CommonHelper::companyDatabaseConnection($_GET['m']);
        $accounts = new Account;
        $accounts = $accounts::orderBy('level1', 'ASC')
            ->orderBy('level2', 'ASC')
            ->orderBy('level3', 'ASC')
            ->orderBy('level4', 'ASC')
            ->orderBy('level5', 'ASC')
            ->orderBy('level6', 'ASC')
            ->orderBy('level7', 'ASC')
            ->where('code','=','1-2')
            ->get();
        return view('Purchase.AjaxPages.editCategoryForm',compact('accounts'));
    }

    public function editPurchaseVoucherForm($id)

    {

        $supplier=new Supplier();
        $supplier=$supplier->SetConnection('mysql2');
        $supplier=$supplier->where('status',1)->select('id','name')->get();
        $department=new FinanceDepartment();
        $department=$department->SetConnection('mysql2');
        $department=$department->where('status',1)->select('id','name','code')
            ->orderBy('level1', 'ASC')
            ->orderBy('level2', 'ASC')
            ->orderBy('level3', 'ASC')
            ->orderBy('level4', 'ASC')
            ->orderBy('level5', 'ASC')
            ->get();


        $purchase_voucher=new PurchaseVoucher();
        $purchase_voucher=$purchase_voucher->SetConnection('mysql2');
        $purchase_voucher=$purchase_voucher->where('id',$id)->select('pv_no','pv_date','slip_no','purchase_date','purchase_type'
            ,'due_date','supplier','description','currency','total_net_amount','amount_in_words')->first();


        $purchase_voucher_data=new PurchaseVoucherData();
        $purchase_voucher_data=$purchase_voucher_data->SetConnection('mysql2');
        $purchase_voucher_data=$purchase_voucher_data->where('master_id',$id)->select('id','pv_no','category_id','sub_item','uom','qty'
            ,'rate','amount','sales_tax_per','sales_tax_amount','net_amount')->orderBy('id','ASC')->get();


        return view('Purchase.editPurchaseVoucherForm',compact('supplier','department','purchase_voucher','id','purchase_voucher_data'));
    }

    public function createSubItemForm(){
        $uom = new UOM;
        $uom = $uom::where('status','=','1')->get();
   	    CommonHelper::companyDatabaseConnection($_GET['m']);
        $categories = new Category;
        $categories = $categories::where('status','=','1')->get();

        return view('Purchase.createSubItemForm',compact('categories','uom'));
    }

    public function viewSubItemList(){
        return view('Purchase.viewSubItemList');
    }

    public function viewSubItemDetail(){
        return view('Purchase.AjaxPages.viewSubItemDetail');
    }

    public function editSubItemForm(){
        $uom = new UOM;
        $uom = $uom::where('status','=','1')->get();
        CommonHelper::companyDatabaseConnection($_GET['m']);
        $categories = new Category;
        $categories = $categories::where('status','=','1')->get();
        return view('Purchase.AjaxPages.editSubItemForm',compact('categories','uom'));
    }

    public function createUOMForm(){
        return view('Purchase.createUOMForm');
    }

    public function viewUOMList(){
        return view('Purchase.viewUOMList');
    }

    public function createDemandForm(){
        $departments = new Department;
        $departments = $departments::where([['company_id', '=', $_GET['m']], ['status', '=', '1'], ])->select('id','department_name')->orderBy('id')->get();
        return view('Purchase.createDemandForm',compact('departments'));
    }

    public function viewDemandList(){
        return view('Purchase.viewDemandList');
    }

    public function editDemandVoucherForm(){
        $departments = new Department;
        $departments = $departments::where([['company_id', '=', $_GET['m']], ['status', '=', '1'], ])->orderBy('id')->get();
        return view('Purchase.editDemandVoucherForm',compact('departments'));
    }

    public function createGoodsReceiptNoteForm(){
        CommonHelper::companyDatabaseConnection($_GET['m']);
        $PurchaseRequestData = new PurchaseRequestData;
        $PurchaseRequestDatas = $PurchaseRequestData::distinct()->where('grn_status','=','1')->where('purchase_request_status','=','2')->get(['purchase_request_no','purchase_request_date']);
        return view('Purchase.createGoodsReceiptNoteForm',compact('PurchaseRequestDatas'));
    }

    public function viewGoodsReceiptNoteList(){
        return view('Purchase.viewGoodsReceiptNoteList');
    }



    public function editGoodsReceiptNoteVoucherForm(){
        CommonHelper::companyDatabaseConnection($_GET['m']);
        //$PurchaseRequestData = new PurchaseRequestData;
        //$PurchaseRequestDatas = $PurchaseRequestData::distinct()->where('grn_status','=','1')->get(['purchase_request_no','purchase_request_date']);
        return view('Purchase.editGoodsReceiptNoteVoucherForm');
    }

    public function createGoodsForwardOrderForm(){
        return view('Purchase.createGoodsForwardOrderForm');
    }

    public function viewGoodsForwardOrderList(){
        return view('Purchase.viewGoodsForwardOrderList');
    }


    public function viewPurchaseVoucherList(){


        $purchase_voucher=new PurchaseVoucher();
        $purchase_voucher=$purchase_voucher->SetConnection('mysql2');
        $purchase_voucher=$purchase_voucher->where('status',1)->select('id','pv_no','pv_date','supplier','slip_no','bill_date','total_net_amount')->orderBy('pv_date','ASC')->

        get();

        return view('Purchase.viewPurchaseVoucherList',compact('purchase_voucher'));

    }

public function createDemandTypeForm(){
        return view('Purchase.createDemandTypeForm');
    }


    public function createWarehouseForm(){
        return view('Purchase.createWarehouseForm');
    }
 public function viewDemandTypeList(){

        $demand_type=new DemandType();
        $demand_type=$demand_type->SetConnection('mysql2');
        $demand_type=$demand_type->where('status',1)->select('name')->get();

        return view('Purchase.viewDemandTypeList',compact('demand_type'));
    }
    public function viewWarehouseList(){

        $warehouse=new Warehouse();
        $warehouse=$warehouse->SetConnection('mysql2');
        $warehouse=$warehouse->where('status',1)->select('name')->get();

        return view('Purchase.viewWarehouseList',compact('warehouse'));
    }
}
