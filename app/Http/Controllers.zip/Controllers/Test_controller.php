<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Helpers\CommonHelper;
use App\Helpers\HrHelper;
use App\Http\Requests;
use App\Models\Job;
use App\Models\RequestHiring;
use App\Models\FamilyStatus;
use App\Models\EmployeeHistoryVerification;
use App\Models\EmployeeExitClearance;
use App\Models\EmployeeExitInterview;
use App\Models\Employee;
use App\Models\Designation;
use App\Models\Department;
use App\Models\EmployeeProbationaryPeriod;
use App\Models\QuizTest;

use Input;
use Auth;
use DB;
use Config;
use Session;
class Test_controller extends Controller
{


    public function index()
    {
        return view('Visitor.visitorDashboard');
    }

    public function careers()
    {

        return view('Visitor.careers');
    }

    public function ViewandApplyDetail($companyId, $recordId)
    {

        CommonHelper::companyDatabaseConnection($companyId);
        $hiringRequestDetail = RequestHiring::where([['id', '=', $recordId]])->first();
        CommonHelper::reconnectMasterDatabase();
        return view('Visitor.ViewandApplyDetail', compact('hiringRequestDetail'));

    }

    public function ThankyouForApply()
    {
        if (session('key_message') != '') {
            session()->put('key_message', '');

            return view('Visitor.ThankyouForApply');
        } else {
            return view('Visitor.visitorDashboard');
        }
    }


    function addEmployeeFamilyStatusDetail(Request $request)
    {

        $id = $request->emp_id;
        $family_status = new FamilyStatus();
        $family_status = $family_status->SetConnection('mysql2');
        $family_status = $family_status->where('status', 1)->where('emp_id', $id);
        if ($family_status->count() > 0):

            $family_status->delete();
        endif;

        $martarial_status = $request->optradio;
        if ($martarial_status == 1):
            $count = count($request->name) - 1;
            for ($i = 0; $i <= $count; $i++):
                $family_status = new FamilyStatus();
                $family_status = $family_status->SetConnection('mysql2');
                $family_status->marital_status_id = $martarial_status;
                $family_status->emp_id = $request->emp_id;
                $family_status->name = $request->name[$i];
                $family_status->gender = $request->gender[$i];
                $family_status->relation = $request->relation[$i];
                $family_status->dob = $request->dob[$i];
                $family_status->date = date('Y-m-d');
                $family_status->username = Auth::user()->name;
                $family_status->save();
            endfor;

        else:
            $family_status = new FamilyStatus();
            $family_status = $family_status->SetConnection('mysql2');
            $family_status->marital_status_id = $martarial_status;
            $family_status->emp_id = $request->emp_id;
            $family_status->date = date('Y-m-d');
            $family_status->username = Auth::user()->name;
            $family_status->save();

        endif;

        Session::flash('dataInsert', 'successfully saved.');
        return redirect('hr/createEmployeeFamilyStatus?pageType=add&&parentCode=27&&m=1#SFR');

    }


    function addEmployeeHistoryVerification(Request $request)
    {

        $idd = $request->emp_id;
        $history_varification = new EmployeeHistoryVerification();
        $history_varification = $history_varification->SetConnection('mysql2');
        $history_varification->emp_id = $request->emp_id;
        $history_varification->quality_work = $request->quality_work;
        $history_varification->quantity_work = $request->quantity_work;
        $history_varification->attendance = $request->attendance;

        $history_varification->behavior = $request->behavior;
        $history_varification->leave_reson = $request->leave_reson;
        $history_varification->eligible = $request->eligible;
        $history_varification->eligible_reason = $request->eligible_reason;

        $history_varification->additional_comments = $request->additional_comments;
        $history_varification->inform_from = $request->inform_from;
        $history_varification->position_titke = $request->position_titke;
        $history_varification->username = Auth::user()->name;
        $history_varification->date = date('Y-m-d');
        $history_varification->save();
        Session::flash('dataInsert', 'successfully saved.');
        return redirect('hr/createEmployeeHistoryVerification?pageType=add&&parentCode=27&&m=1#SFR');
    }

    function editEmployeeHistoryVerification(Request $request,$id)
    {


        $history_varification = new EmployeeHistoryVerification();
        $history_varification = $history_varification->SetConnection('mysql2');
        $history_varification =$history_varification->find($id);
        $history_varification->emp_id = $id;
        $history_varification->quality_work = $request->quality_work;
        $history_varification->quantity_work = $request->quantity_work;
        $history_varification->attendance = $request->attendance;

        $history_varification->behavior = $request->behavior;
        $history_varification->leave_reson = $request->leave_reson;
        $history_varification->eligible = $request->eligible;
        $history_varification->eligible_reason = $request->eligible_reason;

        $history_varification->additional_comments = $request->additional_comments;
        $history_varification->inform_from = $request->inform_from;
        $history_varification->position_titke = $request->position_titke;
        $history_varification->username = Auth::user()->name;
        $history_varification->date = date('Y-m-d');
        $history_varification->save();
        Session::flash('dataInsert', 'successfully saved.');
        return redirect('hr/createEmployeeHistoryVerification?pageType=add&&parentCode=27&&m=1#SFR');
    }


    function addEmployeeExitClearanceDetail(Request $request)
    {

        $employe_exit_clearance=new EmployeeExitClearance();
        $employe_exit_clearance=$employe_exit_clearance->SetConnection('mysql2');
        $save_update=$request->save_update;
        if ($save_update==1):
            $id=$request->emp_id;
            $employe_exit_clearance =$employe_exit_clearance->find($id);
        endif;
        $employe_exit_clearance->emp_id=$request->emp_id;
        $employe_exit_clearance->issue_date= $request->issue_date;
        $employe_exit_clearance->dos=$request->dos;
        $employe_exit_clearance->leaving_type= $request->leaving_type;
        $employe_exit_clearance->relieved_duties=$request->relieved_duties;
        $employe_exit_clearance->item_returned=$request->item_returned;
        $employe_exit_clearance->transaction_completed_concern=$request->transaction_completed_concern;
        $employe_exit_clearance->relieved_duties_remarks=$request->relieved_duties_remarks;
        $employe_exit_clearance->item_returned_remarks=$request->item_returned_remarks;
        $employe_exit_clearance->transaction_completed_remarks_concern=$request->transaction_completed_remarks_concern;
        $employe_exit_clearance->working_condition=$request->working_condition;
        $employe_exit_clearance->email_account_closed=$request->email_account_closed;
        $employe_exit_clearance->transaction_completed_it=$request->transaction_completed_it;
        $employe_exit_clearance->working_condition_remarks=$request->working_condition_remarks;
        $employe_exit_clearance->email_account_closed_remarks=$request->email_account_closed_remarks;
        $employe_exit_clearance->transaction_completed_it_remarks=$request->transaction_completed_it_remarks;
        $employe_exit_clearance->salary_adjusted=$request->salary_adjusted;
        $employe_exit_clearance->Loan_settled=$request->Loan_settled;
        $employe_exit_clearance->transaction_completed_finance=$request->transaction_completed_finance;
        $employe_exit_clearance->salary_adjusted_remarks=$request->salary_adjusted_remarks;
        $employe_exit_clearance->Loan_settled_remarks=$request->Loan_settled_remarks;
        $employe_exit_clearance->transaction_completed_finance_remarks=$request->transaction_completed_finance_remarks;
        $employe_exit_clearance->office_material=$request->office_material;
        $employe_exit_clearance->received_company_assets=$request->received_company_assets;
        $employe_exit_clearance->transaction_completed_administration= $request->transaction_completed_administration;
        $employe_exit_clearance->office_material_remarks=$request->office_material_remarks;
        $employe_exit_clearance->received_company_assets_remarks=$request->received_company_assets_remarks;
        $employe_exit_clearance->transaction_completed_administration_remarks=$request->transaction_completed_administration_remarks;
        $employe_exit_clearance->office_card=$request->office_card;
        $employe_exit_clearance->balance_leav_annual=$request->balance_leav_annual;
        $employe_exit_clearance->balance_leav_casual=$request->balance_leav_casual;
        $employe_exit_clearance->balance_leav_sick=$request->balance_leav_sick;
        $employe_exit_clearance->transaction_completed_hr=$request->transaction_completed_hr;
        $employe_exit_clearance->office_card_remarks=$request->office_card_remarks;
        $employe_exit_clearance->balance_leav_remarks=$request->balance_leav_remarks;
        $employe_exit_clearance->transaction_completed_hr_remarks=$request->transaction_completed_hr_remarks;
        $employe_exit_clearance->username=Auth::user()->name;
        $employe_exit_clearance->date=date('Y-m-d');
        $employe_exit_clearance->save();
        Session::flash('dataInsert', 'successfully saved.');
        return redirect('hr/createEmployeeExitClearanceForm?pageType=add&&parentCode=73&&m=1#SFR');

    }

    //it will move HrDataCall
    function  viewEmployeeDataExitInterview($id='')
    {
        $id = Input::get('emp_val');
        $employe=new Employee();
        $employe=$employe->SetConnection('mysql2');
        $employe=$employe->where('status',1)->where('id',$id)->first(['designation_id','emp_department_id','emp_joining_date']);
        $designation=new Designation();
        $designation=$designation->where('status',1)->where('id',$employe->designation_id)->select('designation_name')->first();
        $department=new Department();
        $department=$department->where('status',1)->where('id',$employe->emp_department_id)->first(['department_name']);
        //  echo $designation['designation_name'].'*'.$department['department_name'].'*'.$employe->emp_joining_date;
        $designation=$designation['designation_name'];
        $department=$department['department_name'];
        $joining_date =$employe->emp_joining_date;

        $employe_exit_interview=new EmployeeExitInterview();
        $employe_exit=$employe_exit_interview->SetConnection('mysql2');
        $exit_interview_data=$employe_exit_interview->where('status',1)->where('emp_id',$id);
        $count=$exit_interview_data->count();
        $exit_interview_employe_data=$exit_interview_data->first();




        $employee = $employe->where('status', 1)->get(['emp_name', 'id']);
        return view('Hr.AjaxPages.viewEmployeeExitInterview', compact('employee','count','exit_interview_employe_data','designation','department','joining_date','id'));

    }


    function  viewEmployeeDataProbationaryPeriod($id='')
    {
        $id = Input::get('emp_val');
        $employe=new Employee();
        $employe=$employe->SetConnection('mysql2');
        $employe=$employe->where('status',1)->where('id',$id)->first(['designation_id','emp_department_id','emp_joining_date']);
        $designation=new Designation();
        $designation=$designation->where('status',1)->where('id',$employe->designation_id)->select('designation_name')->first();
        $department=new Department();
        $department=$department->where('status',1)->where('id',$employe->emp_department_id)->first(['department_name']);
        //  echo $designation['designation_name'].'*'.$department['department_name'].'*'.$employe->emp_joining_date;
        $designation=$designation['designation_name'];
        $department=$department['department_name'];
        $joining_date =$employe->emp_joining_date;

        $employe_probationary_period=new EmployeeProbationaryPeriod();
        $employe_probationary_period=$employe_probationary_period->SetConnection('mysql2');
        $employe_probationary_period=$employe_probationary_period->where('status',1)->where('emp_id',$id);
        $count=$employe_probationary_period->count();
        $employe_probationary_period=$employe_probationary_period->first();




        $employee = $employe->where('status', 1)->get(['emp_name', 'id']);
        return view('Hr.AjaxPages.viewEmployeeprobationaryPeriod', compact('employee','count','employe_probationary_period','designation','department','joining_date','id'));

    }

    function addEmployeeExitInterviewDetail(Request $request)
    {

        $employe_exit_interview=new EmployeeExitInterview();
        $employe_exit_interview=$employe_exit_interview->SetConnection('mysql2');
        $id=$request->emp_id;
        $save_update=$request->save_update;
        if ($save_update==1):
            $id=$request->emp_id;
            $employe_exit_interview =$employe_exit_interview->find($id);
        endif;
        $employe_exit_interview->emp_id=$request->emp_id;
        $employe_exit_interview->reporting_to= $request->reporting_to;
        $employe_exit_interview->dos=$request->dos;
        $employe_exit_interview->reason_for_leaving= $request->reason_for_leaving;
        $employe_exit_interview->future_plane=$request->future_plane;
        $employe_exit_interview->work_content=$request->work_content;
        $employe_exit_interview->working_method=$request->working_method;
        $employe_exit_interview->quality_supervison=$request->quality_supervison;
        $employe_exit_interview->level_of_empowerment=$request->level_of_empowerment;
        $employe_exit_interview->hr_policies_procedures=$request->hr_policies_procedures;
        $employe_exit_interview->attitude_of_supervisor=$request->attitude_of_supervisor;
        $employe_exit_interview->behavior_colleagues=$request->behavior_colleagues;
        $employe_exit_interview->peertunity_for_training_development=$request->peertunity_for_training_development;
        $employe_exit_interview->remuneration=$request->remuneration;
        $employe_exit_interview->growth_oppertunities=$request->growth_oppertunities;
        $employe_exit_interview->satisfied_with_point1=$request->satisfied_with_point1;
        $employe_exit_interview->satisfied_with_point2=$request->satisfied_with_point2;
        $employe_exit_interview->satisfied_with_point3=$request->satisfied_with_point3;
        $employe_exit_interview->unsatisfied_with_point1=$request->unsatisfied_with_point1;
        $employe_exit_interview->unsatisfied_with_point2=$request->unsatisfied_with_point2;
        $employe_exit_interview->unsatisfied_with_point3=$request->unsatisfied_with_point3;
        $employe_exit_interview->suggestion=$request->suggestion;
        $employe_exit_interview->hr_representative_remarks=$request->hr_representative_remarks;
        $employe_exit_interview->hr_head_representative_remarks=$request->hr_head_representative_remarks;
        $employe_exit_interview->username=Auth::user()->name;
        $employe_exit_interview->date=date('Y-m-d');
        $employe_exit_interview->save();
        Session::flash('dataInsert', 'successfully saved.');
        return redirect('hr/createEmployeeExitInterviewForm?pageType=add&&parentCode=73&&m=1#SFR');
    }


    function addEmployeeProbationaryPeriodDetail(Request $request)
    {
        $employe_probationary=new EmployeeProbationaryPeriod();
        $employe_probationary=$employe_probationary->SetConnection('mysql2');
        $id=$request->emp_id;
        $save_update=$request->save_update;
        if ($save_update==1):
            $id=$request->emp_id;
            $employe_probationary =$employe_probationary->find($id);
        endif;
        $employe_probationary->emp_id=$request->emp_id;
        $employe_probationary->location= $request->location;
        $employe_probationary->immidaite_supervisor=$request->immidaite_supervisor;
        $employe_probationary->job_knowledge= $request->job_knowledge;
        $employe_probationary->meet_requirements=$request->meet_requirements;
        $employe_probationary->quality_work=$request->quality_work;
        $employe_probationary->quantiry_work=$request->quantiry_work;
        $employe_probationary->initiative=$request->initiative;
        $employe_probationary->dependability=$request->dependability;
        $employe_probationary->conduct=$request->conduct;
        $employe_probationary->tradiness=$request->tradiness;
        $employe_probationary->attendance=$request->attendance;
        $employe_probationary->cooperation=$request->cooperation;
        $employe_probationary->satisfaction=$request->satisfaction;
        $employe_probationary->supervisor_recommendation=$request->supervisor_recommendation;
        $employe_probationary->supervisor_comments=$request->supervisor_comments;
        $employe_probationary->dept_head_comments=$request->dept_head_comments;
        $employe_probationary->hr_comments=$request->hr_comments;
        $employe_probationary->md_comments=$request->md_comments;
        $employe_probationary->username=Auth::user()->name;
        $employe_probationary->date=date('Y-m-d');
        $employe_probationary->save();
        Session::flash('dataInsert', 'successfully saved.');
        return redirect('hr/createEmployeeProbationaryPeriod?pageType=add&&parentCode=75&&m=1#SFR');
    }


    function  viewEmployeeDataQuizTest()
    {
        $email = Input::get('email');
        $number = Input::get('number');
        $employe=new Employee();
        $employe=$employe->SetConnection('mysql2');
        $employe=$employe->where('status',1)->where('emp_email',$email)->where('emp_contact_no',$number);
        if ($employe->count() > 0):
            $employe=    $employe->first(['id']);
            echo $employe->id;

        else:
            echo 0;
        endif;

    }


    function  addEmployeeQuizTest(Request $request)
    {

        $quiztest=new QuizTest();
        $quiztest=$quiztest->SetConnection('mysql2');
        $count=$quiztest->where('status',1)->where('emp_id',$request->emp_id)->count();
        if ($count==0):
        $quiztest->emp_id=$request->emp_id;
        $quiztest->emp_answer=$request->question1.','.$request->question2.','.$request->question3.','.$request->question4.','.$request->question5.','.
            $request->question6.','.$request->question7.','.$request->question8.','.$request->question9.','.$request->question10.','.
            $request->question11.','.$request->question12.','.$request->question13.','.$request->question14.','.$request->question15;
        $quiztest->date=date('Y-m-d');
        $quiztest->save();
        return view('Visitor.ThankyouForApply', compact(''));
        else:
            echo '<h3>This User Already Inserted</h3>';
         endif;
  //   return redirect('visitor/viewQuizTestResult/'.$request->emp_id);
      //  return redirect()->action(


    }

    function testcsvFrom()
    {

        return view('test');
    }
    function addcsvDetail()
    {


        $fileName = $_FILES["file"]["tmp_name"];

        if ($_FILES["file"]["size"] > 0) {

            $file = fopen($fileName, "r");

            while (($column = fgetcsv($file, 10000, ",")) !== FALSE) {

                $employeeAttendance['col1'] = $column[0];
                $employeeAttendance['col2'] = $column[1];
                $employeeAttendance['col3'] = $column[2];
                $employeeAttendance['col4'] = $column[3];
                $employeeAttendance['col5'] = $column[4];

                $result = DB::table('test')->insert($employeeAttendance);

                if (! empty($result)) {
                    $type = "success";
                    $message = "CSV Data Imported into the Database";
                } else {
                    $type = "error";
                    $message = "Problem in Importing CSV Data";
                }
            }
        }

    }

    function orm_test()
    {
        CommonHelper::companyDatabaseConnection(1);
        echo "<pre>";
        $aa = Employee::select('emp_name','username')->where([['id',136]])->with('bonus_issue')->get();
        print_r($aa);


    }
}
