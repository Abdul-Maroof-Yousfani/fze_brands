<?php

namespace App\Http\Controllers;
use Illuminate\Database\DatabaseManager;
use App\Http\Requests;
use App\Helpers\FinanceHelper;
use App\Helpers\CommonHelper;
use App\Models\LeavesData;
use App\Models\LeavesPolicy;
use App\Models\EmployeeRequisition;
use Illuminate\Http\Request;

use Input;
use Auth;
use DB;
use Config;
use Redirect;
use Session;
use Hash;
use Helpers;
class HrEditDetailControler extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
		
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
   
   	public function editDepartmentDetail(){
		$departmentSection = Input::get('departmentSection');
		foreach($departmentSection as $row){
			$department_name = Input::get('department_name_'.$row.'');
			$department_id = Input::get('department_id_'.$row.'');
			$data1['department_name'] =	strip_tags($department_name);
        	$data1['username'] 		  = Auth::user()->name;
        	$data1['company_id'] 	  	  = $_GET['m'];
        	$data1['date']     		  = date("Y-m-d");
        	$data1['time']     		  = date("H:i:s");
        
			DB::table('department')->where('id', $department_id)->update($data1);	
		}
        Session::flash('dataEdit','successfully edit.');
		return Redirect::to('hr/viewDepartmentList?pageType='.Input::get('pageType').'&&parentCode='.Input::get('parentCode').'&&m='.$_GET['m'].'#SFR');
	}


    public function editSubDepartmentDetail(){
        $subDepartmentSection = Input::get('subDepartmentSection');
        foreach($subDepartmentSection as $row){
            $department_id                  = Input::get('department_id_'.$row.'');
            $sub_department_name            = Input::get('sub_department_name_'.$row.'');
            $sub_department_id              = Input::get('sub_department_id_'.$row.'');
            $data1['department_id']         =   strip_tags($department_id);
            $data1['sub_department_name']   =   strip_tags($sub_department_name);
            $data1['username']              = Auth::user()->name;
            $data1['company_id']            = $_GET['m'];
            $data1['date']                  = date("Y-m-d");
            $data1['time']                  = date("H:i:s");
        
            DB::table('sub_department')->where('id', $sub_department_id)->update($data1);    
        }
        Session::flash('dataEdit','successfully edit.');
        return Redirect::to('hr/viewSubDepartmentList?pageType='.Input::get('pageType').'&&parentCode='.Input::get('parentCode').'&&m='.$_GET['m'].'#SFR');
    }

    public function editDesignationDetail(){
        $designationSection = Input::get('designationSection');
        foreach($designationSection as $row){
            $designation_name = Input::get('designation_name_'.$row.'');
            $designation_id = Input::get('designation_id_'.$row.'');
            $data1['designation_name'] = strip_tags($designation_name);
            $data1['username']        = Auth::user()->name;
            $data1['company_id']          = $_GET['m'];
            $data1['date']            = date("Y-m-d");
            $data1['time']            = date("H:i:s");
        
            DB::table('designation')->where('id', $designation_id)->update($data1);   
        }
        Session::flash('dataEdit','successfully edit.');
        return Redirect::to('hr/viewDesignationList?pageType='.Input::get('pageType').'&&parentCode='.Input::get('parentCode').'&&m='.$_GET['m'].'#SFR');
    }

    public function editHealthInsuranceDetail(){
        $healthInsuranceSection = Input::get('healthInsuranceSection');
        foreach($healthInsuranceSection as $row){
            $health_insurance_name = Input::get('health_insurance_name_'.$row.'');
            $health_insurance_id = Input::get('health_insurance_id_'.$row.'');
            $data1['health_insurance_name'] = strip_tags($health_insurance_name);
            $data1['username']        = Auth::user()->name;
            $data1['company_id']          = $_GET['m'];
            $data1['date']            = date("Y-m-d");
            $data1['time']            = date("H:i:s");
        
            DB::table('health_insurance')->where('id', $health_insurance_id)->update($data1);   
        }
        Session::flash('dataEdit','successfully edit.');
        return Redirect::to('hr/viewHealthInsuranceList?pageType='.Input::get('pageType').'&&parentCode='.Input::get('parentCode').'&&m='.$_GET['m'].'#SFR');
    }

    public function editLifeInsuranceDetail(){
        $lifeInsuranceSection = Input::get('lifeInsuranceSection');
        foreach($lifeInsuranceSection as $row){
            $life_insurance_name = Input::get('life_insurance_name_'.$row.'');
            $life_insurance_id = Input::get('life_insurance_id_'.$row.'');
            $data1['life_insurance_name'] = strip_tags($life_insurance_name);
            $data1['username']        = Auth::user()->name;
            $data1['company_id']          = $_GET['m'];
            $data1['date']            = date("Y-m-d");
            $data1['time']            = date("H:i:s");
        
            DB::table('life_insurance')->where('id', $life_insurance_id)->update($data1);   
        }
        Session::flash('dataEdit','successfully edit.');
        return Redirect::to('hr/viewLifeInsuranceList?pageType='.Input::get('pageType').'&&parentCode='.Input::get('parentCode').'&&m='.$_GET['m'].'#SFR');
    }

    public function editJobTypeDetail(){
        $jobTypeSection = Input::get('jobTypeSection');
        foreach($jobTypeSection as $row){
            $job_type_name = Input::get('job_type_name_'.$row.'');
            $job_type_id = Input::get('job_type_id_'.$row.'');
            $data1['job_type_name'] = strip_tags($job_type_name);
            $data1['username']        = Auth::user()->name;
            $data1['company_id']          = $_GET['m'];
            $data1['date']            = date("Y-m-d");
            $data1['time']            = date("H:i:s");
        
            DB::table('job_type')->where('id', $job_type_id)->update($data1);   
        }
        Session::flash('dataEdit','successfully edit.');
        return Redirect::to('hr/viewJobTypeList?pageType='.Input::get('pageType').'&&parentCode='.Input::get('parentCode').'&&m='.$_GET['m'].'#SFR');
    }

    public function editShiftTypeDetail(){
        $shiftTypeSection = Input::get('shiftTypeSection');
        foreach($shiftTypeSection as $row){
            $shift_type_name = Input::get('shift_type_name_'.$row.'');
            $shift_type_id = Input::get('shift_type_id_'.$row.'');
            $data1['shift_type_name'] = strip_tags($shift_type_name);
            $data1['username']        = Auth::user()->name;
            $data1['company_id']          = $_GET['m'];
            $data1['date']            = date("Y-m-d");
            $data1['time']            = date("H:i:s");
        
            DB::table('shift_type')->where('id', $shift_type_id)->update($data1);   
        }
        Session::flash('dataEdit','successfully edit.');
        return Redirect::to('hr/viewShiftTypeList?pageType='.Input::get('pageType').'&&parentCode='.Input::get('parentCode').'&&m='.$_GET['m'].'#SFR');
    }

    public function editAdvanceTypeDetail(){
        $advanceTypeSection = Input::get('advanceTypeSection');
        foreach($advanceTypeSection as $row){
            $advance_type_name = Input::get('advance_type_name_'.$row.'');
            $advance_type_id = Input::get('advance_type_id_'.$row.'');
            $data1['advance_type_name'] = strip_tags($advance_type_name);
            $data1['username']        = Auth::user()->name;
            $data1['company_id']          = $_GET['m'];
            $data1['date']            = date("Y-m-d");
            $data1['time']            = date("H:i:s");
        
            DB::table('advance_type')->where('id', $advance_type_id)->update($data1);   
        }
        Session::flash('dataEdit','successfully edit.');
        return Redirect::to('hr/viewAdvanceTypeList?pageType='.Input::get('pageType').'&&parentCode='.Input::get('parentCode').'&&m='.$_GET['m'].'#SFR');
    }

    public function editLoanTypeDetail(){
        $loanTypeSection = Input::get('loanTypeSection');
        foreach($loanTypeSection as $row){
            $loan_type_name = Input::get('loan_type_name_'.$row.'');
            $loan_type_id = Input::get('loan_type_id_'.$row.'');
            $data1['loan_type_name'] = strip_tags($loan_type_name);
            $data1['username']        = Auth::user()->name;
            $data1['company_id']          = $_GET['m'];
            $data1['date']            = date("Y-m-d");
            $data1['time']            = date("H:i:s");
        
            DB::table('loan_type')->where('id', $loan_type_id)->update($data1);   
        }
        Session::flash('dataEdit','successfully edit.');
        return Redirect::to('hr/viewLoanTypeList?pageType='.Input::get('pageType').'&&parentCode='.Input::get('parentCode').'&&m='.$_GET['m'].'#SFR');
    }

    public function editLeaveTypeDetail(){
        $leaveTypeSection = Input::get('leaveTypeSection');
        foreach($leaveTypeSection as $row){
            $leave_type_name = Input::get('leave_type_name_'.$row.'');
            $leave_type_id = Input::get('leave_type_id_'.$row.'');
            $data1['leave_type_name'] = strip_tags($leave_type_name);
            $data1['username']        = Auth::user()->name;
            $data1['company_id']          = $_GET['m'];
            $data1['date']            = date("Y-m-d");
            $data1['time']            = date("H:i:s");
        
            DB::table('leave_type')->where('id', $leave_type_id)->update($data1);   
        }
        Session::flash('dataEdit','successfully edit.');
        return Redirect::to('hr/viewLeaveTypeList?pageType='.Input::get('pageType').'&&parentCode='.Input::get('parentCode').'&&m='.$_GET['m'].'#SFR');
    }


    public function editEmployeeRequisitionDetail(Request $request){

        CommonHelper::companyDatabaseConnection(Input::get('company_id'));


        $employee_requisition = EmployeeRequisition::find(Input::get('employeeRequisitionId'));
        $employee_requisition->no_of_emp_required = $request->no_of_emp_required;
        $employee_requisition->job_title = $request->job_title;
        $employee_requisition->department_id = $request->department_id;
        $employee_requisition->job_type_id = $request->job_type_id;
        $employee_requisition->designation_id = $request->designation_id;
        $employee_requisition->qualification_id = $request->qualification_id;
        $employee_requisition->additional_replacement = $request->additional_replacement;
        $employee_requisition->replacement_description = $request->replacement_description;
        $employee_requisition->additional_description = $request->additional_description;
        $employee_requisition->ex_emp_seperation_date = $request->ex_emp_seperation_date;
        $employee_requisition->ex_emp_benefits = $request->ex_emp_benefits;
        $employee_requisition->other_requirment = $request->other_requirment;
        $employee_requisition->age_group_from = $request->age_group_from;
        $employee_requisition->age_group_to = $request->age_group_to;
        $employee_requisition->job_description_exist = $request->job_description_exist;
        $employee_requisition->job_description_attached = $request->job_description_attached;
        $employee_requisition->requisitioned_by = $request->requisitioned_by;
        $employee_requisition->recommended_by = $request->recommended_by;
        $employee_requisition->chairman_approval = $request->chairman_approval;
        $employee_requisition->form_recieved_in_hrd_on = '-';
        $employee_requisition->verified_against_position = '-';
        $employee_requisition->hr_comments = '-';
        $employee_requisition->form_recieved_by = '-';
        $employee_requisition->location = $request->location;
        $employee_requisition->experience = $request->experience;
        $employee_requisition->career_level = $request->career_level;
        $employee_requisition->apply_before_date = $request->apply_before_date;
        $employee_requisition->gender = $request->gender;
        $employee_requisition->username = Auth::user()->name;
        $employee_requisition->date = date('Y-m-d');
        $employee_requisition->time = date("H:i:s");
        $employee_requisition->save();

        CommonHelper::reconnectMasterDatabase();
        Session::flash('dataInsert','successfully saved.');
        return Redirect::to('hr/viewEmployeeRequisitionList?pageType='.Input::get('pageType').'&&parentCode='.Input::get('parentCode').'&&m='.Input::get('company_id').'#SFR');


    }

    

    public function editEmployeeDetail(Request $request)
    {
        $path = '';
        CommonHelper::companyDatabaseConnection(Input::get('companyId'));
      	$employeeSection = Input::get('employeeSection');
		foreach($employeeSection as $row){


            if($request->file('fileToUpload_'.$row.'')):
                $file_name = Input::get('employee_name_'.$row.'').'_'.time().'.'.$request->file('fileToUpload_'.$row.'')->extension();
                $path = $request->file('fileToUpload_'.$row.'')->storeAs('uploads/employee_images',$file_name);
                $data1['img_path'] = 'app/'.$path;

            endif;

            $employee_code = Input::get('employee_code_'.$row.'');
            $employee_name = Input::get('employee_name_'.$row.'');
            $emp_grade = Input::get('emp_grade_'.$row.'');
            $father_name = Input::get('father_name_'.$row.'');
          //  $sub_department_id = Input::get('sub_department_id_'.$row.'');
            $department_id = Input::get('department_id_'.$row.'');
            $date_of_birth = Input::get('date_of_birth_'.$row.'');
            $joining_date = Input::get('joining_date_'.$row.'');
            $gender = Input::get('gender_'.$row.'');
            $cnic = Input::get('cnic_'.$row.'');
            $cnic_issue_date = Input::get('cnic_issue_date_'.$row.'');
            $cnic_expiry_date= Input::get('cnic_expiry_date_'.$row.'');
            $contact_no = Input::get('contact_no_'.$row.'');
            $salary = Input::get('salary_'.$row.'');
            $email = Input::get('email_'.$row.'');
            $marital_status = Input::get('marital_status_'.$row.'');
            $landline = Input::get('landline_'.$row.'');
            $attendance_machine_id = Input::get('attendance_machine_id_'.$row.'');
            $nationality = Input::get('nationality_'.$row.'');
            $no_of_dependants = Input::get('no_of_dependants_'.$row.'');
            $residential_address = Input::get('residential_address_'.$row.'');
            $permanent_address =  Input::get('permanent_address_'.$row.'');
            $special_skills = Input::get('special_skills_'.$row.'');
            $leaves_policy = Input::get('leaves_policy_'.$row.'');
            $designation = Input::get('designation_'.$row.'');
            $tax_id = Input::get('tax_id_'.$row.'');
            $eobi_id = Input::get('eobi_id_'.$row.'');
            $so_wo_do = Input::get('so_do_wo_'.$row.'');
            $division = Input::get('division_'.$row.'');
            $company =  Input::get('company_'.$row.'');

			//$department_name = Input::get('department_name');
            $data1['attendance_machine_id']  = strip_tags($attendance_machine_id);
		    $data1['emp_code'] 				 = strip_tags($employee_code);
            $data1['tax_id'] 				 = strip_tags($tax_id);
            $data1['eobi_id'] 				 = strip_tags($eobi_id);
            $data1['designation_id'] 		 = strip_tags($designation);
            $data1['leaves_policy_id'] 		 = strip_tags($leaves_policy);
			$data1['emp_name'] 				 = strip_tags($employee_name);
            $data1['emp_grade']      		 = strip_tags($emp_grade);
			$data1['emp_father_name'] 		 = strip_tags($father_name);
            $data1['emp_department_id']  = strip_tags($department_id);
			//$data1['emp_sub_department_id']  = strip_tags($sub_department_id);
			$data1['emp_date_of_birth'] 	 = strip_tags($date_of_birth);
			$data1['emp_joining_date'] 		 = strip_tags($joining_date);
			$data1['emp_gender'] 			 = strip_tags($gender);
			$data1['emp_cnic'] 				 = strip_tags($cnic);
            $data1['cnic_issue_date'] 		 = strip_tags($cnic_issue_date);
            $data1['cnic_expiry_date'] 		 = strip_tags($cnic_expiry_date);
			$data1['emp_contact_no'] 		 = strip_tags($contact_no);
            $data1['landline'] 		         = strip_tags($landline);
            $data1['nationality'] 		     = strip_tags($nationality);
            $data1['no_of_dependants'] 		 = strip_tags($no_of_dependants);
            $data1['residential_address'] 	 = strip_tags($residential_address);
            $data1['permanent_address'] 	 = strip_tags($permanent_address);
            $data1['special_skills'] 	     = strip_tags($special_skills);
			$data1['emp_salary'] 			 = strip_tags($salary);
            $data1['so_wo_do'] 			     = strip_tags($so_wo_do);
            $data1['division'] 			     = strip_tags($division);
            $data1['company'] 			     = strip_tags($company);
            $data1['emp_email'] 			 = strip_tags($email);
			$data1['emp_marital_status'] 	 = strip_tags($marital_status);
			$data1['username'] 		 		 = Auth::user()->name;
            $data1['can_login'] 	         = (Input::get('can_login_'.$row.'') ? 'yes' : 'no');
            $data1['status'] 		 		 = 1;
        	$data1['date']     		  		 = date("Y-m-d");
        	$data1['time']     		  		 = date("H:i:s");

            DB::table('employee')->where('id', Input::get('recordId'))->update($data1);

            /*Employee Salary Starts here*/
            $last_drawn_salary   = Input::get('last_drawn_salary_'.$row.'');
            $last_drawn_benefits = Input::get('last_drawn_benefits_'.$row.'');
            $expected_salary     = Input::get('expected_salary_'.$row.'');
            $expected_benefits   = Input::get('expected_benefits_'.$row.'');
            $notice_period       = Input::get('notice_period_'.$row.'');
            $possbile_doj        = Input::get('possbile_doj_'.$row.'');

            $Salary['emp_id']           = strip_tags(Input::get('recordId'));
            $Salary['last_drawn_salary'] = strip_tags($last_drawn_salary);
            $Salary['last_drawn_benefits'] = strip_tags($last_drawn_benefits);
            $Salary['expected_salary'] = strip_tags($expected_salary);
            $Salary['expected_benefits'] = strip_tags($expected_benefits);
            $Salary['notice_period'] = strip_tags($notice_period);
            $Salary['possbile_doj'] = strip_tags($possbile_doj);
            $Salary['username']                = Auth::user()->name;
            $Salary['status']                  = 1;
            $Salary['date']                    = date("Y-m-d");
            $Salary['time']                    = date("H:i:s");


            DB::table('employee_salary_detail')->where('emp_id', Input::get('recordId'))->update($Salary);


            /*Employee Salary Ends here*/

            if(Input::get('can_login_'.$row.'')):


                if(Input::get('login_check') == Input::get('can_login_'.$row.'')):

                    CommonHelper::reconnectMasterDatabase();
                    $email = Input::get('email_'.$row.'');
                    $employee_password = Input::get('password_'.$row.'');
                    $employee_name = Input::get('employee_name_'.$row.'');
                    $employee_username = Input::get('username_'.$row.'');
                    $employee_account_type = Input::get('account_type_'.$row.'');


                    $dataCredentials['name'] = $employee_name;
                    $dataCredentials['username'] = $email;
                    $dataCredentials['email'] = $email;
                    $dataCredentials['password'] = Hash::make($employee_password);
                    $dataCredentials['acc_type'] = $employee_account_type;
                    $dataCredentials['emp_id'] =  Input::get('recordId');
                    $dataCredentials['company_id'] = Input::get('companyId');
                    $dataCredentials['updated_at'] = date("Y-m-d");
                    $dataCredentials['created_at'] = date("Y-m-d");
                    $dataCredentials['company_id'] = Input::get('companyId');

                    // DB::table('users')->insert($dataCredentials);
                    DB::table('users')->where('emp_id', Input::get('recordId'))->update($dataCredentials);


                else:

                    CommonHelper::reconnectMasterDatabase();
                    $email = Input::get('email_'.$row.'');
                    $employee_password = Input::get('password_'.$row.'');
                    $employee_name = Input::get('employee_name_'.$row.'');
                    $employee_username = Input::get('username_'.$row.'');
                    $employee_account_type = Input::get('account_type_'.$row.'');


                    $dataCredentials['name'] = $employee_name;
                    $dataCredentials['username'] = $email ;
                    $dataCredentials['email'] = $email;
                    $dataCredentials['password'] = Hash::make($employee_password);
                    $dataCredentials['acc_type'] = $employee_account_type;
                    $dataCredentials['emp_id'] =  Input::get('recordId');
                    $dataCredentials['company_id'] = Input::get('companyId');
                    $dataCredentials['updated_at'] = date("Y-m-d");
                    $dataCredentials['created_at'] = date("Y-m-d");
                    $dataCredentials['company_id'] = Input::get('companyId');

                    DB::table('users')->insert($dataCredentials);

                endif;



            else:
                CommonHelper::reconnectMasterDatabase();

                DB::table('users')->where('emp_id', '=', Input::get('recordId'))->delete();

            endif;


        }

        CommonHelper::companyDatabaseConnection(Input::get('companyId'));

        /*Employee Qualification Starts here*/
         DB::table('employee_qualification')->where('emp_id', '=', Input::get('recordId'))->delete();


        $qualificationSection = Input::get('qualificationSection');
        foreach($qualificationSection as $key4 => $row4)
        {

            $degreeTypeId = Input::get('degree_type_'.$row4.'');
            if(Input::get('degree_type_'.$row4.'') == 'other'):


                CommonHelper::reconnectMasterDatabase();

                $DegreeType['degree_type_name']   = strip_tags(Input::get('other_qualification_'.$row4.''));
                $DegreeType['company_id'] 	      = Input::get('companyId');
                $DegreeType['username']           = Auth::user()->name;;
                $DegreeType['status'] 		      = 1;
                $DegreeType['date']     		  = date("Y-m-d");
                $DegreeType['time']     		  = date("H:i:s");

                $degreeTypeId =DB::table('degree_type')->insertGetId($DegreeType);
                CommonHelper::companyDatabaseConnection(Input::get('companyId'));
            endif;


            $Qualification['emp_id']                  = strip_tags(Input::get('recordId'));
            $Qualification['degree_type']             = $degreeTypeId;
            $Qualification['school_college_university']= strip_tags(Input::get('school_college_university_'.$row4.''));
            $Qualification['year_of_passing']         = strip_tags(Input::get('year_of_passing_'.$row4.''));
            $Qualification['grade_div_cgpa']          = strip_tags(Input::get('grade_div_cgpa_'.$row4.''));
            $Qualification['username']                = Auth::user()->name;
            $Qualification['status']                  = 1;
            $Qualification['date']                    = date("Y-m-d");
            $Qualification['time']                    = date("H:i:s");


           DB::table('employee_qualification')->insert($Qualification);;
        }
        

      /*  foreach(Input::get('degree_type') as $QualificaitonKey => $QualificaitonValue):

            $Qualification['emp_id']                  = strip_tags(Input::get('recordId'));
            $Qualification['degree_type']             = $QualificaitonValue;
            $Qualification['school_college_university']= strip_tags(Input::get('school_college_university')[$QualificaitonKey]);
            $Qualification['year_of_passing']         = strip_tags(Input::get('year_of_passing')[$QualificaitonKey]);
            $Qualification['grade_div_cgpa']          = strip_tags(Input::get('grade_div_cgpa')[$QualificaitonKey]);
            $Qualification['username']                = Auth::user()->name;
            $Qualification['status']                  = 1;
            $Qualification['date']                    = date("Y-m-d");
            $Qualification['time']                    = date("H:i:s");

            DB::table('employee_qualification')->insert($Qualification);
        endforeach;
      */


        /*Employee Qualification Ends here*/

        /*Employee Work Experience Starts here*/
        DB::table('employee_work_experience')->where('emp_id', '=', Input::get('recordId'))->delete();

        foreach(Input::get('employeer_name') as $WorkExperienceKey => $WorkExperienceValue):

            $WorkExperience['emp_id']          = strip_tags(Input::get('recordId'));
            $WorkExperience['employeer_name']  = $WorkExperienceValue;
            $WorkExperience['position_held']   = strip_tags(Input::get('position_held')[$WorkExperienceKey]);
            $WorkExperience['started']         = strip_tags(Input::get('started')[$WorkExperienceKey]);
            $WorkExperience['ended']           = strip_tags(Input::get('ended')[$WorkExperienceKey]);
            $WorkExperience['reason_leaving']  = strip_tags(Input::get('reason_leaving')[$WorkExperienceKey]);
            $WorkExperience['username']        = Auth::user()->name;
            $WorkExperience['status']          = 1;
            $WorkExperience['date']            = date("Y-m-d");
            $WorkExperience['time']            = date("H:i:s");

            DB::table('employee_work_experience')->insert($WorkExperience);
        endforeach;


        /*Employee Work Experience Ends here*/

        /*Employee Refrence Starts here*/
        DB::table('employee_reference')->where('emp_id', '=', Input::get('recordId'))->delete();
        foreach(Input::get('reference_name') as $ReferenceKey => $ReferenceValue):

            $Reference['emp_id']                     = strip_tags(Input::get('recordId'));
            $Reference['reference_name']             = $ReferenceValue;
            $Reference['reference_designation']      = strip_tags(Input::get('reference_designation')[$ReferenceKey]);
            $Reference['reference_organization']     = strip_tags(Input::get('reference_organization')[$ReferenceKey]);
            $Reference['reference_address']           = strip_tags(Input::get('reference_address')[$ReferenceKey]);
            $Reference['reference_country']  = strip_tags(Input::get('reference_country')[$ReferenceKey]);
            $Reference['reference_contact']  = strip_tags(Input::get('reference_contact')[$ReferenceKey]);
            $Reference['reference_relationship']  = strip_tags(Input::get('reference_relationship')[$ReferenceKey]);
            $Reference['username']        = Auth::user()->name;
            $Reference['status']          = 1;
            $Reference['date']            = date("Y-m-d");
            $Reference['time']            = date("H:i:s");

            DB::table('employee_reference')->insert($Reference);
        endforeach;


        /*Employee Refrence Ends here*/

        CommonHelper::reconnectMasterDatabase();
        Session::flash('dataInsert','successfully saved.');
		return Redirect::to('hr/viewEmployeeList?pageType=viewlist&&parentCode=20&&m='.Input::get('companyId').'');
		
	}

    

    public function editMaritalStatusDetail()
    {
        
        $data1['marital_status_name'] = strip_tags(Input::get('marital_status_name'));
        $data1['username']        = Auth::user()->name;
        $data1['company_id']          = $_GET['m'];
        $data1['date']            = date("Y-m-d");
        $data1['time']            = date("H:i:s");
    
        DB::table('marital_status')->where('id', Input::get('id'))->update($data1);
        Session::flash('dataEdit','successfully edit.');
        return Redirect::to('hr/viewMaritalStatuslist?pageType=viewlist&&parentCode=16&&m='.$_GET['m'].'');
    
    }

    public function editAllowanceDetail()
    {
        CommonHelper::companyDatabaseConnection(Input::get('company_id'));


            $data1['emp_id'] 				= strip_tags(Input::get('employee_id'));
            $data1['emp_sub_department_id'] = strip_tags(Input::get('sub_department_id'));
            $data1['allowance_type'] 		= strip_tags(Input::get('allowance_type'));
            $data1['allowance_amount'] 		= strip_tags(Input::get('allowance_amount'));
            $data1['username'] 				= Auth::user()->name;
            $data1['status'] 		 		= 1;
            $data1['date']     		  		= date("Y-m-d");
            $data1['time']     		  		= date("H:i:s");
            DB::table('allowance')->where([['id','=',Input::get('allowanceId')]])->update($data1);

        CommonHelper::reconnectMasterDatabase();
        Session::flash('dataInsert','successfully saved.');
        return Redirect::to('hr/viewAllowanceList?pageType=viewlist&&parentCode=21&&m='.Input::get('company_id').'');

    }
    public function editDeductionDetail()
    {
        CommonHelper::companyDatabaseConnection(Input::get('company_id'));


        $data1['emp_id'] 				= strip_tags(Input::get('employee_id'));
        $data1['emp_sub_department_id'] = strip_tags(Input::get('sub_department_id'));
        $data1['deduction_type'] 		= strip_tags(Input::get('deduction_type'));
        $data1['deduction_amount'] 		= strip_tags(Input::get('deduction_amount'));
        $data1['username'] 				= Auth::user()->name;
        $data1['status'] 		 		= 1;
        $data1['date']     		  		= date("Y-m-d");
        $data1['time']     		  		= date("H:i:s");
        
        DB::table('deduction')->where([['id','=',Input::get('deductionId')]])->update($data1);

        CommonHelper::reconnectMasterDatabase();
        Session::flash('dataInsert','successfully saved.');
        return Redirect::to('hr/viewDeductionList?pageType=viewlist&&parentCode=21&&m='.Input::get('company_id').'');

    }

    public function editAdvanceSalaryDetail()
    {

        CommonHelper::companyDatabaseConnection(Input::get('company_id'));
        $implode_date = explode("-",Input::get('deduction_month_year'));

        $data1['emp_id'] 				= Auth::user()->id;
        $data1['salary_needed_on'] 		= strip_tags(Input::get('salary_needed_date'));
        $data1['deduction_year'] 		= $implode_date[0];
        $data1['deduction_month'] 		= $implode_date[1];
        $data1['detail'] 		        = strip_tags(Input::get('advance_salary_detail'));
        $data1['username'] 				= Auth::user()->name;
        $data1['status'] 		 		= 1;
        $data1['date']     		  		= date("Y-m-d");
        $data1['time']     		  		= date("H:i:s");



        DB::table('advance_salary')->where([['id','=',Input::get('advance_salary_id')]])->update($data1);
        CommonHelper::reconnectMasterDatabase();
        Session::flash('dataInsert','successfully saved.');
        return Redirect::to('hr/viewAdvanceSalaryList?pageType=viewlist&&parentCode=21&&m='.Input::get('company_id').'');


    }

    public function editLeavesPolicyDetail()
    {
        CommonHelper::companyDatabaseConnection(Input::get('company_id'));


        $data1['leaves_policy_name'] 		= strip_tags(Input::get('leaves_policy_name'));
        $data1['policy_date_from'] 	        = strip_tags(Input::get('PolicyDateFrom'));
        $data1['policy_date_till'] 	        = strip_tags(Input::get('PolicyDateTill'));
        $data1['terms_conditions'] 		    = Input::get('terms_conditions');
        $data1['fullday_deduction_rate'] 	= Input::get('full_day_deduction_rate');
        $data1['halfday_deduction_rate']    = Input::get('half_day_deduction_rate');
        $data1['per_hour_deduction_rate']   = Input::get('per_hour_deduction_rate');
        $data1['username']     		  		= Auth::user()->name;
        $data1['status']     		  		= 1;
        $data1['time']     		  		    = date("H:i:s");
        $data1['date']     		  		    = date("Y-m-d");

        LeavesPolicy::where([['id','=',Input::get('record_id')]])->update($data1);
        LeavesData::where([['leaves_policy_id','=',Input::get('record_id')]])->delete();

        foreach(Input::get('leaves_type_id') as $key => $val):

            $data2['leaves_policy_id']=Input::get('record_id');
            $data2['leave_type_id']   =$val;
            $data2['no_of_leaves']    =Input::get('no_of_leaves')[$key];
            $data2['username']        =Auth::user()->name;;
            $data2['status']          =1;
            $data2['time']            =date("H:i:s");
            $data2['date']            =date("Y-m-d");
            DB::table('leaves_data')->insert($data2);

        endforeach;

        CommonHelper::reconnectMasterDatabase();
        Session::flash('dataInsert','successfully saved.');
        return Redirect::to('hr/viewLeavesPolicyList?pageType=viewlist&&parentCode=21&&m='.Input::get('company_id').'');

    }

    public function editVehicleTypeDetail()
    {
        $data1['vehicle_type_name'] 	= strip_tags(Input::get('vehicle_type_name'));
        $data1['vehicle_type_cc'] 		= strip_tags(Input::get('vehicle_type_cc'));
        $data1['username'] 				= Auth::user()->name;
        $data1['company_id'] 			= Input::get('m');
        $data1['status'] 		 		= 1;
        $data1['date']     		  		= date("Y-m-d");
        $data1['time']     		  		= date("H:i:s");


        DB::table('vehicle_type')->where([['id','=',Input::get('record_id')],['company_id','=',Input::get('company_id')]])->update($data1);
        Session::flash('dataInsert','successfully saved.');
        return Redirect::to('hr/viewVehicleTypeList?pageType=viewlist&&parentCode=21&&m='.Input::get('company_id').'');

    }
    public function editCarPolicyDetail()
    {

        $data1['designation_id'] 		= Input::get('designation_id');
        $data1['vehicle_type_id']  	    = Input::get('vehicle_type_id');
        $data1['policy_name'] 	        = Input::get('policy_name');
        $data1['start_salary_range'] 	= Input::get('start_salary_range');
        $data1['end_salary_range'] 	 	= Input::get('end_salary_range');
        $data1['status'] 		 		= 1;
        $data1['date']     		  		= date("Y-m-d");
        $data1['time']     		  		= date("H:i:s");
        CommonHelper::companyDatabaseConnection(Input::get('company_id'));
        DB::table('car_policy')->where([['id','=',Input::get('record_id')]])->update($data1);
        CommonHelper::reconnectMasterDatabase();
        Session::flash('dataInsert','successfully saved.');
        return Redirect::to('hr/viewCarPolicyList?pageType=viewlist&&parentCode=21&&m='.Input::get('company_id').'');

    }
    public function editQualificationDetail()
    {
        $qualificationSection = Input::get('qualificationSection');
        foreach($qualificationSection as $row){
            $qualification_name = Input::get('qualification_name_'.$row.'');
            $country = Input::get('country_'.$row.'');
            $state = Input::get('state_'.$row.'');
            $city = Input::get('city_'.$row.'');
            $institute = Input::get('institute_id_'.$row.'');
            $data2['qualification_name']	= strip_tags($qualification_name);
            $data2['institute_id']			= strip_tags($institute);
            $data2['country_id']			= strip_tags($country);
            $data2['state_id']				= strip_tags($state);
            $data2['city_id']				= strip_tags($city);
            $data2['username'] 		    	= Auth::user()->name;
            $data2['status'] 		 		= 1;
            $data2['date']     		  		= date("Y-m-d");
            $data2['time']     		  		= date("H:i:s");
            $data2['company_id'] 	  		= $_GET['m'];

            DB::table('qualification')->where([['id','=',Input::get('qualification_id_1')]])->update($data2);


        }
        Session::flash('dataInsert','successfully saved.');
        return Redirect::to('hr/viewQualificationList?pageType='.Input::get('pageType').'&&parentCode='.Input::get('parentCode').'&&m='.$_GET['m'].'#SFR');

    }


    public function editLoanRequestDetail()
    {
        $data1['emp_id']           = Input::get('employee_id');
        $data1['needed_on']        = Input::get('needed_on_date');
        $data1['description']      = Input::get('loan_description');
        $data1['status'] 		   = 1;
        $data1['username']         = Auth::user()->name;;
        $data1['date']     		   = date("Y-m-d");
        $data1['time']     		   = date("H:i:s");

        CommonHelper::companyDatabaseConnection(Input::get('company_id'));
        DB::table('loan_request')->where([['id','=',Input::get('loanRequestId')]])->update($data1);
        CommonHelper::reconnectMasterDatabase();
        Session::flash('dataInsert','successfully saved.');
        return Redirect::to('hr/viewLoanRequestList?pageType=viewlist&&parentCode=21&&m='.Input::get('company_id').'');

    }

    public function editEOBIDetail()
    {
        $data1['EOBI_name']        = Input::get('EOBI_name');
        $data1['EOBI_amount']      = Input::get('EOBI_amount');
        $data1['month_year']       = Input::get('month_year');
        $data1['username']         = Auth::user()->name;;
        $data1['date']     		   = date("Y-m-d");
        $data1['time']     		   = date("H:i:s");

        DB::table('eobi')->where([['company_id','=',Input::get('company_id')],['id','=',Input::get('recordId')]])->update($data1);
        Session::flash('dataInsert','successfully saved.');
        return Redirect::to('hr/viewEOBIList?pageType=viewlist&&parentCode=21&&m='.Input::get('company_id').'');


    }

    public function editDegreeTypeDetail()
    {
        $data1['degree_type_name'] = Input::get('degree_type_name');
        $data1['company_id'] 	   = Input::get('company_id');
        $data1['username']         = Auth::user()->name;;
        $data1['status'] 		   = 1;
        $data1['date']     		   = date("Y-m-d");
        $data1['time']     		   = date("H:i:s");

        DB::table('degree_type')->where([['company_id','=',Input::get('company_id')],['id','=',Input::get('recordId')]])->update($data1);
        Session::flash('dataInsert','successfully saved.');
        return Redirect::to('hr/viewDegreeTypeList?pageType=viewlist&&parentCode=21&&m='.Input::get('company_id').'');


    }

    public function editTaxesDetail()
    {
        $data1['tax_name']             = Input::get('tax_name');
        $data1['salary_range_from']    = Input::get('salary_range_from');
        $data1['salary_range_to']      = Input::get('salary_range_to');
        $data1['tax_percent']          = Input::get('tax_percent');
        $data1['tax_month_year']       = Input::get('tax_month_year');
        $data1['company_id'] 	       = Input::get('company_id');
        $data1['username']             = Auth::user()->name;;
        $data1['date']     		       = date("Y-m-d");
        $data1['time']     		       = date("H:i:s");

        DB::table('tax')->where([['company_id','=',Input::get('company_id')],['id','=',Input::get('recordId')]])->update($data1);
        Session::flash('dataInsert','successfully saved.');
        return Redirect::to('hr/viewTaxesList?pageType=viewlist&&parentCode=21&&m='.Input::get('company_id').'');


    }

    public function editBonusDetail()
    {

        $data1['bonus_name']         = Input::get('Bonus_name');
        $data1['percent_of_salary']  = Input::get('percent_of_salary');
        $data1['status'] 		     = 1;
        $data1['username']           = Auth::user()->name;;
        $data1['date']     		     = date("Y-m-d");
        $data1['time']     		     = date("H:i:s");

        CommonHelper::companyDatabaseConnection(Input::get('company_id'));
        DB::table('bonus')->where([['id','=',Input::get('recordId')]])->update($data1);
        CommonHelper::reconnectMasterDatabase();

        Session::flash('dataInsert','successfully saved.');
        return Redirect::to('hr/viewBonusList?pageType=viewlist&&parentCode=21&&m='.Input::get('company_id').'');
    }

    public function editHolidayDetail()
    {


            CommonHelper::companyDatabaseConnection(Input::get('company_id'));


            if(Input::get('holiday_name')):

                foreach(Input::get('holiday_name') as $key => $value):
                    $month_year = explode('-',Input::get('holiday_month_year')[$key]);
                    $data1['holiday_name'] = $value;
                    $data1['holiday_date'] = Input::get('holiday_date')[$key];
                    $data1['year']         = $month_year[0];
                    $data1['month']        = $month_year[1];
                    $data1['username'] 	   = Auth::user()->name;
                    $data1['status']       = 1;
                    $data1['date']     	   = date("d-m-Y");
                    $data1['time']     	   = date("H:i:s");

                    DB::table('holidays')->where([['id','=',Input::get('record_id')]])->update($data1);

                endforeach;

            endif;
            CommonHelper::reconnectMasterDatabase();
            Session::flash('dataInsert','successfully saved.');
            return Redirect::to('hr/viewHolidaysList?pageType=viewlist&&parentCode=21&&m='.Input::get('company_id').'');
        }


}
