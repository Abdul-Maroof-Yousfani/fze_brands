<?php

namespace App\Http\Controllers;
use Illuminate\Database\DatabaseManager;
use App\Http\Requests;
use Illuminate\Http\Request;
use App\Helpers\CommonHelper;
use App\Helpers\PurchaseHelper;
use Input;
use Auth;
use DB;
use Config;
use Redirect;
use Session;


use App\Models\PurchaseVoucher;
use App\Models\PurchaseVoucherData;
use App\Models\Transactions;
use App\Models\DepartmentAllocation1;
use App\Models\SalesTaxDepartmentAllocation;
use App\Models\CostCenterDepartmentAllocation;
use App\Helpers\FinanceHelper;
class PurchaseEditDetailControler extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');

    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */

    public function editSupplierDetail(){

        CommonHelper::companyDatabaseConnection($_GET['m']);
        $id = Input::get('supplier_id');
        $supplier_name = Input::get('supplier_name');
        $country = Input::get('country');
        $state = Input::get('state');
        $city = Input::get('city');
        $email = Input::get('email');
        $o_blnc_trans = Input::get('o_blnc_trans');
        $register_income_tax=Input::get('regd_in_income_tax');
        $business_type=Input::get('optradiooo');
        $ntn=Input::get('ntn');
        $cnic=Input::get('cnic');
        $regd_in_sales_tax=Input::get('regd_in_sales_tax');
        $strn=Input::get('strn');
        $regd_in_srb=Input::get('regd_in_srb');
        $srb=Input::get('srb');
        $regd_in_pra=Input::get('regd_in_pra');
        $pra=Input::get('pra');

        $print_check_as=Input::get('print_check_as');
        $vendor_type=Input::get('vendor_type');
        $website=Input::get('website');
        $credit_limit=Input::get('credit_limit');
        $acc_no=Input::get('acc_no');
        $bank_name=Input::get('bank_name');
        $bank_address=Input::get('bank_address');
        $branch_name=Input::get('branch_name');
        $swift_code=Input::get('swift_code');
        $open_date=Input::get('open_date');


        $address[] = Input::get('address');
        $o_blnc = Input::get('o_blnc');




        $data2['resgister_income_tax']     		    = strip_tags($register_income_tax);
        $data2['business_type']     		= strip_tags($business_type);
        $data2['cnic']     	    = strip_tags($cnic);
        $data2['ntn']     	        = strip_tags($ntn);
        $data2['register_sales_tax']     	        = strip_tags($regd_in_sales_tax);
        $data2['strn']     	        = strip_tags($strn);
        $data2['register_srb']     	        = strip_tags($regd_in_srb);
        $data2['srb']     	        = strip_tags($srb);
        $data2['register_pra']     	        = strip_tags($regd_in_pra);
        $data2['pra']     	        = strip_tags($pra);
        $data2['name']     		    = strip_tags($supplier_name);
        $data2['country']     		= strip_tags($country);
        $data2['province']     	    = strip_tags($state);
        $data2['city']     	        = strip_tags($city);
        $data2['email']   		    = strip_tags($email);
        $data2['username']	 	    = Auth::user()->name;
        $data2['date']     		    = date("Y-m-d");
        $data2['time']     		    = date("H:i:s");
        $data2['action']     		= 'create';
        $data2['company_id']     		= $_GET['m'];

        $data2['print_check_as']     		= $print_check_as;
        $data2['vendor_type']	 	    = $vendor_type;
        $data2['website']     		    = $website;
        $data2['credit_limit']     		    = $credit_limit;
        $data2['acc_no']     		= $acc_no;
        $data2['bank_name']     		= $bank_name;
        $data2['bank_address']     		= $bank_address;
        $data2['swift_code']     		= $swift_code;
        $data2['branch_name']     		= $branch_name;
        $data2['opening_bal_date']     		= $open_date;
        DB::table('supplier')->where('id',$id)->update($data2);
        DB::table('supplier_info')->where('supp_id',$id)->delete();

        $count1 = count(Input::get('contact_no'));
        $count2 = count(Input::get('address'));
        if ($count1==$count2):
            $count=$count1;
        else:

            if ($count1 >$count2):
                $count=$count1;
            else:
                $count=$count2;
            endif;
        endif;
        $count=$count-1;

        for($i=0; $i<=$count;$i++):
            $data4['supp_id']=$id;



            $ii=$i+1;
            if ($count2 >=$ii):


                $data4['address']=Input::get('address')[$i];
            else:
                $data4['address']='';
            endif;
            echo $count1.' '.$ii.'</br>';
            if ($count1 >=$ii):


                $data4['contact_no']=Input::get('contact_no')[$i];
            else:
                $data4['contact_no']='';
            endif;
            DB::table('supplier_info')->insert($data4);
        endfor;



        $data3['debit_credit']      = 0;
        $data3['amount'] 	        = strip_tags($o_blnc);
        $data3['opening_bal'] 	    = 1;
        $data3['username'] 		 	= Auth::user()->name;
        $data3['date']     		    = date("Y-m-d");
        $data3['v_date']     		= date("Y-m-d");
        $data3['time']     		    = date("H:i:s");
        $data3['action']     		= 'create';
        //    DB::table('transactions')->insert($data3);



        CommonHelper::reconnectMasterDatabase();
        return Redirect::to('purchase/viewSupplierList?pageType='.Input::get('pageType').'&&parentCode='.Input::get('parentCode').'&&m='.$_GET['m'].'#SFR');
    }

    public function editSubItemDetail(){
        $m = $_GET['m'];
        CommonHelper::companyDatabaseConnection($_GET['m']);
        $recordId = Input::get('recordId');
        $recordAccId = Input::get('recordAccId');
        $priviousMainIcId = Input::get('priviousMainIcId');

        $category_name = Input::get('category_name');
        $sub_item_name = Input::get('sub_item_name');
        $opening_qty = Input::get('opening_qty');
        $opening_value = Input::get('opening_value');
        $rate = Input::get('rate');

        $uom = Input::get('uom_id');
        $username = '';
        $branch_id = '';
        $o_blnc_trans_form 		= 	1;
        $wip_finish_g_form = 'fara';
        $acc_id = DB::selectOne('select `acc_id` from `category` where `id` = '.$category_name.'')->acc_id;
        $parent_code = DB::selectOne('select code from `accounts` where `id` = '.$acc_id.'')->code;
        $max_id = DB::selectOne('SELECT max(`id`) as id  FROM `accounts` WHERE `parent_code` LIKE \''.$parent_code.'\'')->id;
        if($max_id == ''){
            $code = $parent_code.'-1';
        }else{
            $max_code2 = DB::selectOne('SELECT `code`  FROM `accounts` WHERE `id` LIKE \''.$max_id.'\'')->code;
            $max_code2;
            $max = explode('-',$max_code2);
            $code = $parent_code.'-'.(end($max)+1);
        }
        $level_array = explode('-',$code);
        $counter = 1;
        foreach($level_array as $level):
            $data1['level'.$counter] = strip_tags($level);
            $counter++;
        endforeach;

        $data1['code']              = strip_tags($code);
        $data1['name']              = strip_tags($sub_item_name);
        $data1['parent_code']       = strip_tags($parent_code);
        $data1['username'] 		 	= Auth::user()->name;
        $data1['date']     		    = date("Y-m-d");
        $data1['time']     		    = date("H:i:s");
        $data1['action']     		= 'create';
        $data1['operational']		= 1;


        DB::table('accounts')->where('id','=',$recordAccId)->update($data1);
        $acc_id_new = $recordAccId;

        $data2['acc_id']			= strip_tags($acc_id_new);
        $data2['sub_ic']     		= strip_tags($sub_item_name);
        $data2['main_ic_id']     	= strip_tags($category_name);
        $data2['rate']     = strip_tags($rate);
        $data2['uom']     	        = strip_tags($uom);
        $data2['username']	 	    = Auth::user()->name;
        $data2['date']     		    = date("Y-m-d");
        $data2['time']     		    = date("H:i:s");
        $data2['action']     		= 'create';
        $data2['company_id']        = $m;

        DB::table('subitem')->where('id','=',$recordId)->update($data2);
        $s_id = $recordId;

        $data3['acc_code']		    = strip_tags($code);
        $data3['acc_id']		    = strip_tags($acc_id_new);
        $data3['debit_credit']	    = 1;
        $data3['opening_bal']	    = 1;
        $data3['username'] 		    = Auth::user()->name;
        $data3['v_date']     		= date("Y-m-d");
        $data3['date']     		    = date("Y-m-d");
        $data3['time']     		    = date("H:i:s");
        $data3['action']     	    = 'create';
        $data3['status']			= 1;
        $data3['amount']		    = $opening_value;

        DB::table('transactions')->where('acc_id','=',$recordAccId)->where('opening_bal','=','1')->where('status','=','1')->update($data3);

        $data4['main_ic_id']        = strip_tags($category_name);
        $data4['sub_ic_id']         = strip_tags($s_id);
        $data4['value'] 	        = $opening_value;
        $data4['qty']     		    = strip_tags($opening_qty);
        $data4['date']     	        = date("Y-m-d");
        $data4['time']     	        = date("H:i:s");
        $data4['action']     	    = '1';//1 for opening
        $data4['username'] 	        = Auth::user()->name;
        $data4['date']     	        = date("Y-m-d");
        $data4['time']     	        = date("H:i:s");
        $data4['company_id']        = $m;

        DB::table('fara')->where('sub_ic_id','=',$recordId)->where('main_ic_id','=',$priviousMainIcId)->where('action','=','1')->update($data4);

        $updateFaraEntries = array(
            'main_ic_id' => $category_name
        );

        DB::table('fara')->where('sub_ic_id','=',$recordId)->where('main_ic_id','=',$priviousMainIcId)->update($updateFaraEntries);

        $updateTransectionEntries = array(
            'acc_code' => $code
        );

        DB::table('transactions')->where('acc_id','=',$recordAccId)->update($updateTransectionEntries);

        CommonHelper::reconnectMasterDatabase();
        echo 'Done';
        CommonHelper::reconnectMasterDatabase();
        Session::flash('dataEdit','successfully edit.');
    }

    public function editCategoryDetail(){
        $m = $_GET['m'];
        CommonHelper::companyDatabaseConnection($_GET['m']);
        $recordId = Input::get('recordId');
        $recordAccId = Input::get('recordAccId');
        $category_name = Input::get('category_name');

        $updateCategoryDetails = array(
            'main_ic' => $category_name
        );

        $updateAccountDetails = array(
            'name' => $category_name
        );

        DB::table('category')
            ->where('status', 1)
            ->where('id', $recordId)
            ->update($updateCategoryDetails);

        DB::table('accounts')
            ->where('id', $recordAccId)
            ->where('status', 1)
            ->update($updateAccountDetails);

        CommonHelper::reconnectMasterDatabase();
        echo 'Done';
        CommonHelper::reconnectMasterDatabase();
        Session::flash('dataEdit','successfully edit.');
    }

    public function editDemandVoucherDetail(){

        CommonHelper::companyDatabaseConnection($_GET['m']);

        $demand_no = Input::get('demand_no');

        DB::table('demand')->where('demand_no', $demand_no)->delete();
        DB::table('demand_data')->where('demand_no', $demand_no)->delete();




        $slip_no = Input::get('slip_no');
        $demand_date = Input::get('demand_date');
        $mainDescription = Input::get('description');
        $sub_department_id = Input::get('sub_department_id');

        $data1['demand_date']   	= $demand_date;
        $data1['demand_no']   		= $demand_no;
        $data1['slip_no']   	    = $slip_no;
        $data1['description']       = $mainDescription;
        $data1['sub_department_id']       = $sub_department_id;
        $data1['username'] 		    = Auth::user()->name;
        $data1['demand_status']  	= 1;
        $data1['date'] 			    = date('Y-m-d');
        $data1['time'] 			    = date('H:i:s');
        $data1['status']  		    = 1;

        DB::table('demand')->insert($data1);

        $demandDataSection = Input::get('demandDataSection_1');
        foreach($demandDataSection as $row1){
            $category_id =  Input::get('category_id_1_'.$row1.'');
            $sub_item_id =  Input::get('sub_item_id_1_'.$row1.'');
            $description  =  Input::get('description_1_'.$row1.'');
            $qty  =  Input::get('qty_1_'.$row1.'');

            $data2['demand_no']   		= $demand_no;
            $data2['demand_date']   	= $demand_date;
            $data2['category_id'] 		= $category_id;
            $data2['sub_item_id'] 		= $sub_item_id;
            $data2['description'] 		= $description;
            $data2['qty']               = $qty;
            $data2['demand_status']   	= 1;
            $data2['username'] 		    = Auth::user()->name;
            $data2['status']  		    = 1;
            $data2['date'] 			    = date('Y-m-d');
            $data2['time'] 			    = date('H:i:s');

            DB::table('demand_data')->insert($data2);
        }
        echo 'Done';
        CommonHelper::reconnectMasterDatabase();
        Session::flash('dataEdit','successfully edit.');
    }

    public function updateDemandDetailandApprove(){
        CommonHelper::companyDatabaseConnection($_GET['m']);

        $demand_no = Input::get('demandNo');

        $updateDetails = array(
            'demand_status' => 2,
            'approve_username' => Auth::user()->name
        );

        DB::table('demand')
            ->where('demand_no', $demand_no)
            ->update($updateDetails);

        $rowId = Input::get('rowId');
        foreach($rowId as $row1){
            $categoryId =  Input::get('categoryId_'.$row1.'');
            $subItemId =  Input::get('subItemId_'.$row1.'');
            $demandType  =  Input::get('demandType_'.$row1.'');

            $data2['demand_status']   	= 2;
            $data2['approve_username'] 		    = Auth::user()->name;
            $data2['date'] 			    = date('Y-m-d');
            $data2['time'] 			    = date('H:i:s');
          

            DB::table('demand_data')->where('id','=',$row1)->where('category_id','=',$categoryId)->where('sub_item_id','=',$subItemId)->update($data2);
        }
        echo 'Done';
        CommonHelper::reconnectMasterDatabase();
        Session::flash('dataEdit','successfully edit.');
    }

    function editPurchaseVoucher(Request $request,$id)
    {

        $cn = DB::connection('mysql2');
        $cn->beginTransaction();
        // $str = DB::connection('mysql2')->selectOne("select count(id)id from purchase_voucher where status=1 and purchase_date='".Input::get('purchase_date')."'")->id;
        //  $pv_no = 'pv'.($str+1);
        $total_salesTax=str_replace('%','',$request->total_salesTax);
        $purchase_voucher = new PurchaseVoucher();
        $purchase_voucher = $purchase_voucher->SetConnection('mysql2');
        $purchase_voucher=$purchase_voucher->find($id);
        $purchase_voucher->pv_no=$request->pv_no;
        $purchase_voucher->slip_no=$request->slip_no;
        $purchase_voucher->purchase_date=date("Y-m-d", strtotime($request->purchase_date));
        $purchase_voucher->bill_date=date("Y-m-d", strtotime($request->bill_date));;
        $purchase_voucher->purchase_type=$request->p_type;
        $purchase_voucher->current_amount=$request->current_amount;
        $purchase_voucher->amount_in_words=$request->rupeess;
        $purchase_voucher->due_date=date("Y-m-d", strtotime($request->due_date));;
        $purchase_voucher->supplier=$request->supplier;
        $purchase_voucher->total_qty=$request->total_qty;
        $purchase_voucher->total_rate=$request->total_rate;
        $purchase_voucher->total_amount=$request->total_amount;

        $purchase_voucher->total_salesTax_amount=$request->total_salesTax_amount;
        $purchase_voucher->total_net_amount=$request->total_net_amount;
        $purchase_voucher->username= Auth::user()->name;
        $purchase_voucher->edit_date=date('Y-m-d');
        $purchase_voucher->edit=1;
        $purchase_voucher->description=$request->description;
        $purchase_voucher->pv_date=$request->purchase_date;



        $currency=$request->curren;
        $currency=explode(',',$currency);
        $purchase_voucher->currency=$currency[0];
        $purchase_voucher->save();
        $master_id=$id;
        $id=$id;
        $purchase_voucher_dataa=$request->demandDataSection_1;



        // delete data


        $purchase_voucher_data=new PurchaseVoucherData();
        $purchase_voucher_data=$purchase_voucher_data->SetConnection('mysql2');
        $purchase_voucher_data->where('master_id',$id)->delete();

        $department=new DepartmentAllocation1();
        $department=$department->SetConnection('mysql2');
        $department->where('Main_master_id',$id)->delete();

        $cost_center=new CostCenterDepartmentAllocation();
        $cost_center=$cost_center->SetConnection('mysql2');
        $cost_center->where('Main_master_id',$id)->delete();


        $sales_tax=new SalesTaxDepartmentAllocation();
        $sales_tax=$sales_tax->SetConnection('mysql2');
        $sales_tax->where('Main_master_id',$id)->delete();


        $tran=new Transactions();
        $tran=$tran->SetConnection('mysql2');
        $tran->where('master_id',$id)->where('voucher_type',4)->delete();
        //end


        $count=1;
        foreach($purchase_voucher_dataa as $row):

            $purchase_voucher_data = new PurchaseVoucherData();
            $purchase_voucher_data = $purchase_voucher_data->SetConnection('mysql2');
            $request->input('sales_tax_amount_1_'.$count);
            $purchase_voucher_data->master_id=$master_id;
            $purchase_voucher_data->pv_no=$request->pv_no;
            $purchase_voucher_data->category_id=$request->input('category_id_1_'.$count);;
            $purchase_voucher_data->sub_item=$request->input('sub_item_id_1_'.$count);;

            $purchase_voucher_data->uom=$request->input('uom_id_1_'.$count);;
            $purchase_voucher_data->qty=$request->input('qty_1_'.$count);;
            $purchase_voucher_data->rate=$request->input('rate_1_'.$count);;
            $purchase_voucher_data->amount=str_replace(',','',$request->input('amount_1_'.$count));
            $purchase_voucher_data->sales_tax_per=$request->input('accounts_1_'.$count);
            $purchase_voucher_data->sales_tax_amount=$request->input('sales_tax_amount_1_'.$count);
            $purchase_voucher_data->net_amount=$request->input('net_amount_1_'.$count);;
            $purchase_voucher_data->username=Auth::user()->name;
            $purchase_voucher_data->date=date('Y-m-d');
            $purchase_voucher->pv_no=$request->pv_no;
            $purchase_voucher_data->save();
            $other_id=$purchase_voucher_data->id;



            $trans=new Transactions();
            $trans = $trans->SetConnection('mysql2');
            $account=$request->input('category_id_1_'.$count);
            //    $account=CommonHelper::get_item_acc_id($sub_ic_id);

            $trans->acc_id=$account;
            $trans->acc_code=FinanceHelper::getAccountCodeByAccId($account,'');;
            $trans->master_id=$master_id;
            $trans->particulars=$request->description;
            $trans->opening_bal=0;
            $trans->debit_credit=1;
            $trans->amount=str_replace(',','',$request->input('amount_1_'.$count));;
            $trans->voucher_no=$request->pv_no;
            $trans->voucher_type=4;
            $trans->v_date=$request->purchase_date;
            $trans->date=date('Y-m-d');
            $trans->action=1;
            $trans->username=Auth::user()->name;
            $trans->save();

            // for tax
            if ($request->input('accounts_1_'.$count)!=0):
                $trans1=new Transactions();
                $trans1 = $trans1->SetConnection('mysql2');
                $account=$request->input('accounts_1_'.$count);
                $trans1->acc_id=$account;
                $trans1->acc_code=FinanceHelper::getAccountCodeByAccId($account,'');;
                $trans1->master_id=$master_id;
                $trans1->particulars=$request->description;
                $trans1->opening_bal=0;
                $trans1->debit_credit=1;
                $trans1->amount=str_replace(',','',$request->input('sales_tax_amount_1_'.$count));;
                $trans1->voucher_no=$request->pv_no;
                $trans1->voucher_type=4;
                $trans1->v_date=$request->purchase_date;
                $trans1->date=date('Y-m-d');
                $trans1->action=1;
                $trans1->username=Auth::user()->name;
                $trans1->save();
            endif;
            // end for tax

            // for department

            $allow_null=$request->input('dept_check_box'.$count);
            if ($allow_null==0):
                $department1=$request->input('department'.$count);
                $counter=0;
                foreach($department1 as $row1):
                    $dept_allocation1=new DepartmentAllocation1();
                    $dept_allocation1 = $dept_allocation1->SetConnection('mysql2');
                    $dept_allocation1->Main_master_id=$master_id;
                    $dept_allocation1->master_id=$other_id;
                    $dept_allocation1->pv_no=$request->pv_no;
                    $dept_allocation1->dept_id=$row1;
                    $perccent=$request->input('percent'.$count);
                    $dept_allocation1->percent=$perccent[$counter];
                    $amount=$request->input('department_amount'.$count);
                    $amount=str_replace(",","",$amount);
                    $dept_allocation1->amount=$amount[$counter];
                    $dept_allocation1->item=$request->input('sub_item_id_1_'.$count);
                    $dept_allocation1->save();
                    $counter++;

                endforeach;
            endif;

            // end for department


            // for sales tax department

            $allow_null=$request->input('sales_tax_check_box'.$count);
            if ($allow_null==0):
                $sales_tax_department=$request->input('sales_tax_department'.$count);
                $counter=0;
                foreach($sales_tax_department as $row2):
                    if ($row2!=0):
                        $salestaxdepartment=new SalesTaxDepartmentAllocation();
                        $salestaxdepartment = $salestaxdepartment->SetConnection('mysql2');
                        $salestaxdepartment->Main_master_id=$master_id;
                        $salestaxdepartment->master_id=$other_id;
                        $salestaxdepartment->pv_no=$request->pv_no;
                        $salestaxdepartment->dept_id=$row2;
                        $perccent=$request->input('sales_tax_percent'.$count);
                        $salestaxdepartment->percent=$perccent[$counter];
                        $amount=$request->input('sales_tax_department_amount'.$count);
                        $amount=str_replace(",","",$amount);
                        $salestaxdepartment->amount=$amount[$counter];
                        $salestaxdepartment->sales_tax=$request->input('accounts_1_'.$count);

                        $salestaxdepartment->save();
                    endif;
                    $counter++;

                endforeach;
            endif;

            // End for sales tax department


            // for Cost center department

            $allow_null=$request->input('cost_center_check_box'.$count);
            if ($allow_null==0):
                $sales_tax_department=$request->input('cost_center_department'.$count);
                $counter=0;
                foreach($sales_tax_department as $row3):
                    if ($row3!=0):
                        $costcenter=new CostCenterDepartmentAllocation();
                        $costcenter = $costcenter->SetConnection('mysql2');
                        $costcenter->Main_master_id=$master_id;
                        $costcenter->master_id=$other_id;
                        $costcenter->pv_no=$request->pv_no;
                        $costcenter->dept_id=$row3;
                        $perccent=$request->input('cost_center_percent'.$count);
                        $costcenter->percent=$perccent[$counter];
                        $amount=$request->input('cost_center_department_amount'.$count);
                        $amount=$amount[$counter];
                        $amount=str_replace(",","",$amount);
                        $costcenter->amount=$amount;

                        $costcenter->item=$request->input('sub_item_id_1_'.$count);
                        $costcenter->save();
                    endif;
                    $counter++;

                endforeach;
            endif;

            // End for Cost center department


            $count++;  endforeach;


        $trans2=new Transactions();
        $trans2 = $trans2->SetConnection('mysql2');
        $account=CommonHelper::get_supplier_acc_id($request->supplier);
        $trans2->acc_id=$account;
        $trans2->acc_code=FinanceHelper::getAccountCodeByAccId($account,'');;
        $trans2->master_id=$master_id;
        $trans2->particulars=$request->description;
        $trans2->opening_bal=0;
        $trans2->debit_credit=0;
        $trans2->amount=$request->total_net_amount;
        $trans2->voucher_no=$request->pv_no;
        $trans2->voucher_type=4;
        $trans2->v_date=$request->purchase_date;
        $trans2->date=date('Y-m-d');
        $trans2->action=1;
        $trans2->username=Auth::user()->name;

        $trans2->save();

        $cn->rollBack();
        return Redirect::to('pdc/viewPurchaseVoucherDetailAfterSubmit/'.$id);


    }
}
?>